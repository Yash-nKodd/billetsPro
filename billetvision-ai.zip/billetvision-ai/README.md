# BilletVision AI 🦾

> **Automated Steel Billet Optical Quality Inspection & Traceability Workstation**  
> *Engineered for Continuous Casting, Hot-Rolling Mills, and Quality Control Rooms*

---

## 📌 Executive Summary

**BilletVision AI** is a complete, full-stack industrial control-room application for automated steel billet inspection and traceability. It delivers calibrated dimensional measurement, optical character recognition (OCR) of stamped heat numbers and batch identifiers, visible surface defect classification, configurable manufacturing tolerance evaluation, and persistent audit traceability.

Unlike superficial concepts, **BilletVision AI enforces honest AI and hardware states**: when optical camera feeds or deep-learning model weights are unavailable, the system explicitly reports their absence and transitions to **Demo Mode** with certified sample scenarios, preventing unverified or fabricated factory telemetry.

---

## 🏗️ System Architecture

```mermaid
flowchart TD
    subgraph Frontend["React 19 + TypeScript + Vite + Tailwind CSS"]
        UI["Control Room Workstation UI"]
        UI --> OV["1. Overview Dashboard"]
        UI --> LI["2. Live Inspection Viewport"]
        UI --> IH["3. Inspection History"]
        UI --> BP["4. Digital Billet Passport"]
        UI --> QA["5. Quality Analytics"]
        UI --> CW["6. Calibration Workstation"]
        UI --> ST["7. Tolerance & Audit Settings"]
        UI --> AQ["Alerts & Review Queue"]
    end

    subgraph Backend["Python FastAPI Service (127.0.0.1:8000)"]
        API["REST Endpoints (/api)"]
        API --> QE["Quality Decision Engine"]
        API --> DME["Dimensional Measurement Engine"]
        API --> DSM["Duplicate Suppression Manager"]
        API --> EXP["Export Service (pandas + openpyxl)"]
        API --> DG["Demo Scenario Generator"]
        
        API --> CA["OpenCV Camera Adapter"]
        API --> YA["YOLOv8 Defect Adapter"]
        API --> OA["OCR Adapter (PaddleOCR / Tesseract)"]
    end

    subgraph Storage["Persistence & Storage Layer"]
        DB[("SQLite Local Repository (billetvision.db)")]
        IMG["Frames Directory (/data/images)"]
        EXPD["Reports Directory (/data/exports)"]
    end

    Backend --> Storage
    Frontend <-->|JSON REST & Proxied Static Assets| Backend
```

---

## ✨ Core Features & Functional Modules

### 1. Control-Room Industrial Design
* Dark graphite/navy aesthetic (`#0A0D14` / `#121722`), steel-grey surfaces, subtle borders, and restrained cyan accents.
* High-contrast status badges: **PASS** (Emerald Green), **FAIL** (Crimson Red), **REVIEW** (Amber).
* Live mill UTC clock, telemetry status bar, and collapsible left navigation.

### 2. Overview Dashboard
* Seven key performance indicators: **Inspected Count**, **PASS Count & Rate**, **FAIL Count**, **REVIEW Count**, **Avg Processing Latency**, **FPS**, and **OCR Validation Accuracy**.
* 100% computed dynamically from stored SQLite records — never hardcoded.
* Stacked daily inspection throughput chart and YOLO surface defect breakdown meter.
* Batch-level quality trends table and quick navigation to unresolved reviews.

### 3. Live Inspection & Viewport
* Real-time camera stream or synthetic 960x540 steel billet generator.
* Live optical overlays: Billet bounding box, conveyor line-crossing trigger line ($X=0.50$), calibrated dimensions, defect bounding boxes with confidence meters, and stamped stencil marking region.
* Real-time inspection summary panel with length, width, height (clearly marked unavailable without 3D depth sensor), OCR confidence, and exact compliance rule.
* Honest hardware disconnect state if no direct camera device is detected.

### 4. Dimensional Measurement & Calibration
* Reference gauge calibration: $\text{Scale} = \frac{\text{Known Physical Length (mm)}}{\text{Measured Pixel Distance (px)}}$.
* Configurable measurement plane: Top Surface Conveyor ($L \times W$) vs. Side Profile ($L \times H$).
* Optical homography perspective correction display with estimated measurement uncertainty ($\pm 2.5\text{ mm}$).

### 5. Marking OCR & Identity Traceability
* Industrial image preprocessing: Grayscale, bilateral smoothing, and Contrast Limited Adaptive Histogram Equalization (CLAHE) to extract faint, hot-rolled stamped numbers.
* Automated regex parsing for Heat Numbers (`HEAT-XXXX-X`) and Billet IDs (`BLT-XXXX-XXXX`).
* Low-confidence trigger ($< 70\%$): automatically marks billet as `REVIEW` to mandate operator confirmation.

### 6. Visible Surface Defect Inspection
* Supported surface classifications: **Corner Crack**, **Surface Inclusion**, **Rhomboidity**, **Longitudinal Crack**, **Severe Scale**, and **Bending Deformation**.
* Clear disclosure that subsurface and internal voids cannot be verified by standard RGB cameras and require Ultrasonic Testing (UT).

### 7. Quality Decision Engine
* Configurable manufacturing tolerance envelope: Target Length/Width with positive and negative limits in millimetres.
* Tri-state decision output:
  * **PASS**: All dimensions within tolerance, no disallowed surface defects, OCR confidence above threshold.
  * **FAIL**: Any dimension out-of-tolerance or confirmed critical surface defect.
  * **REVIEW**: Low OCR confidence, unreadable stencil, or borderline detection requiring human verification.
* Complete rule versioning recorded with every inspection.

### 8. Digital Billet Passport
* Searchable record with full physical dimensions, tolerance caliper deviation, raw OCR extraction, defect findings, and linked camera frame.
* Anti-overwrite pass history preserving repeated passes of the same billet.
* Complete operator review and correction audit trail with timestamps and inspector badge signatures.

### 9. Inspection History & Reporting
* Sortable, paginated table with multi-filter search: Billet ID, Heat Number, Batch ID, Status, Defect Class, and Date Range.
* Direct **CSV** and **XLSX** export powered by `pandas` and `openpyxl`, featuring detailed records and executive summary sheets.

### 10. Alerts & Review Queue
* Real-time visual alerts for out-of-tolerance dimensions, defects, and OCR ambiguity.
* Operator review modal supporting:
  * `CORRECT_ID`: Fixes misread heat numbers or billet IDs while preserving original OCR strings.
  * `RESOLVE`: Overrides status to PASS or FAIL with required engineering justification.
  * `CONFIRM`: Formally quarantine or scrap rejected billets.
  * `REINSPECT`: Flags billet for a secondary camera pass.

---

## 🚀 Quickstart Guide

### Prerequisites
* **Python**: Version 3.10+ (tested on Python 3.14)
* **Node.js**: Version 18+ (tested on Node v24)
* **OS**: Windows, macOS, or Linux

### 1. Backend Setup

```bash
# Navigate to the backend directory
cd backend

# Install dependencies
python -m pip install -r requirements.txt

# Start the FastAPI service
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
```
The backend API and Swagger UI will be available at:
* **Interactive Docs**: `http://127.0.0.1:8000/docs`
* **Health Endpoint**: `http://127.0.0.1:8000/api/health`

### 2. Frontend Setup

```bash
# Open a new terminal and navigate to frontend
cd frontend

# Install npm dependencies
npm install

# Start the Vite development server
npm run dev
```
The workstation interface will be accessible at:
* **Workstation UI**: `http://127.0.0.1:5173/`

---

## 🧪 Automated Testing

Automated unit and integration tests are provided in `backend/tests/`:

```bash
# Run pytest test suite from project root
python -m pytest backend/tests -v
```

### Test Coverage:
1. `test_quality_engine.py`: Tolerance decision boundaries, upper/lower limits, defect rejections, and review rule precedence.
2. `test_duplicate_suppression.py`: Line-crossing trigger events and time-based duplicate suppression windows.
3. `test_persistence.py`: SQLite table initialization, CRUD operations, and auditable correction event trails.
4. `test_ocr_review_rules.py`: Heat/Billet regex extraction and low-confidence review triggers.
5. `test_export.py`: Multi-sheet Excel workbook generation and CSV integrity with pandas and openpyxl.

---

## 🎯 Demo Mode Scenarios

When physical industrial cameras or trained YOLO weights are not connected, **Demo Mode** allows testing:

| Scenario | Title | Description | Expected Decision |
|---|---|---|---|
| **1** | **Within Tolerance** | Length 12005.0 mm, Width 150.2 mm, clear stencil marking (`HEAT-8492-B`), OCR 96% conf, no defects. | **PASS** |
| **2** | **Out of Tolerance & Defect** | Length 12118.0 mm (+118 mm exceeds +50 mm tolerance), critical corner crack defect detected. | **FAIL** |
| **3** | **Unreadable Identifier** | Stencil marking oxidized and degraded, OCR confidence 48% (< 70% threshold). | **REVIEW** |

Click any of the **Trigger Scenario** buttons in the Live Inspection view to execute the scenario and observe real-time telemetry, alerts, and SQLite persistence.

---

## 📦 Data Export Format

Reports can be exported on-demand via the Inspection History view:
* **CSV Export**: `GET /api/export/csv` (RFC 4180 compliant, UTF-8 BOM for Excel compatibility)
* **Excel Export**: `GET /api/export/xlsx` with two sheets:
  1. `Inspection Records`: Tabular log of all filtered inspections.
  2. `Executive Summary`: High-level summary of total inspected, pass rates, average dimensions, and generation metadata.

---

## 🛡️ Industrial Safety Notice

BilletVision AI operates as an advisory quality inspection system. Rejection kickers, roller table divergence arms, and hot-billet sorting mechanisms must be physically interlocked with certified hardware safety relays and PLC limits.
