import {
  BilletInspection,
  BilletInspectionCreate,
  CorrectionRequest,
  ToleranceConfig,
  CalibrationConfig,
  AlertItem,
  SystemStatus,
  OverviewData,
  QualityAnalytics,
  AuditLogItem
} from '../types';

const API_BASE = '/api';

class ApiService {
  private async request<T>(endpoint: string, options?: RequestInit): Promise<T> {
    const res = await fetch(`${API_BASE}${endpoint}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(options?.headers || {})
      }
    });

    if (!res.ok) {
      let errorMsg = `API Error ${res.status}: ${res.statusText}`;
      try {
        const errorJson = await res.json();
        if (errorJson.detail) errorMsg = errorJson.detail;
      } catch {
        // ignore fallback
      }
      throw new Error(errorMsg);
    }

    return res.json();
  }

  async getHealth() {
    return this.request<{ status: string; timestamp: string }>('/health');
  }

  async getSystemStatus(): Promise<SystemStatus> {
    return this.request<SystemStatus>('/status');
  }

  async setOperatingMode(mode: 'DEMO' | 'LIVE'): Promise<{ active_mode: 'DEMO' | 'LIVE'; warning?: string }> {
    return this.request(`/status/mode?mode=${mode}`, { method: 'POST' });
  }

  async getOverview(): Promise<OverviewData> {
    return this.request<OverviewData>('/overview');
  }

  async listInspections(params: {
    search?: string;
    status?: string;
    defect_class?: string;
    date_from?: string;
    date_to?: string;
    source_mode?: string;
    page?: number;
    page_size?: number;
  }): Promise<{ items: BilletInspection[]; total: number; page: number; total_pages: number }> {
    const query = new URLSearchParams();
    if (params.search) query.append('search', params.search);
    if (params.status && params.status !== 'ALL') query.append('status', params.status);
    if (params.defect_class && params.defect_class !== 'ALL') query.append('defect_class', params.defect_class);
    if (params.date_from) query.append('date_from', params.date_from);
    if (params.date_to) query.append('date_to', params.date_to);
    if (params.source_mode && params.source_mode !== 'ALL') query.append('source_mode', params.source_mode);
    if (params.page) query.append('page', params.page.toString());
    if (params.page_size) query.append('page_size', params.page_size.toString());

    return this.request(`/inspections?${query.toString()}`);
  }

  async getInspection(inspectionId: string): Promise<BilletInspection> {
    return this.request<BilletInspection>(`/inspections/${inspectionId}`);
  }

  async getInspectionsForBillet(billetId: string): Promise<BilletInspection[]> {
    return this.request<BilletInspection[]>(`/inspections/billet/${billetId}`);
  }

  async createInspection(payload: BilletInspectionCreate): Promise<BilletInspection> {
    return this.request<BilletInspection>('/inspections', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  }

  async submitReview(inspectionId: string, payload: CorrectionRequest): Promise<BilletInspection> {
    return this.request<BilletInspection>(`/inspections/${inspectionId}/review`, {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  }

  async runDemoScenario(scenarioId: number): Promise<{ scenario_name: string; inspection: BilletInspection; alert?: AlertItem }> {
    return this.request(`/demo/run-scenario/${scenarioId}`, {
      method: 'POST'
    });
  }

  async seedDemoData(): Promise<{ message: string }> {
    return this.request('/demo/seed', { method: 'POST' });
  }

  async getAlerts(limit: number = 50, unackOnly: boolean = false): Promise<AlertItem[]> {
    return this.request<AlertItem[]>(`/alerts?limit=${limit}&unack_only=${unackOnly}`);
  }

  async acknowledgeAlert(alertId: string, operator: string = 'OPERATOR'): Promise<{ message: string }> {
    return this.request(`/alerts/${alertId}/acknowledge?operator=${encodeURIComponent(operator)}`, {
      method: 'POST'
    });
  }

  async getAnalytics(): Promise<QualityAnalytics> {
    return this.request<QualityAnalytics>('/analytics');
  }

  async getCalibration(): Promise<CalibrationConfig> {
    return this.request<CalibrationConfig>('/calibration');
  }

  async updateCalibration(config: CalibrationConfig, operator: string = 'OPERATOR'): Promise<CalibrationConfig> {
    return this.request<CalibrationConfig>(`/calibration?operator=${encodeURIComponent(operator)}`, {
      method: 'POST',
      body: JSON.stringify(config)
    });
  }

  async getTolerances(): Promise<ToleranceConfig> {
    return this.request<ToleranceConfig>('/tolerances');
  }

  async updateTolerances(config: ToleranceConfig, operator: string = 'OPERATOR'): Promise<ToleranceConfig> {
    return this.request<ToleranceConfig>(`/tolerances?operator=${encodeURIComponent(operator)}`, {
      method: 'POST',
      body: JSON.stringify(config)
    });
  }

  async getAuditLogs(limit: number = 50): Promise<AuditLogItem[]> {
    return this.request<AuditLogItem[]>(`/audit-logs?limit=${limit}`);
  }

  getExportCsvUrl(params: { search?: string; status?: string; defect_class?: string; date_from?: string; date_to?: string }): string {
    const q = new URLSearchParams();
    if (params.search) q.append('search', params.search);
    if (params.status && params.status !== 'ALL') q.append('status', params.status);
    if (params.defect_class && params.defect_class !== 'ALL') q.append('defect_class', params.defect_class);
    if (params.date_from) q.append('date_from', params.date_from);
    if (params.date_to) q.append('date_to', params.date_to);
    return `${API_BASE}/export/csv?${q.toString()}`;
  }

  getExportXlsxUrl(params: { search?: string; status?: string; defect_class?: string; date_from?: string; date_to?: string }): string {
    const q = new URLSearchParams();
    if (params.search) q.append('search', params.search);
    if (params.status && params.status !== 'ALL') q.append('status', params.status);
    if (params.defect_class && params.defect_class !== 'ALL') q.append('defect_class', params.defect_class);
    if (params.date_from) q.append('date_from', params.date_from);
    if (params.date_to) q.append('date_to', params.date_to);
    return `${API_BASE}/export/xlsx?${q.toString()}`;
  }

  async uploadImage(formData: FormData): Promise<BilletInspection> {
    const res = await fetch(`${API_BASE}/upload/image`, {
      method: 'POST',
      body: formData
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: 'Upload failed' }));
      throw new Error(err.detail || 'Upload failed');
    }
    return res.json();
  }
}

export const api = new ApiService();
