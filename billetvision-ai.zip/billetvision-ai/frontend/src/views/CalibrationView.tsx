import React, { useState, useEffect } from 'react';
import {
  Sliders,
  Ruler,
  Info
} from 'lucide-react';
import { CalibrationConfig } from '../types';
import { api } from '../services/api';

export const CalibrationView: React.FC = () => {
  const [config, setConfig] = useState<CalibrationConfig | null>(null);
  const [knownLength, setKnownLength] = useState<number>(1000.0);
  const [pixelDistance, setPixelDistance] = useState<number>(500.0);
  const [measurementPlane, setMeasurementPlane] = useState<'TOP_SURFACE_CONVEYOR' | 'SIDE_PROFILE'>('TOP_SURFACE_CONVEYOR');
  const [cameraDistance, setCameraDistance] = useState<number>(2400.0);
  const [uncertainty, setUncertainty] = useState<number>(2.5);
  const [isCalibrated, setIsCalibrated] = useState<boolean>(true);
  const [operator, setOperator] = useState<string>('Metrology Lead #01');
  const [notes, setNotes] = useState<string>('Calibrated with certified 1000mm steel gauge bar');

  const [saving, setSaving] = useState<boolean>(false);
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    const fetchCalibration = async () => {
      try {
        const cal = await api.getCalibration();
        setConfig(cal);
        setKnownLength(cal.known_reference_length_mm);
        setPixelDistance(cal.pixel_distance_px);
        setMeasurementPlane(cal.measurement_plane);
        setCameraDistance(cal.camera_distance_mm);
        setUncertainty(cal.estimated_uncertainty_mm);
        setIsCalibrated(cal.is_calibrated);
        setNotes(cal.notes);
      } catch (err) {
        console.error(err);
      }
    };
    fetchCalibration();
  }, []);

  const calculatedScale = pixelDistance > 0 ? (knownLength / pixelDistance).toFixed(4) : '0.0000';

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setMessage(null);
    try {
      const updated: CalibrationConfig = {
        calibration_id: config?.calibration_id || 'CAL-STD-01',
        known_reference_length_mm: knownLength,
        pixel_distance_px: pixelDistance,
        scale_mm_per_px: Number(calculatedScale),
        measurement_plane: measurementPlane,
        is_calibrated: isCalibrated,
        camera_distance_mm: cameraDistance,
        calibration_timestamp: new Date().toISOString(),
        estimated_uncertainty_mm: uncertainty,
        notes: notes
      };
      await api.updateCalibration(updated, operator);
      setConfig(updated);
      setMessage('Calibration updated successfully and logged in system audit trail.');
    } catch (err: any) {
      setMessage(`Error saving calibration: ${err.message}`);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h2 className="text-sm font-bold text-slate-100 uppercase tracking-wider m-0 flex items-center gap-2">
          <Sliders className="text-cyan-400" size={18} />
          Optical Dimension Measurement Calibration
        </h2>
        <p className="text-[11px] text-slate-500 mt-0.5">
          Configure reference gauge standards, pixel-to-millimetre scale transformations, and geometric planes
        </p>
      </div>

      {/* Honesty & Metrology Notice */}
      <div className="p-3.5 bg-slate-900 border border-cyan-500/30 rounded text-xs text-slate-300 flex items-start gap-2.5">
        <Info size={16} className="text-cyan-400 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <span className="font-bold uppercase tracking-wider block text-[11px] text-cyan-300">
            Metrology Standards & Limitation Disclosure
          </span>
          <p className="text-[11px] text-slate-400 leading-relaxed">
            Length and width are calculated via 2D overhead camera projection at the calibrated conveyor plane.
            Height (depth) measurement is physically unavailable without dedicated stereoscopic triangulation or laser line profilers.
            Do not certify sub-millimetre tolerances without physical gauge verification.
          </p>
        </div>
      </div>

      {message && (
        <div className="p-3 bg-emerald-950/40 border border-emerald-500/40 rounded text-xs text-emerald-300">
          {message}
        </div>
      )}

      <form onSubmit={handleSave} className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Calibration Inputs (7 Cols) */}
        <div className="lg:col-span-7 bg-[#121722] border border-[#1e2638] rounded-md p-6 space-y-4 shadow-xl text-xs">
          <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider m-0 pb-2 border-b border-slate-800">
            Physical Reference Parameters
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-slate-400 font-semibold mb-1">
                Known Reference Gauge Length (mm)
              </label>
              <input
                type="number"
                step="0.1"
                value={knownLength}
                onChange={(e) => setKnownLength(Number(e.target.value))}
                className="w-full px-3 py-2 bg-[#0e141f] border border-slate-700 rounded text-slate-100 font-mono focus:border-cyan-400 focus:outline-none"
                required
              />
              <span className="text-[10px] text-slate-500">Certified steel calibration block length</span>
            </div>

            <div>
              <label className="block text-slate-400 font-semibold mb-1">
                Measured Image Pixel Distance (px)
              </label>
              <input
                type="number"
                step="0.5"
                value={pixelDistance}
                onChange={(e) => setPixelDistance(Number(e.target.value))}
                className="w-full px-3 py-2 bg-[#0e141f] border border-slate-700 rounded text-slate-100 font-mono focus:border-cyan-400 focus:outline-none"
                required
              />
              <span className="text-[10px] text-slate-500">Pixel span on camera sensor matrix</span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div>
              <label className="block text-slate-400 font-semibold mb-1">
                Measurement Plane
              </label>
              <select
                value={measurementPlane}
                onChange={(e: any) => setMeasurementPlane(e.target.value)}
                className="w-full px-3 py-2 bg-[#0e141f] border border-slate-700 rounded text-slate-200 focus:border-cyan-400 focus:outline-none"
              >
                <option value="TOP_SURFACE_CONVEYOR">Top Surface Conveyor (Length & Width)</option>
                <option value="SIDE_PROFILE">Side Profile (Length & Height)</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-400 font-semibold mb-1">
                Camera Optical Distance (mm)
              </label>
              <input
                type="number"
                value={cameraDistance}
                onChange={(e) => setCameraDistance(Number(e.target.value))}
                className="w-full px-3 py-2 bg-[#0e141f] border border-slate-700 rounded text-slate-100 font-mono focus:border-cyan-400 focus:outline-none"
              />
              <span className="text-[10px] text-slate-500">Standoff distance from lens to conveyor surface</span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div>
              <label className="block text-slate-400 font-semibold mb-1">
                Estimated Measurement Uncertainty (± mm)
              </label>
              <input
                type="number"
                step="0.1"
                value={uncertainty}
                onChange={(e) => setUncertainty(Number(e.target.value))}
                className="w-full px-3 py-2 bg-[#0e141f] border border-slate-700 rounded text-slate-100 font-mono focus:border-cyan-400 focus:outline-none"
              />
              <span className="text-[10px] text-slate-500">Derived from sensor resolution & lens distortion</span>
            </div>

            <div className="flex items-center gap-3 pt-6">
              <input
                type="checkbox"
                id="isCalibratedCheckbox"
                checked={isCalibrated}
                onChange={(e) => setIsCalibrated(e.target.checked)}
                className="w-4 h-4 rounded bg-[#0e141f] border-slate-700 text-cyan-500 focus:ring-0"
              />
              <label htmlFor="isCalibratedCheckbox" className="text-slate-300 font-semibold cursor-pointer">
                Certification Valid & Active
              </label>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-800 space-y-3">
            <div>
              <label className="block text-slate-400 font-semibold mb-1">
                Certified Metrology Inspector Name
              </label>
              <input
                type="text"
                value={operator}
                onChange={(e) => setOperator(e.target.value)}
                className="w-full px-3 py-2 bg-[#0e141f] border border-slate-700 rounded text-slate-100 focus:border-cyan-400 focus:outline-none"
                required
              />
            </div>
            <div>
              <label className="block text-slate-400 font-semibold mb-1">
                Calibration Notes & Artifact Reference
              </label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={2}
                className="w-full px-3 py-2 bg-[#0e141f] border border-slate-700 rounded text-slate-100 focus:border-cyan-400 focus:outline-none resize-none"
              />
            </div>
          </div>

          <div className="pt-3 flex justify-end">
            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-cyan-950 font-bold rounded uppercase tracking-wider text-xs transition-colors"
            >
              {saving ? 'Validating & Storing...' : 'Save & Certify Calibration'}
            </button>
          </div>
        </div>

        {/* Right Transformation Display (5 Cols) */}
        <div className="lg:col-span-5 space-y-6">
          {/* Computed Scale Readout */}
          <div className="bg-[#121722] border border-cyan-500/30 rounded-md p-6 space-y-4 shadow-xl">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400">
                  Computed Calibration Ratio
                </span>
                <div className="text-3xl font-extrabold font-mono text-cyan-400 mt-1">
                  {calculatedScale} <span className="text-sm font-normal text-slate-400">mm / px</span>
                </div>
              </div>
              <div className="p-2.5 rounded bg-cyan-950/60 border border-cyan-500/40 text-cyan-400">
                <Ruler size={24} />
              </div>
            </div>

            <div className="p-3 bg-[#0e141f] border border-slate-800 rounded font-mono text-xs space-y-1.5">
              <div className="flex justify-between text-slate-400">
                <span>Formula:</span>
                <span className="text-slate-200">Scale = Known_mm / Measured_px</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Calculation:</span>
                <span className="text-slate-200">{knownLength} mm ÷ {pixelDistance} px</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Uncertainty Margin:</span>
                <span className="text-emerald-400">±{uncertainty} mm</span>
              </div>
            </div>
          </div>

          {/* Perspective Correction Grid Mock */}
          <div className="bg-[#121722] border border-[#1e2638] rounded-md p-5 space-y-3 shadow-xl">
            <div className="flex justify-between items-center">
              <span className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                Optical Homography / Perspective Matrix
              </span>
              <span className="text-[10px] font-mono text-emerald-400">HOMOGRAPHY 3x3 OK</span>
            </div>
            
            <div className="aspect-video bg-[#0a0d14] rounded border border-slate-800 flex items-center justify-center relative p-3">
              {/* Virtual Conveyor Wireframe Grid */}
              <div className="w-full h-full border border-cyan-500/20 grid grid-cols-6 grid-rows-4 rounded">
                {Array.from({ length: 24 }).map((_, i) => (
                  <div key={i} className="border border-cyan-500/10" />
                ))}
              </div>
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <span className="px-3 py-1 bg-black/80 rounded text-[11px] font-mono text-cyan-300 border border-cyan-500/40">
                  Orthogonal Conveyor Plane Corrected
                </span>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
};
