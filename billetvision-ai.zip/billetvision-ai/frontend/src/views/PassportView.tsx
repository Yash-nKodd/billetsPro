import React, { useState, useEffect } from 'react';
import {
  Search,
  QrCode,
  Ruler,
  ScanText,
  AlertTriangle,
  History,
  Edit3,
  FileCheck
} from 'lucide-react';
import { BilletInspection, ReviewAction } from '../types';
import { api } from '../services/api';
import { StatusBadge } from '../components/common/StatusBadge';
import { ReviewModal } from '../components/modals/ReviewModal';

interface PassportViewProps {
  selectedInspection: BilletInspection | null;
  onSubmitReview: (
    inspectionId: string,
    action: ReviewAction,
    operator: string,
    notes: string,
    correctedBilletId?: string,
    correctedHeatNumber?: string,
    resolvedStatus?: 'PASS' | 'FAIL'
  ) => Promise<void>;
  onSelectInspection: (inspection: BilletInspection) => void;
}

export const PassportView: React.FC<PassportViewProps> = ({
  selectedInspection,
  onSubmitReview,
  onSelectInspection
}) => {
  const [searchInput, setSearchInput] = useState<string>('');
  const [currentInspection, setCurrentInspection] = useState<BilletInspection | null>(selectedInspection);
  const [billetHistory, setBilletHistory] = useState<BilletInspection[]>([]);
  const [isReviewModalOpen, setIsReviewModalOpen] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const [searchError, setSearchError] = useState<string | null>(null);

  useEffect(() => {
    if (selectedInspection) {
      setCurrentInspection(selectedInspection);
      loadBilletHistory(selectedInspection.billet_id);
    }
  }, [selectedInspection]);

  const loadBilletHistory = async (billetId: string) => {
    try {
      const history = await api.getInspectionsForBillet(billetId);
      setBilletHistory(history);
    } catch {
      // ignore
    }
  };

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchInput.trim()) return;
    setLoading(true);
    setSearchError(null);
    try {
      const res = await api.listInspections({ search: searchInput.trim(), page_size: 1 });
      if (res.items && res.items.length > 0) {
        const item = res.items[0];
        setCurrentInspection(item);
        loadBilletHistory(item.billet_id);
      } else {
        setSearchError(`No passport found for query "${searchInput}"`);
      }
    } catch (err: any) {
      setSearchError(err.message || 'Search error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Lookup Bar */}
      <div className="bg-[#121722] border border-[#1e2638] rounded-md p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-sm font-bold text-slate-100 uppercase tracking-wider m-0 flex items-center gap-2">
            <QrCode className="text-cyan-400" size={18} />
            Digital Billet Traceability Passport
          </h2>
          <p className="text-[11px] text-slate-500 mt-0.5">
            Cryptographically auditable pedigree, physical tolerances, and thermal heat record
          </p>
        </div>

        <form onSubmit={handleSearch} className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-3 top-2.5 text-slate-500" size={14} />
            <input
              type="text"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="Lookup Billet ID or Heat Number..."
              className="pl-9 pr-3 py-1.5 bg-[#0e141f] border border-slate-700 rounded text-xs text-slate-100 focus:border-cyan-400 focus:outline-none w-64"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="px-3.5 py-1.5 bg-cyan-500 hover:bg-cyan-400 text-cyan-950 font-bold rounded text-xs uppercase tracking-wider transition-colors"
          >
            {loading ? 'Searching...' : 'Lookup'}
          </button>
        </form>
      </div>

      {searchError && (
        <div className="p-3 bg-rose-950/40 border border-rose-500/40 rounded text-xs text-rose-300">
          {searchError}
        </div>
      )}

      {currentInspection ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Main Passport Document (8 Cols) */}
          <div className="lg:col-span-8 bg-[#121722] border border-[#1e2638] rounded-md p-6 space-y-6 shadow-xl relative">
            {/* Header / Certificate Banner */}
            <div className="border-b border-slate-800 pb-5 flex flex-wrap items-start justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-xs uppercase font-mono px-2 py-0.5 rounded bg-cyan-950/60 text-cyan-400 border border-cyan-800">
                    Official Mill Record
                  </span>
                  <span className="text-xs font-mono text-slate-400">
                    Conf Version: {currentInspection.configuration_version}
                  </span>
                </div>
                <h1 className="text-2xl font-bold font-mono text-slate-100 m-0">
                  {currentInspection.billet_id}
                </h1>
                <div className="flex items-center gap-3 text-xs text-slate-400 mt-1 font-mono">
                  <span>Inspection ID: {currentInspection.inspection_id}</span>
                  <span>•</span>
                  <span>Timestamp: {currentInspection.timestamp.replace('T', ' ').substring(0, 19)} UTC</span>
                </div>
              </div>

              <div className="flex flex-col items-end gap-2">
                <StatusBadge status={currentInspection.status} size="lg" />
                <button
                  onClick={() => setIsReviewModalOpen(true)}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-cyan-300 text-xs font-semibold rounded border border-slate-700 flex items-center gap-1.5 transition-colors"
                >
                  <Edit3 size={13} /> Operator Review / Edit
                </button>
              </div>
            </div>

            {/* Quality Reason / Decision Box */}
            <div
              className={`p-3.5 rounded border text-xs leading-relaxed ${
                currentInspection.status === 'PASS'
                  ? 'bg-emerald-950/15 border-emerald-500/30 text-emerald-300'
                  : currentInspection.status === 'FAIL'
                  ? 'bg-rose-950/15 border-rose-500/30 text-rose-300'
                  : 'bg-amber-950/15 border-amber-500/30 text-amber-300'
              }`}
            >
              <div className="font-bold uppercase tracking-wider text-[11px] mb-1">
                Evaluation Statement & Manufacturing Compliance
              </div>
              {currentInspection.reason}
            </div>

            {/* Dimensional Tolerance Caliper & Verification */}
            <div className="space-y-3">
              <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider m-0 flex items-center gap-2">
                <Ruler size={16} className="text-cyan-400" /> Physical Dimension Verifications
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Length Card */}
                <div className="p-4 bg-[#0e141f] border border-slate-800 rounded space-y-2">
                  <div className="flex justify-between items-baseline">
                    <span className="text-xs text-slate-400 font-semibold uppercase">Calibrated Length</span>
                    <span className="text-lg font-mono font-bold text-slate-100">
                      {currentInspection.length_mm} mm
                    </span>
                  </div>
                  <div className="flex justify-between text-[11px] text-slate-500 font-mono">
                    <span>Target: 12000.0 mm</span>
                    <span>Range: [11970.0 — 12050.0] mm</span>
                  </div>
                  <div className="flex justify-between text-[11px] text-slate-400 font-mono pt-1 border-t border-slate-800/80">
                    <span>Deviation: {(currentInspection.length_mm - 12000.0).toFixed(1)} mm</span>
                    <span className="text-cyan-400">Uncertainty: ±2.5 mm</span>
                  </div>
                </div>

                {/* Width Card */}
                <div className="p-4 bg-[#0e141f] border border-slate-800 rounded space-y-2">
                  <div className="flex justify-between items-baseline">
                    <span className="text-xs text-slate-400 font-semibold uppercase">Calibrated Width</span>
                    <span className="text-lg font-mono font-bold text-slate-100">
                      {currentInspection.width_mm} mm
                    </span>
                  </div>
                  <div className="flex justify-between text-[11px] text-slate-500 font-mono">
                    <span>Target: 150.0 mm</span>
                    <span>Range: [147.0 — 153.0] mm</span>
                  </div>
                  <div className="flex justify-between text-[11px] text-slate-400 font-mono pt-1 border-t border-slate-800/80">
                    <span>Deviation: {(currentInspection.width_mm - 150.0).toFixed(1)} mm</span>
                    <span className="text-cyan-400">Uncertainty: ±2.5 mm</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Optical Markings & Traceability Tags */}
            <div className="space-y-3">
              <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider m-0 flex items-center gap-2">
                <ScanText size={16} className="text-cyan-400" /> Steel Marking & Metallurgical Traceability
              </h3>

              <div className="p-4 bg-[#0e141f] border border-slate-800 rounded space-y-3 text-xs">
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  <div>
                    <span className="text-slate-500 block text-[11px]">Heat Number</span>
                    <span className="font-mono font-bold text-cyan-300 text-sm">
                      {currentInspection.heat_number}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[11px]">Batch ID</span>
                    <span className="font-mono font-bold text-slate-200 text-sm">
                      {currentInspection.batch_id}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[11px]">OCR Confidence</span>
                    <span
                      className={`font-mono font-bold text-sm ${
                        currentInspection.ocr_confidence >= 0.7 ? 'text-emerald-400' : 'text-amber-400'
                      }`}
                    >
                      {Math.round(currentInspection.ocr_confidence * 100)}%
                    </span>
                  </div>
                </div>

                <div>
                  <span className="text-slate-500 block text-[11px] mb-1">OCR Stencil Raw Extraction</span>
                  <div className="font-mono bg-[#141a27] p-2.5 rounded border border-slate-800 text-slate-200">
                    "{currentInspection.ocr_raw_text || 'NO MARKING DETECTED'}"
                  </div>
                </div>
              </div>
            </div>

            {/* Surface Defect Observations */}
            <div className="space-y-3">
              <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider m-0 flex items-center gap-2">
                <AlertTriangle size={16} className="text-rose-400" /> Optical Surface Defect Observations
              </h3>

              {currentInspection.defect_results.length === 0 ? (
                <div className="p-4 bg-[#0e141f] border border-slate-800 rounded text-xs text-emerald-400 flex items-center gap-2">
                  <FileCheck size={16} /> Billet passed full optical surface defect scanning with zero anomalous indications.
                </div>
              ) : (
                <div className="space-y-2">
                  {currentInspection.defect_results.map((d, i: number) => (
                    <div
                      key={i}
                      className="p-3 bg-rose-950/20 border border-rose-500/30 rounded flex items-center justify-between text-xs"
                    >
                      <div>
                        <div className="font-mono font-bold text-rose-300 uppercase">
                          {d.defect_class.replace('_', ' ')}
                        </div>
                        <div className="text-[11px] text-slate-400">{d.description}</div>
                      </div>
                      <div className="text-right">
                        <span className="px-2 py-0.5 rounded bg-rose-500/20 text-rose-400 font-mono text-[11px] font-bold">
                          {d.severity} • {Math.round(d.confidence * 100)}%
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Audit Trail & Operator Correction History */}
            <div className="space-y-3 pt-2 border-t border-slate-800">
              <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider m-0 flex items-center gap-2">
                <History size={16} className="text-cyan-400" /> Operator Review & Change Audit Trail
              </h3>

              {currentInspection.review_audit_events.length === 0 ? (
                <div className="p-3 bg-[#0e141f] border border-slate-800 rounded text-xs text-slate-500">
                  No manual operator corrections or overrides recorded for this inspection record.
                </div>
              ) : (
                <div className="space-y-2">
                  {currentInspection.review_audit_events.map((evt, i: number) => (
                    <div
                      key={i}
                      className="p-3 bg-[#0e141f] border border-cyan-500/20 rounded text-xs space-y-1 font-mono"
                    >
                      <div className="flex items-center justify-between text-slate-300">
                        <span className="font-bold text-cyan-400">
                          {evt.action} by {evt.operator}
                        </span>
                        <span className="text-[11px] text-slate-500">
                          {evt.timestamp.replace('T', ' ').substring(0, 19)}
                        </span>
                      </div>
                      <div className="text-slate-400 font-sans text-[11px]">{evt.notes}</div>
                      {evt.new_val && (
                        <div className="text-[10px] text-slate-500 pt-0.5">
                          Audit state transition: {evt.new_val}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Frame Image & Inspection Timeline (4 Cols) */}
          <div className="lg:col-span-4 space-y-6">
            {/* Inspection Frame Preview */}
            <div className="bg-[#121722] border border-[#1e2638] rounded-md p-4 space-y-3 shadow-xl">
              <span className="text-xs font-bold text-slate-200 uppercase tracking-wider block">
                Visual Inspection Frame
              </span>
              {currentInspection.frame_reference ? (
                <div className="aspect-video bg-[#0a0d14] rounded border border-slate-800 overflow-hidden relative">
                  <img
                    src={currentInspection.frame_reference}
                    alt="Billet inspection frame"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-2 right-2 px-1.5 py-0.5 bg-black/70 rounded text-[10px] font-mono text-cyan-400">
                    CALIBRATED 2D
                  </div>
                </div>
              ) : (
                <div className="aspect-video bg-[#0a0d14] rounded border border-slate-800 flex items-center justify-center text-xs text-slate-500">
                  No visual frame reference attached.
                </div>
              )}
              <div className="text-[11px] text-slate-500 font-mono">
                Storage: SQLite BLOB/Ref • Immutable Hash
              </div>
            </div>

            {/* Billet Inspection Timeline / Anti-Overwrite History */}
            <div className="bg-[#121722] border border-[#1e2638] rounded-md p-4 space-y-3 shadow-xl">
              <span className="text-xs font-bold text-slate-200 uppercase tracking-wider block">
                Billet Pass History ({billetHistory.length})
              </span>
              <p className="text-[11px] text-slate-500">
                All camera passes for this billet are preserved independently to prevent record overwriting.
              </p>

              <div className="divide-y divide-slate-800/60 font-mono text-xs">
                {billetHistory.map((h) => (
                  <div
                    key={h.inspection_id}
                    onClick={() => onSelectInspection(h)}
                    className="py-2.5 flex items-center justify-between cursor-pointer hover:bg-[#161d2b] px-2 rounded transition-colors"
                  >
                    <div>
                      <div className="font-semibold text-slate-300">{h.inspection_id}</div>
                      <div className="text-[10px] text-slate-500">
                        {h.timestamp.substring(11, 19)} UTC • {h.length_mm}mm
                      </div>
                    </div>
                    <StatusBadge status={h.status} size="sm" />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="p-12 text-center text-slate-500 text-xs">
          Select an inspection record from the History table or search by Billet ID above.
        </div>
      )}

      {/* Review Modal */}
      {currentInspection && (
        <ReviewModal
          inspection={currentInspection}
          isOpen={isReviewModalOpen}
          onClose={() => setIsReviewModalOpen(false)}
          onSubmitReview={async (id: string, action: ReviewAction, op: string, notes: string, cb?: string, ch?: string, rs?: 'PASS' | 'FAIL') => {
            await onSubmitReview(id, action, op, notes, cb, ch, rs);
            // Refresh
            setCurrentInspection({
              ...currentInspection,
              billet_id: cb || currentInspection.billet_id,
              heat_number: ch || currentInspection.heat_number,
              status: rs || currentInspection.status
            });
            loadBilletHistory(cb || currentInspection.billet_id);
          }}
        />
      )}
    </div>
  );
};
