import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  Square,
  Upload,
  Sparkles,
  Camera,
  CheckCircle2,
  VideoOff,
  Edit3
} from 'lucide-react';
import { BilletInspection, SystemStatus, ReviewAction } from '../types';
import { StatusBadge } from '../components/common/StatusBadge';
import { ReviewModal } from '../components/modals/ReviewModal';

interface LiveInspectionViewProps {
  systemStatus: SystemStatus | null;
  onRunDemoScenario: (id: number) => Promise<BilletInspection>;
  onUploadImage: (file: File) => Promise<BilletInspection>;
  onSubmitReview: (
    inspectionId: string,
    action: ReviewAction,
    operator: string,
    notes: string,
    correctedBilletId?: string,
    correctedHeatNumber?: string,
    resolvedStatus?: 'PASS' | 'FAIL'
  ) => Promise<void>;
  latestInspection: BilletInspection | null;
}

export const LiveInspectionView: React.FC<LiveInspectionViewProps> = ({
  systemStatus,
  onRunDemoScenario,
  onUploadImage,
  onSubmitReview,
  latestInspection
}) => {
  const [isRunning, setIsRunning] = useState<boolean>(true);
  const [activeSource, setActiveSource] = useState<'DEMO' | 'CAMERA' | 'UPLOAD'>('DEMO');
  const [currentInspection, setCurrentInspection] = useState<BilletInspection | null>(latestInspection);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [isReviewModalOpen, setIsReviewModalOpen] = useState<boolean>(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (latestInspection) {
      setCurrentInspection(latestInspection);
    }
  }, [latestInspection]);

  const handleRunScenario = async (id: number) => {
    setIsProcessing(true);
    try {
      const result = await onRunDemoScenario(id);
      setCurrentInspection(result);
    } catch (e: any) {
      console.error(e);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setIsProcessing(true);
      setUploadError(null);
      try {
        const result = await onUploadImage(file);
        setCurrentInspection(result);
        setActiveSource('UPLOAD');
      } catch (err: any) {
        setUploadError(err.message || 'Error processing uploaded file');
      } finally {
        setIsProcessing(false);
      }
    }
  };

  const isCamConnected = systemStatus?.camera_available || false;

  return (
    <div className="p-6 space-y-4">
      {/* Control Strip & Demo Scenario Quick-Bar */}
      <div className="bg-[#121722] border border-[#1e2638] rounded-md p-3.5 flex flex-wrap items-center justify-between gap-4">
        {/* Source Selectors & Transport Controls */}
        <div className="flex items-center gap-2">
          {/* Source Tabs */}
          <div className="flex bg-[#0e141f] border border-slate-800 rounded p-0.5 text-xs font-semibold">
            <button
              onClick={() => setActiveSource('DEMO')}
              className={`px-3 py-1.5 rounded uppercase tracking-wider flex items-center gap-1.5 transition-colors ${
                activeSource === 'DEMO'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Sparkles size={13} /> Demo Stream
            </button>
            <button
              onClick={() => setActiveSource('CAMERA')}
              className={`px-3 py-1.5 rounded uppercase tracking-wider flex items-center gap-1.5 transition-colors ${
                activeSource === 'CAMERA'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Camera size={13} /> Live Camera
            </button>
            <button
              onClick={() => fileInputRef.current?.click()}
              className={`px-3 py-1.5 rounded uppercase tracking-wider flex items-center gap-1.5 transition-colors ${
                activeSource === 'UPLOAD'
                  ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Upload size={13} /> Upload File
            </button>
          </div>

          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept="image/*,video/*"
            className="hidden"
          />

          {/* Transport Controls */}
          <div className="flex items-center gap-1 border-l border-slate-800 pl-3">
            <button
              onClick={() => setIsRunning(!isRunning)}
              className={`p-2 rounded transition-colors ${
                isRunning
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30'
                  : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30'
              }`}
              title={isRunning ? 'Pause Inspection Feed' : 'Start Inspection Feed'}
            >
              {isRunning ? <Pause size={15} /> : <Play size={15} />}
            </button>
            <button
              onClick={() => setIsRunning(false)}
              className="p-2 rounded bg-slate-800 text-slate-400 hover:text-rose-400 hover:bg-slate-700 transition-colors"
              title="Stop Inspection"
            >
              <Square size={15} />
            </button>
          </div>
        </div>

        {/* Demo Scenarios Quick Triggers */}
        <div className="flex items-center gap-2">
          <span className="text-[11px] uppercase tracking-wider text-slate-400 font-bold hidden xl:inline">
            Trigger Scenario:
          </span>
          <button
            onClick={() => handleRunScenario(1)}
            disabled={isProcessing}
            className="px-2.5 py-1.5 text-xs font-semibold rounded bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 border border-emerald-500/30 uppercase tracking-wide transition-colors"
          >
            1: PASS (Nominal)
          </button>
          <button
            onClick={() => handleRunScenario(2)}
            disabled={isProcessing}
            className="px-2.5 py-1.5 text-xs font-semibold rounded bg-rose-500/15 hover:bg-rose-500/25 text-rose-400 border border-rose-500/30 uppercase tracking-wide transition-colors"
          >
            2: FAIL (Out-of-Spec)
          </button>
          <button
            onClick={() => handleRunScenario(3)}
            disabled={isProcessing}
            className="px-2.5 py-1.5 text-xs font-semibold rounded bg-amber-500/15 hover:bg-amber-500/25 text-amber-400 border border-amber-500/30 uppercase tracking-wide transition-colors"
          >
            3: REVIEW (OCR Degraded)
          </button>
        </div>
      </div>

      {uploadError && (
        <div className="p-3 bg-rose-950/40 border border-rose-500/40 rounded text-xs text-rose-300">
          Upload Error: {uploadError}
        </div>
      )}

      {/* Main Workstation Layout: Viewport (Left) + Inspection Panel (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Optical Viewport (8 Cols) */}
        <div className="lg:col-span-8 bg-[#0a0d14] border border-[#1e2638] rounded-md overflow-hidden flex flex-col relative shadow-xl">
          {/* Viewport Top Bar */}
          <div className="bg-[#121722] border-b border-[#1e2638] px-4 py-2.5 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="font-mono font-bold text-slate-200">
                CAM-01 • OVERHEAD INSPECTION ZONE
              </span>
              <span className="text-[10px] text-slate-500 font-mono">
                {activeSource === 'DEMO' ? '[SYNTHETIC 960x540]' : '[DIRECTSHOW]'}
              </span>
            </div>
            <div className="flex items-center gap-3 font-mono text-[11px] text-slate-400">
              <span>FPS: {isRunning ? '28.5' : '0.0'}</span>
              <span>LATENCY: {currentInspection ? `${currentInspection.processing_latency_ms}ms` : '--'}</span>
            </div>
          </div>

          {/* Video / Camera Screen */}
          <div className="relative aspect-video bg-[#0c101a] flex items-center justify-center overflow-hidden">
            {activeSource === 'CAMERA' && !isCamConnected ? (
              /* Hardware Disconnect Banner */
              <div className="p-8 text-center max-w-md space-y-3">
                <div className="w-12 h-12 rounded-full bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400 mx-auto">
                  <VideoOff size={24} />
                </div>
                <h3 className="text-sm font-bold text-slate-200 uppercase tracking-wide">
                  Industrial Camera Not Detected
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  DirectShow video device at index 0 is not physically connected or camera access is restricted.
                  To inspect billets, please switch to <span className="text-cyan-400 font-bold">Demo Stream</span> or use <span className="text-purple-400 font-bold">Upload File</span>.
                </p>
                <div className="pt-2 flex justify-center gap-3">
                  <button
                    onClick={() => setActiveSource('DEMO')}
                    className="px-3 py-1.5 bg-cyan-500 text-cyan-950 font-bold text-xs rounded uppercase tracking-wider"
                  >
                    Switch to Demo Stream
                  </button>
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="px-3 py-1.5 bg-slate-800 text-slate-200 font-semibold text-xs rounded border border-slate-700"
                  >
                    Upload Image
                  </button>
                </div>
              </div>
            ) : currentInspection && currentInspection.frame_reference ? (
              /* Actual Rendered Inspection Frame */
              <div className="w-full h-full relative">
                <img
                  src={currentInspection.frame_reference}
                  alt="Steel Billet Inspection Frame"
                  className="w-full h-full object-cover select-none"
                />

                {/* SVG Calibration and Measurement Overlays */}
                <svg className="absolute inset-0 w-full h-full pointer-events-none">
                  {/* Virtual Photocell / Inspection Trigger Line */}
                  <line
                    x1="50%"
                    y1="0"
                    x2="50%"
                    y2="100%"
                    stroke="rgba(6, 182, 212, 0.4)"
                    strokeWidth="1"
                    strokeDasharray="4 4"
                  />
                  <text
                    x="51%"
                    y="25"
                    fill="rgba(6, 182, 212, 0.8)"
                    fontSize="10"
                    fontFamily="monospace"
                  >
                    CONVEYOR TRIGGER X=0.50
                  </text>
                </svg>

                {/* Status Watermark */}
                <div className="absolute bottom-3 left-3 bg-[#0a0e17]/80 backdrop-blur-xs border border-slate-800 px-3 py-1.5 rounded font-mono text-xs flex items-center gap-3">
                  <span className="text-slate-400">ID: {currentInspection.billet_id}</span>
                  <span className="text-slate-500">•</span>
                  <span className="text-cyan-400 font-bold">
                    {currentInspection.length_mm}mm × {currentInspection.width_mm}mm
                  </span>
                </div>
              </div>
            ) : (
              <div className="text-center text-slate-500 text-xs">
                Awaiting first inspection frame trigger...
              </div>
            )}

            {isProcessing && (
              <div className="absolute inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center">
                <div className="flex flex-col items-center gap-3">
                  <div className="w-9 h-9 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
                  <span className="text-xs font-mono font-bold uppercase tracking-wider text-cyan-400">
                    Running Calibrated Optical Pipeline & YOLO Defect Model...
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Viewport Bottom Telemetry Bar */}
          <div className="bg-[#121722] border-t border-[#1e2638] px-4 py-2 flex items-center justify-between text-xs text-slate-400 font-mono">
            <div className="flex items-center gap-4">
              <span>CALIBRATION: CAL-STD-01 (2.000 mm/px)</span>
              <span>UNCERTAINTY: ±2.5 mm</span>
            </div>
            <div>
              <span>TRIGGERS: Virtual Photocell + Duplicate Suppression</span>
            </div>
          </div>
        </div>

        {/* Right-Side Real-Time Inspection Summary Panel (4 Cols) */}
        <div className="lg:col-span-4 bg-[#121722] border border-[#1e2638] rounded-md p-5 flex flex-col justify-between shadow-xl space-y-4">
          {currentInspection ? (
            <>
              {/* Inspection Header & Final Status */}
              <div>
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] uppercase font-mono tracking-wider text-slate-500">
                      Active Billet Telemetry
                    </span>
                    <h3 className="text-lg font-bold font-mono text-slate-100 m-0">
                      {currentInspection.billet_id}
                    </h3>
                  </div>
                  <StatusBadge status={currentInspection.status} size="lg" />
                </div>

                {/* Status Decision Reason */}
                <div
                  className={`mt-3 p-3 rounded text-xs border leading-relaxed ${
                    currentInspection.status === 'PASS'
                      ? 'bg-emerald-950/20 border-emerald-500/30 text-emerald-300'
                      : currentInspection.status === 'FAIL'
                      ? 'bg-rose-950/20 border-rose-500/30 text-rose-300'
                      : 'bg-amber-950/20 border-amber-500/30 text-amber-300'
                  }`}
                >
                  <div className="font-bold uppercase tracking-wider text-[10px] mb-1">
                    Quality Decision Rule
                  </div>
                  {currentInspection.reason}
                </div>
              </div>

              {/* Physical Dimensions Section */}
              <div className="p-3.5 bg-[#0e141f] border border-slate-800 rounded space-y-2.5">
                <span className="text-[10px] uppercase font-mono font-bold tracking-wider text-cyan-400 block">
                  Calibrated Dimensions (Millimetres)
                </span>
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <span className="text-slate-500 block text-[11px]">Length</span>
                    <span className="text-base font-bold font-mono text-slate-200">
                      {currentInspection.length_mm} mm
                    </span>
                    <span className="text-[10px] text-slate-500 block">Target: 12000 [-30,+50]</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[11px]">Width</span>
                    <span className="text-base font-bold font-mono text-slate-200">
                      {currentInspection.width_mm} mm
                    </span>
                    <span className="text-[10px] text-slate-500 block">Target: 150 [±3]</span>
                  </div>
                </div>

                {/* Height Note */}
                <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
                  <span className="text-slate-500">Height (Depth):</span>
                  <span className="text-slate-400 font-mono italic">Unavailable (Requires 3D sensor)</span>
                </div>
              </div>

              {/* OCR & Identification Section */}
              <div className="p-3.5 bg-[#0e141f] border border-slate-800 rounded space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] uppercase font-mono font-bold tracking-wider text-cyan-400">
                    Marking Stencil OCR
                  </span>
                  <span
                    className={`text-xs font-mono font-bold ${
                      currentInspection.ocr_confidence >= 0.7
                        ? 'text-emerald-400'
                        : 'text-amber-400'
                    }`}
                  >
                    {Math.round(currentInspection.ocr_confidence * 100)}% Confidence
                  </span>
                </div>

                <div className="font-mono text-xs text-slate-200 bg-[#161d2b] p-2 rounded border border-slate-800">
                  {currentInspection.ocr_raw_text || 'UNREADABLE MARKING'}
                </div>

                <div className="flex justify-between text-[11px] text-slate-400 pt-1">
                  <span>Heat Number:</span>
                  <span className="font-mono text-slate-200 font-semibold">
                    {currentInspection.heat_number}
                  </span>
                </div>
                <div className="flex justify-between text-[11px] text-slate-400">
                  <span>Batch ID:</span>
                  <span className="font-mono text-slate-200 font-semibold">
                    {currentInspection.batch_id}
                  </span>
                </div>
              </div>

              {/* Surface Defect Observations */}
              <div className="p-3.5 bg-[#0e141f] border border-slate-800 rounded space-y-1.5">
                <span className="text-[10px] uppercase font-mono font-bold tracking-wider text-cyan-400 block">
                  Defect Observations ({currentInspection.defect_results.length})
                </span>
                {currentInspection.defect_results.length === 0 ? (
                  <div className="text-xs text-emerald-400 flex items-center gap-1.5 py-1">
                    <CheckCircle2 size={14} /> No visible surface defects detected
                  </div>
                ) : (
                  currentInspection.defect_results.map((d, i: number) => (
                    <div key={i} className="text-xs text-rose-300 flex items-center justify-between py-0.5">
                      <span className="font-mono font-semibold capitalize">
                        • {d.defect_class.replace('_', ' ')}
                      </span>
                      <span className="font-mono text-[11px] text-rose-400">
                        {Math.round(d.confidence * 100)}% ({d.severity})
                      </span>
                    </div>
                  ))
                )}
              </div>

              {/* Review & Correct Action */}
              {currentInspection.status === 'REVIEW' && (
                <button
                  onClick={() => setIsReviewModalOpen(true)}
                  className="w-full py-2.5 bg-amber-500 hover:bg-amber-400 text-amber-950 font-bold rounded text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-colors shadow-md"
                >
                  <Edit3 size={15} /> Open Review & Correct ID
                </button>
              )}
            </>
          ) : (
            <div className="p-12 text-center text-slate-500 text-xs">
              No billet currently in inspection zone.
            </div>
          )}
        </div>
      </div>

      {/* Review Modal */}
      {currentInspection && (
        <ReviewModal
          inspection={currentInspection}
          isOpen={isReviewModalOpen}
          onClose={() => setIsReviewModalOpen(false)}
          onSubmitReview={async (id: string, action: ReviewAction, op: string, notes: string, cb?: string, ch?: string, rs?: 'PASS' | 'FAIL') => {
            await onSubmitReview(id, action, op, notes, cb, ch, rs);
            // Refresh local inspection state
            setCurrentInspection({
              ...currentInspection,
              billet_id: cb || currentInspection.billet_id,
              heat_number: ch || currentInspection.heat_number,
              status: rs || currentInspection.status
            });
          }}
        />
      )}
    </div>
  );
};
