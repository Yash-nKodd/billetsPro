import React from 'react';
import {
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Clock,
  Gauge,
  ScanText,
  Layers,
  ArrowRight,
  TrendingUp
} from 'lucide-react';
import { OverviewData, BilletInspection } from '../types';
import { MetricCard } from '../components/common/MetricCard';
import { StatusBadge } from '../components/common/StatusBadge';
import { EmptyState } from '../components/common/EmptyState';

interface OverviewViewProps {
  data: OverviewData | null;
  loading: boolean;
  onSelectInspection: (inspection: BilletInspection) => void;
  onNavigateToTab: (tab: any) => void;
  onSeedData: () => void;
}

export const OverviewView: React.FC<OverviewViewProps> = ({
  data,
  loading,
  onSelectInspection,
  onNavigateToTab,
  onSeedData
}) => {
  if (loading && !data) {
    return (
      <div className="p-8 text-center text-slate-500 flex flex-col items-center justify-center min-h-[400px]">
        <div className="w-8 h-8 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin mb-4" />
        <span className="text-xs uppercase tracking-wider font-mono">Loading Production Telemetry...</span>
      </div>
    );
  }

  if (!data || data.metrics.inspected_count === 0) {
    return (
      <div className="p-6">
        <EmptyState
          title="No Steel Billet Records in Database"
          description="The local SQLite repository is currently empty. Run a live inspection feed, execute a demo scenario, or generate seed production records."
          actionText="Generate Sample Billet Records"
          onAction={onSeedData}
        />
      </div>
    );
  }

  const { metrics, recent_inspections, daily_trends, defect_distribution, batch_comparison } = data;

  return (
    <div className="p-6 space-y-6">
      {/* Top Banner if Reviews are Pending */}
      {metrics.review_count > 0 && (
        <div className="p-3.5 rounded-md bg-amber-500/10 border border-amber-500/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <AlertTriangle className="text-amber-400 shrink-0" size={20} />
            <div>
              <h4 className="text-xs font-bold text-amber-200 uppercase tracking-wider">
                Operator Action Required: {metrics.review_count} Billet(s) Awaiting Review
              </h4>
              <p className="text-[11px] text-amber-300/80">
                Low OCR confidence or ambiguous heat stamp markings require operator confirmation.
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigateToTab('history')}
            className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-amber-950 text-xs font-bold rounded flex items-center gap-1.5 uppercase tracking-wider transition-colors"
          >
            Review Queue <ArrowRight size={14} />
          </button>
        </div>
      )}

      {/* Primary KPI Grid (7 metrics) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-3.5">
        <MetricCard
          label="Total Inspected"
          value={metrics.inspected_count}
          unit="pcs"
          sublabel="Stored in SQLite"
          icon={<Layers size={18} />}
          highlightColor="cyan"
        />

        <MetricCard
          label="Pass Count"
          value={metrics.pass_count}
          unit="pcs"
          sublabel={`Pass Rate: ${metrics.pass_rate_pct}%`}
          icon={<CheckCircle2 size={18} />}
          highlightColor="emerald"
          trend={{ value: `${metrics.pass_rate_pct}%`, isPositive: metrics.pass_rate_pct >= 90 }}
        />

        <MetricCard
          label="Fail Count"
          value={metrics.fail_count}
          unit="pcs"
          sublabel="Tolerance / Defect"
          icon={<XCircle size={18} />}
          highlightColor={metrics.fail_count > 0 ? 'rose' : 'default'}
        />

        <MetricCard
          label="Review Count"
          value={metrics.review_count}
          unit="pcs"
          sublabel="Pending Verification"
          icon={<AlertTriangle size={18} />}
          highlightColor={metrics.review_count > 0 ? 'amber' : 'default'}
        />

        <MetricCard
          label="Avg Latency"
          value={metrics.avg_latency_ms}
          unit="ms"
          sublabel="Per-billet pipeline"
          icon={<Clock size={18} />}
          trend={{ value: 'Real-time', isNeutral: true }}
        />

        <MetricCard
          label="Capture FPS"
          value={metrics.fps > 0 ? metrics.fps.toFixed(1) : '0.0'}
          unit="fps"
          sublabel="Camera / Stream"
          icon={<Gauge size={18} />}
          highlightColor={metrics.fps > 0 ? 'cyan' : 'default'}
        />

        <MetricCard
          label="OCR Accuracy"
          value={metrics.ocr_accuracy_pct}
          unit="%"
          sublabel="Validation mean"
          icon={<ScanText size={18} />}
          trend={{ value: 'Stencil', isNeutral: true }}
        />
      </div>

      {/* Middle Row: Trend Chart & Defect Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Inspection Volume Trends (2 Cols) */}
        <div className="lg:col-span-2 bg-[#121722] border border-[#1e2638] rounded-md p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider m-0">
                Inspection Throughput & Quality Trend
              </h3>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Pass, Fail, and Review metrics aggregated from actual inspection history
              </p>
            </div>
            <span className="text-xs font-mono text-cyan-400 flex items-center gap-1">
              <TrendingUp size={14} /> Real-time
            </span>
          </div>

          {/* SVG Trend Chart */}
          <div className="h-44 w-full flex items-end gap-2 pt-6 pb-2 px-2 border-b border-slate-800">
            {daily_trends.length === 0 ? (
              <div className="w-full text-center text-xs text-slate-500 py-12">
                Accumulating trend history...
              </div>
            ) : (
              daily_trends.map((t, idx: number) => {
                const maxVal = Math.max(...daily_trends.map((x) => x.inspected), 5);
                const passH = (t.passed / maxVal) * 100;
                const failH = (t.failed / maxVal) * 100;
                const revH = (t.reviewed / maxVal) * 100;

                return (
                  <div key={idx} className="flex-1 flex flex-col items-center h-full justify-end group">
                    <div className="w-full flex flex-col justify-end items-center gap-0.5 h-full max-w-[40px]">
                      {revH > 0 && (
                        <div
                          style={{ height: `${revH}%` }}
                          className="w-full bg-amber-500/80 rounded-t-xs"
                          title={`Review: ${t.reviewed}`}
                        />
                      )}
                      {failH > 0 && (
                        <div
                          style={{ height: `${failH}%` }}
                          className="w-full bg-rose-500/80"
                          title={`Fail: ${t.failed}`}
                        />
                      )}
                      {passH > 0 && (
                        <div
                          style={{ height: `${passH}%` }}
                          className="w-full bg-emerald-500/80"
                          title={`Pass: ${t.passed}`}
                        />
                      )}
                    </div>
                    <span className="text-[10px] font-mono text-slate-500 mt-2 truncate w-full text-center">
                      {t.date.substring(5)}
                    </span>
                  </div>
                );
              })
            )}
          </div>

          {/* Legend */}
          <div className="flex items-center justify-center gap-6 pt-3 text-[11px] text-slate-400">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 bg-emerald-500 rounded-xs" /> Passed
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 bg-rose-500 rounded-xs" /> Failed / Rejected
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 bg-amber-500 rounded-xs" /> Under Review
            </span>
          </div>
        </div>

        {/* Defect Class Distribution */}
        <div className="bg-[#121722] border border-[#1e2638] rounded-md p-5 flex flex-col justify-between">
          <div>
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider m-0">
              Surface Defect Breakdown
            </h3>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Supported YOLO optical surface classifications
            </p>
          </div>

          <div className="my-4 space-y-3">
            {Object.keys(defect_distribution).length === 0 ? (
              <div className="text-center text-xs text-slate-500 py-8">
                No surface defects recorded in current dataset.
              </div>
            ) : (
              Object.entries(defect_distribution).map(([defClass, countVal]) => {
                const count = Number(countVal);
                const totalDef = Object.values(defect_distribution).reduce((a, b) => Number(a) + Number(b), 0);
                const pct = totalDef > 0 ? Math.round((count / totalDef) * 100) : 0;
                return (
                  <div key={defClass} className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="font-mono text-slate-300 capitalize">
                        {defClass.replace('_', ' ')}
                      </span>
                      <span className="mono-nums text-slate-400 font-semibold">
                        {count} ({pct}%)
                      </span>
                    </div>
                    <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                      <div
                        style={{ width: `${pct}%` }}
                        className="h-full bg-rose-500 rounded-full"
                      />
                    </div>
                  </div>
                );
              })
            )}
          </div>

          <div className="p-2.5 rounded bg-[#0d121c] border border-slate-800 text-[10px] text-slate-400 leading-tight">
            * Optical inspection detects visible surface cracks & rhomboidity. Internal voids require ultrasonic testing.
          </div>
        </div>
      </div>

      {/* Bottom Row: Recent Inspections Table & Batch Trends */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Inspections Table (2 Cols) */}
        <div className="lg:col-span-2 bg-[#121722] border border-[#1e2638] rounded-md p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider m-0">
                Latest Completed Inspections
              </h3>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Real-time feed of billets stored with full traceability records
              </p>
            </div>
            <button
              onClick={() => onNavigateToTab('history')}
              className="text-xs text-cyan-400 hover:text-cyan-300 font-semibold flex items-center gap-1"
            >
              Full History <ArrowRight size={13} />
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#0e141f] border-b border-slate-800 text-slate-400 uppercase font-mono text-[10px]">
                <tr>
                  <th className="py-2.5 px-3">Billet ID</th>
                  <th className="py-2.5 px-3">Heat / Batch</th>
                  <th className="py-2.5 px-3">Dimensions (L×W)</th>
                  <th className="py-2.5 px-3">OCR Conf</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono">
                {recent_inspections.map((item: BilletInspection) => (
                  <tr key={item.inspection_id} className="hover:bg-[#161d2b] transition-colors">
                    <td className="py-2.5 px-3 font-semibold text-slate-200">
                      {item.billet_id}
                    </td>
                    <td className="py-2.5 px-3 text-slate-400">
                      <div>{item.heat_number}</div>
                      <div className="text-[10px] text-slate-500">{item.batch_id}</div>
                    </td>
                    <td className="py-2.5 px-3 text-slate-300">
                      {item.length_mm} × {item.width_mm} mm
                    </td>
                    <td className="py-2.5 px-3">
                      <span className={item.ocr_confidence >= 0.7 ? 'text-emerald-400' : 'text-amber-400'}>
                        {Math.round(item.ocr_confidence * 100)}%
                      </span>
                    </td>
                    <td className="py-2.5 px-3">
                      <StatusBadge status={item.status} size="sm" />
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <button
                        onClick={() => onSelectInspection(item)}
                        className="text-cyan-400 hover:text-cyan-300 font-sans font-semibold text-[11px] underline"
                      >
                        Passport
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Batch-Level Quality Summary */}
        <div className="bg-[#121722] border border-[#1e2638] rounded-md p-5 flex flex-col justify-between">
          <div>
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider m-0">
              Batch Quality Performance
            </h3>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Comparison across active production heats
            </p>
          </div>

          <div className="my-4 divide-y divide-slate-800/60">
            {batch_comparison.length === 0 ? (
              <div className="text-center text-xs text-slate-500 py-8">
                No batch groups identified.
              </div>
            ) : (
              batch_comparison.slice(0, 4).map((b) => (
                <div key={b.batch_id} className="py-2.5 flex items-center justify-between text-xs">
                  <div>
                    <div className="font-mono font-bold text-slate-200">{b.batch_id}</div>
                    <div className="text-[10px] text-slate-500">
                      Count: {b.count} pcs • Avg L: {b.avg_length}mm
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="font-bold font-mono text-emerald-400 text-sm">
                      {b.pass_rate}%
                    </span>
                    <div className="text-[10px] text-slate-400">Pass Rate</div>
                  </div>
                </div>
              ))
            )}
          </div>

          <button
            onClick={() => onNavigateToTab('analytics')}
            className="w-full py-2 bg-[#161d2b] hover:bg-slate-800 text-cyan-400 text-xs font-semibold rounded border border-slate-800 flex items-center justify-center gap-1.5 transition-colors"
          >
            Open Analytics Workstation <ArrowRight size={13} />
          </button>
        </div>
      </div>
    </div>
  );
};
