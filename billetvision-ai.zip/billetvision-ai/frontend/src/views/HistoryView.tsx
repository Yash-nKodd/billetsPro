import React, { useState, useEffect } from 'react';
import {
  Search,
  Calendar,
  FileSpreadsheet,
  FileText,
  ChevronLeft,
  ChevronRight,
  RefreshCw
} from 'lucide-react';
import { BilletInspection, ReviewAction } from '../types';
import { api } from '../services/api';
import { StatusBadge } from '../components/common/StatusBadge';
import { EmptyState } from '../components/common/EmptyState';
import { ReviewModal } from '../components/modals/ReviewModal';

interface HistoryViewProps {
  onSelectInspection: (inspection: BilletInspection) => void;
  onSubmitReview: (
    inspectionId: string,
    action: ReviewAction,
    operator: string,
    notes: string,
    correctedBilletId?: string,
    correctedHeatNumber?: string,
    resolvedStatus?: 'PASS' | 'FAIL'
  ) => Promise<void>;
}

export const HistoryView: React.FC<HistoryViewProps> = ({
  onSelectInspection,
  onSubmitReview
}) => {
  const [items, setItems] = useState<BilletInspection[]>([]);
  const [total, setTotal] = useState<number>(0);
  const [page, setPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(10);
  const [totalPages, setTotalPages] = useState<number>(1);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Filters
  const [search, setSearch] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [defectFilter, setDefectFilter] = useState<string>('ALL');
  const [dateFrom, setDateFrom] = useState<string>('');
  const [dateTo, setDateTo] = useState<string>('');
  const [exportNotice, setExportNotice] = useState<string | null>(null);

  // Active Review Modal Target
  const [reviewTarget, setReviewTarget] = useState<BilletInspection | null>(null);

  const fetchHistory = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await api.listInspections({
        search,
        status: statusFilter,
        defect_class: defectFilter,
        date_from: dateFrom,
        date_to: dateTo,
        page,
        page_size: pageSize
      });
      setItems(data.items);
      setTotal(data.total);
      setTotalPages(data.total_pages);
    } catch (err: any) {
      setError(err.message || 'Failed to load inspection history');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHistory();
  }, [page, pageSize, statusFilter, defectFilter]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(1);
    fetchHistory();
  };

  const handleExportCsv = () => {
    setExportNotice('Exporting CSV from SQLite dataset...');
    const url = api.getExportCsvUrl({
      search,
      status: statusFilter,
      defect_class: defectFilter,
      date_from: dateFrom,
      date_to: dateTo
    });
    window.location.href = url;
    setTimeout(() => setExportNotice(null), 3000);
  };

  const handleExportXlsx = () => {
    setExportNotice('Exporting formatted XLSX report (pandas + openpyxl)...');
    const url = api.getExportXlsxUrl({
      search,
      status: statusFilter,
      defect_class: defectFilter,
      date_from: dateFrom,
      date_to: dateTo
    });
    window.location.href = url;
    setTimeout(() => setExportNotice(null), 3000);
  };

  return (
    <div className="p-6 space-y-4">
      {/* Top Filter and Search Bar */}
      <div className="bg-[#121722] border border-[#1e2638] rounded-md p-4 space-y-3">
        <form onSubmit={handleSearchSubmit} className="flex flex-wrap items-center justify-between gap-3">
          {/* Search Input */}
          <div className="flex-1 min-w-[240px] relative">
            <Search className="absolute left-3 top-2.5 text-slate-500" size={15} />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by Billet ID, Heat Number, Batch ID, or Inspection ID..."
              className="w-full pl-9 pr-3 py-1.5 bg-[#0e141f] border border-slate-700 rounded text-xs text-slate-100 placeholder-slate-500 focus:border-cyan-400 focus:outline-none"
            />
          </div>

          {/* Status Filter */}
          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-400 font-semibold uppercase text-[11px]">Status:</span>
            <select
              value={statusFilter}
              onChange={(e) => {
                setStatusFilter(e.target.value);
                setPage(1);
              }}
              className="bg-[#0e141f] border border-slate-700 text-slate-200 py-1.5 px-2.5 rounded focus:border-cyan-400 focus:outline-none"
            >
              <option value="ALL">All Statuses</option>
              <option value="PASS">PASS Only</option>
              <option value="FAIL">FAIL (Scrap/Out-of-Spec)</option>
              <option value="REVIEW">REVIEW (Uncertain ID)</option>
            </select>
          </div>

          {/* Defect Class Filter */}
          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-400 font-semibold uppercase text-[11px]">Defect:</span>
            <select
              value={defectFilter}
              onChange={(e) => {
                setDefectFilter(e.target.value);
                setPage(1);
              }}
              className="bg-[#0e141f] border border-slate-700 text-slate-200 py-1.5 px-2.5 rounded focus:border-cyan-400 focus:outline-none"
            >
              <option value="ALL">All Defects</option>
              <option value="corner_crack">Corner Crack</option>
              <option value="surface_inclusion">Surface Inclusion</option>
              <option value="rhomboidity">Rhomboidity</option>
              <option value="longitudinal_crack">Longitudinal Crack</option>
              <option value="severe_scale">Severe Scale</option>
            </select>
          </div>

          {/* Search Trigger */}
          <button
            type="submit"
            className="px-4 py-1.5 bg-cyan-500 hover:bg-cyan-400 text-cyan-950 font-bold rounded text-xs uppercase tracking-wider transition-colors"
          >
            Apply Filters
          </button>
        </form>

        {/* Date Filter & Export Row */}
        <div className="pt-2 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 text-slate-400">
              <Calendar size={13} />
              <span>From:</span>
              <input
                type="date"
                value={dateFrom}
                onChange={(e) => setDateFrom(e.target.value)}
                className="bg-[#0e141f] border border-slate-700 rounded px-2 py-1 text-slate-200"
              />
            </div>
            <div className="flex items-center gap-1.5 text-slate-400">
              <span>To:</span>
              <input
                type="date"
                value={dateTo}
                onChange={(e) => setDateTo(e.target.value)}
                className="bg-[#0e141f] border border-slate-700 rounded px-2 py-1 text-slate-200"
              />
            </div>
            {(dateFrom || dateTo) && (
              <button
                onClick={() => {
                  setDateFrom('');
                  setDateTo('');
                  fetchHistory();
                }}
                className="text-[11px] text-slate-400 hover:text-slate-200 underline"
              >
                Clear Dates
              </button>
            )}
          </div>

          {/* Export Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={handleExportCsv}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded border border-slate-700 flex items-center gap-1.5 font-semibold text-xs transition-colors"
            >
              <FileText size={13} className="text-cyan-400" /> Export CSV
            </button>
            <button
              onClick={handleExportXlsx}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded border border-slate-700 flex items-center gap-1.5 font-semibold text-xs transition-colors"
            >
              <FileSpreadsheet size={13} className="text-emerald-400" /> Export XLSX (openpyxl)
            </button>
          </div>
        </div>
      </div>

      {exportNotice && (
        <div className="p-2.5 bg-cyan-950/40 border border-cyan-500/40 rounded text-xs text-cyan-300 flex items-center gap-2">
          <RefreshCw size={13} className="animate-spin" /> {exportNotice}
        </div>
      )}

      {/* Main Table */}
      <div className="bg-[#121722] border border-[#1e2638] rounded-md overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-slate-500 flex flex-col items-center justify-center">
            <div className="w-7 h-7 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin mb-3" />
            <span className="text-xs uppercase font-mono">Querying SQLite Records...</span>
          </div>
        ) : error ? (
          <div className="p-6 text-center text-rose-400 text-xs">{error}</div>
        ) : items.length === 0 ? (
          <EmptyState
            title="No Matching Inspection Records"
            description="No records match your active search terms or filters. Try adjusting your search query or reset filters."
            actionText="Reset All Filters"
            onAction={() => {
              setSearch('');
              setStatusFilter('ALL');
              setDefectFilter('ALL');
              setDateFrom('');
              setDateTo('');
            }}
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#0e141f] border-b border-slate-800 text-slate-400 font-mono text-[10px] uppercase">
                <tr>
                  <th className="py-3 px-3.5">Timestamp (UTC)</th>
                  <th className="py-3 px-3.5">Billet ID</th>
                  <th className="py-3 px-3.5">Heat Number</th>
                  <th className="py-3 px-3.5">Batch ID</th>
                  <th className="py-3 px-3.5">Length (mm)</th>
                  <th className="py-3 px-3.5">Width (mm)</th>
                  <th className="py-3 px-3.5">OCR Marking</th>
                  <th className="py-3 px-3.5">Defects</th>
                  <th className="py-3 px-3.5">Quality Status</th>
                  <th className="py-3 px-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono">
                {items.map((item) => (
                  <tr key={item.inspection_id} className="hover:bg-[#161d2b] transition-colors">
                    <td className="py-3 px-3.5 text-slate-400 whitespace-nowrap">
                      {item.timestamp.substring(0, 19).replace('T', ' ')}
                    </td>
                    <td className="py-3 px-3.5 font-bold text-slate-200">
                      {item.billet_id}
                    </td>
                    <td className="py-3 px-3.5 text-slate-300">
                      {item.heat_number}
                    </td>
                    <td className="py-3 px-3.5 text-slate-400">
                      {item.batch_id}
                    </td>
                    <td className="py-3 px-3.5 text-slate-200">
                      {item.length_mm}
                    </td>
                    <td className="py-3 px-3.5 text-slate-200">
                      {item.width_mm}
                    </td>
                    <td className="py-3 px-3.5">
                      <div className="truncate max-w-[130px] text-slate-300" title={item.ocr_raw_text}>
                        {item.ocr_raw_text || '—'}
                      </div>
                      <div className={`text-[10px] ${item.ocr_confidence >= 0.7 ? 'text-emerald-400' : 'text-amber-400'}`}>
                        {Math.round(item.ocr_confidence * 100)}% conf
                      </div>
                    </td>
                    <td className="py-3 px-3.5">
                      {item.defect_results.length === 0 ? (
                        <span className="text-slate-500 text-[11px]">None</span>
                      ) : (
                        <span className="text-rose-400 font-bold text-[11px]">
                          {item.defect_results.length} defect(s)
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-3.5">
                      <StatusBadge status={item.status} size="sm" />
                    </td>
                    <td className="py-3 px-3.5 text-right whitespace-nowrap space-x-2">
                      <button
                        onClick={() => onSelectInspection(item)}
                        className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-cyan-300 rounded font-sans text-[11px] font-semibold transition-colors"
                      >
                        Passport
                      </button>
                      {item.status === 'REVIEW' && (
                        <button
                          onClick={() => setReviewTarget(item)}
                          className="px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-amber-950 rounded font-sans text-[11px] font-bold transition-colors"
                        >
                          Resolve
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination Footer */}
        <div className="bg-[#0e141f] border-t border-slate-800 px-4 py-3 flex items-center justify-between text-xs text-slate-400">
          <div>
            Showing <span className="font-mono text-slate-200 font-bold">{items.length}</span> of{' '}
            <span className="font-mono text-slate-200 font-bold">{total}</span> total inspections
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5">
              <span>Rows:</span>
              <select
                value={pageSize}
                onChange={(e) => {
                  setPageSize(Number(e.target.value));
                  setPage(1);
                }}
                className="bg-[#121722] border border-slate-700 text-slate-200 py-1 px-2 rounded focus:outline-none"
              >
                <option value={10}>10</option>
                <option value={20}>20</option>
                <option value={50}>50</option>
              </select>
            </div>

            <div className="flex items-center gap-1">
              <button
                disabled={page <= 1}
                onClick={() => setPage(page - 1)}
                className="p-1 rounded bg-[#121722] border border-slate-700 text-slate-300 disabled:opacity-30 hover:bg-slate-800"
              >
                <ChevronLeft size={16} />
              </button>
              <span className="font-mono px-2">
                Page {page} of {totalPages}
              </span>
              <button
                disabled={page >= totalPages}
                onClick={() => setPage(page + 1)}
                className="p-1 rounded bg-[#121722] border border-slate-700 text-slate-300 disabled:opacity-30 hover:bg-slate-800"
              >
                <ChevronRight size={16} />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Review Modal */}
      {reviewTarget && (
        <ReviewModal
          inspection={reviewTarget}
          isOpen={true}
          onClose={() => setReviewTarget(null)}
          onSubmitReview={async (id: string, action: ReviewAction, op: string, notes: string, cb?: string, ch?: string, rs?: 'PASS' | 'FAIL') => {
            await onSubmitReview(id, action, op, notes, cb, ch, rs);
            fetchHistory();
          }}
        />
      )}
    </div>
  );
};
