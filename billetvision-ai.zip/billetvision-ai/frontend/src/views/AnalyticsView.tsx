import React, { useState, useEffect } from 'react';
import {
  TrendingUp,
  AlertTriangle,
  Info,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Compass
} from 'lucide-react';
import { QualityAnalytics } from '../types';
import { api } from '../services/api';
import { MetricCard } from '../components/common/MetricCard';

export const AnalyticsView: React.FC = () => {
  const [analytics, setAnalytics] = useState<QualityAnalytics | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchAnalytics = async () => {
      setLoading(true);
      try {
        const data = await api.getAnalytics();
        setAnalytics(data);
      } catch (err: any) {
        setError(err.message || 'Failed to fetch analytics');
      } finally {
        setLoading(false);
      }
    };
    fetchAnalytics();
  }, []);

  if (loading) {
    return (
      <div className="p-12 text-center text-slate-500 flex flex-col items-center justify-center">
        <div className="w-7 h-7 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin mb-3" />
        <span className="text-xs uppercase font-mono">Computing Statistical Metrics from SQLite...</span>
      </div>
    );
  }

  if (error || !analytics) {
    return <div className="p-6 text-center text-rose-400 text-xs">{error || 'No analytics available'}</div>;
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-sm font-bold text-slate-100 uppercase tracking-wider m-0 flex items-center gap-2">
          <TrendingUp className="text-cyan-400" size={18} />
          Statistical Quality & Process Analytics
        </h2>
        <p className="text-[11px] text-slate-500 mt-0.5">
          Real-time dimensional variation analysis and quality control charting from factory database
        </p>
      </div>

      {/* Preliminary Notice if Dataset is Small */}
      {analytics.preliminary_notice && (
        <div className="p-3.5 bg-cyan-950/30 border border-cyan-500/30 rounded text-xs text-cyan-300 flex items-start gap-2.5">
          <Info size={16} className="text-cyan-400 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold uppercase tracking-wider block text-[11px]">Preliminary Dataset Notice</span>
            {analytics.preliminary_notice} Statistical confidence intervals will tighten as throughput grows.
          </div>
        </div>
      )}

      {/* Statistical Process Drift Warning */}
      {analytics.drift_warning && (
        <div className="p-3.5 bg-amber-950/30 border border-amber-500/40 rounded text-xs text-amber-300 flex items-start gap-2.5">
          <AlertTriangle size={16} className="text-amber-400 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold uppercase tracking-wider block text-[11px]">Process Drift Detected</span>
            {analytics.drift_warning}
          </div>
        </div>
      )}

      {/* Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <MetricCard
          label="Pass Rate"
          value={analytics.pass_rate_pct}
          unit="%"
          sublabel="Acceptable Billets"
          icon={<CheckCircle2 size={18} />}
          highlightColor="emerald"
        />
        <MetricCard
          label="Defect Scrap Rate"
          value={analytics.defect_rate_pct}
          unit="%"
          sublabel="Out-of-Spec Rejections"
          icon={<XCircle size={18} />}
          highlightColor={analytics.defect_rate_pct > 10 ? 'rose' : 'default'}
        />
        <MetricCard
          label="Review Rate"
          value={analytics.review_rate_pct}
          unit="%"
          sublabel="OCR Ambiguity"
          icon={<HelpCircle size={18} />}
          highlightColor={analytics.review_rate_pct > 15 ? 'amber' : 'default'}
        />
        <MetricCard
          label="Length Std Dev (σ)"
          value={analytics.length_std_dev}
          unit="mm"
          sublabel={`Mean: ${analytics.avg_length_mm} mm`}
          icon={<Compass size={18} />}
          highlightColor={analytics.length_std_dev > 25 ? 'amber' : 'cyan'}
        />
      </div>

      {/* Middle Grid: Dimensional Distribution & Heat Comparison */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Dimensional Distribution Table */}
        <div className="bg-[#121722] border border-[#1e2638] rounded-md p-5 space-y-4 shadow-xl">
          <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider m-0">
            Dimensional Statistical Summary
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#0e141f] border-b border-slate-800 text-slate-400 font-mono text-[10px] uppercase">
                <tr>
                  <th className="py-2.5 px-3">Dimension</th>
                  <th className="py-2.5 px-3">Target</th>
                  <th className="py-2.5 px-3">Tolerance Limits</th>
                  <th className="py-2.5 px-3">Measured Mean</th>
                  <th className="py-2.5 px-3">Standard Dev (σ)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono text-slate-300">
                <tr>
                  <td className="py-2.5 px-3 font-bold text-slate-100">Length</td>
                  <td className="py-2.5 px-3">12000.0 mm</td>
                  <td className="py-2.5 px-3">[11970.0, 12050.0]</td>
                  <td className="py-2.5 px-3 text-cyan-400 font-bold">{analytics.avg_length_mm} mm</td>
                  <td className="py-2.5 px-3">±{analytics.length_std_dev} mm</td>
                </tr>
                <tr>
                  <td className="py-2.5 px-3 font-bold text-slate-100">Width</td>
                  <td className="py-2.5 px-3">150.0 mm</td>
                  <td className="py-2.5 px-3">[147.0, 153.0]</td>
                  <td className="py-2.5 px-3 text-cyan-400 font-bold">{analytics.avg_width_mm} mm</td>
                  <td className="py-2.5 px-3">±{analytics.width_std_dev} mm</td>
                </tr>
                <tr>
                  <td className="py-2.5 px-3 font-bold text-slate-100">Height (Depth)</td>
                  <td className="py-2.5 px-3">—</td>
                  <td className="py-2.5 px-3">—</td>
                  <td className="py-2.5 px-3 text-slate-500 italic">Sensor Unavailable</td>
                  <td className="py-2.5 px-3 text-slate-500 italic">N/A</td>
                </tr>
              </tbody>
            </table>
          </div>
          <p className="text-[11px] text-slate-500 italic">
            * Process stability index Cp requires 50+ validated heats to prevent sampling bias.
          </p>
        </div>

        {/* Batch / Heat Comparison Table */}
        <div className="bg-[#121722] border border-[#1e2638] rounded-md p-5 space-y-4 shadow-xl">
          <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider m-0">
            Heat & Batch Traceability Comparison
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#0e141f] border-b border-slate-800 text-slate-400 font-mono text-[10px] uppercase">
                <tr>
                  <th className="py-2.5 px-3">Batch ID</th>
                  <th className="py-2.5 px-3">Sample Count</th>
                  <th className="py-2.5 px-3">Pass Rate</th>
                  <th className="py-2.5 px-3">Avg Length</th>
                  <th className="py-2.5 px-3">Rejections</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono text-slate-300">
                {analytics.batch_comparison.map((b) => (
                  <tr key={b.batch_id} className="hover:bg-[#161d2b]">
                    <td className="py-2.5 px-3 font-bold text-slate-100">{b.batch_id}</td>
                    <td className="py-2.5 px-3">{b.count} pcs</td>
                    <td className="py-2.5 px-3">
                      <span className={b.pass_rate >= 90 ? 'text-emerald-400 font-bold' : 'text-amber-400 font-bold'}>
                        {b.pass_rate}%
                      </span>
                    </td>
                    <td className="py-2.5 px-3">{b.avg_length} mm</td>
                    <td className="py-2.5 px-3 text-rose-400 font-bold">{b.fail_count}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
