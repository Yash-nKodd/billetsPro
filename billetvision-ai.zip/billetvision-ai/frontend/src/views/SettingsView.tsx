import React, { useState, useEffect } from 'react';
import {
  Settings,
  Database,
  History,
  RefreshCw
} from 'lucide-react';
import { ToleranceConfig, AuditLogItem } from '../types';
import { api } from '../services/api';

interface SettingsViewProps {
  onSeedData: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ onSeedData }) => {
  const [config, setConfig] = useState<ToleranceConfig | null>(null);
  const [auditLogs, setAuditLogs] = useState<AuditLogItem[]>([]);
  const [saving, setSaving] = useState<boolean>(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Form states
  const [targetLength, setTargetLength] = useState<number>(12000.0);
  const [lenTolPos, setLenTolPos] = useState<number>(50.0);
  const [lenTolNeg, setLenTolNeg] = useState<number>(30.0);
  const [targetWidth, setTargetWidth] = useState<number>(150.0);
  const [widTolPos, setWidTolPos] = useState<number>(3.0);
  const [widTolNeg, setWidTolNeg] = useState<number>(3.0);
  const [minOcrConfidence, setMinOcrConfidence] = useState<number>(0.70);
  const [suppressionWindow, setSuppressionWindow] = useState<number>(3.0);
  const [triggerX, setTriggerX] = useState<number>(0.50);
  const [operator, setOperator] = useState<string>('Quality Manager #01');
  const [disallowedDefects, setDisallowedDefects] = useState<string[]>([
    'corner_crack',
    'surface_inclusion',
    'rhomboidity',
    'longitudinal_crack',
    'severe_scale'
  ]);

  const loadSettings = async () => {
    try {
      const [tol, logs] = await Promise.all([api.getTolerances(), api.getAuditLogs(20)]);
      setConfig(tol);
      setAuditLogs(logs);

      setTargetLength(tol.target_length_mm);
      setLenTolPos(tol.length_tolerance_pos_mm);
      setLenTolNeg(tol.length_tolerance_neg_mm);
      setTargetWidth(tol.target_width_mm);
      setWidTolPos(tol.width_tolerance_pos_mm);
      setWidTolNeg(tol.width_tolerance_neg_mm);
      setMinOcrConfidence(tol.min_ocr_confidence);
      setSuppressionWindow(tol.duplicate_suppression_window_s);
      setTriggerX(tol.inspection_zone_trigger_x);
      setDisallowedDefects(tol.disallowed_defects);
    } catch (err: any) {
      setError(err.message || 'Failed to load configuration');
    }
  };

  useEffect(() => {
    loadSettings();
  }, []);

  const handleToggleDefect = (defectName: string) => {
    if (disallowedDefects.includes(defectName)) {
      setDisallowedDefects(disallowedDefects.filter((d) => d !== defectName));
    } else {
      setDisallowedDefects([...disallowedDefects, defectName]);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!operator.trim()) {
      setError('Operator identification name is required to commit configuration changes.');
      return;
    }
    setSaving(true);
    setMessage(null);
    setError(null);
    try {
      const newVersion = `v1.${Date.now().toString().slice(-4)}`;
      const updated: ToleranceConfig = {
        version: newVersion,
        target_length_mm: targetLength,
        length_tolerance_pos_mm: lenTolPos,
        length_tolerance_neg_mm: lenTolNeg,
        target_width_mm: targetWidth,
        width_tolerance_pos_mm: widTolPos,
        width_tolerance_neg_mm: widTolNeg,
        min_ocr_confidence: minOcrConfidence,
        disallowed_defects: disallowedDefects,
        duplicate_suppression_window_s: suppressionWindow,
        inspection_zone_trigger_x: triggerX
      };
      await api.updateTolerances(updated, operator);
      setMessage(`Tolerances updated to ${newVersion} and committed to immutable audit log.`);
      loadSettings();
    } catch (err: any) {
      setError(err.message || 'Error updating tolerances');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h2 className="text-sm font-bold text-slate-100 uppercase tracking-wider m-0 flex items-center gap-2">
          <Settings className="text-cyan-400" size={18} />
          Manufacturing Tolerance & System Settings
        </h2>
        <p className="text-[11px] text-slate-500 mt-0.5">
          Configure physical acceptance criteria, rejection limits, duplicate suppression, and review thresholds
        </p>
      </div>

      {message && (
        <div className="p-3 bg-emerald-950/40 border border-emerald-500/40 rounded text-xs text-emerald-300">
          {message}
        </div>
      )}

      {error && (
        <div className="p-3 bg-rose-950/40 border border-rose-500/40 rounded text-xs text-rose-300">
          {error}
        </div>
      )}

      <form onSubmit={handleSave} className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Tolerances Configuration (7 Cols) */}
        <div className="lg:col-span-7 bg-[#121722] border border-[#1e2638] rounded-md p-6 space-y-5 shadow-xl text-xs">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider m-0">
              Dimensional Tolerance Envelope
            </h3>
            <span className="font-mono text-cyan-400 font-bold">
              Current Version: {config?.version || 'v1.2.0'}
            </span>
          </div>

          {/* Length Limits */}
          <div className="space-y-2">
            <span className="font-semibold text-slate-300 block">Length Tolerance Parameters (mm)</span>
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">Target Length</label>
                <input
                  type="number"
                  step="1.0"
                  value={targetLength}
                  onChange={(e) => setTargetLength(Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 bg-[#0e141f] border border-slate-700 rounded font-mono text-slate-100"
                  required
                />
              </div>
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">+ Upper Tolerance</label>
                <input
                  type="number"
                  step="0.5"
                  value={lenTolPos}
                  onChange={(e) => setLenTolPos(Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 bg-[#0e141f] border border-slate-700 rounded font-mono text-slate-100"
                  required
                />
              </div>
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">- Lower Tolerance</label>
                <input
                  type="number"
                  step="0.5"
                  value={lenTolNeg}
                  onChange={(e) => setLenTolNeg(Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 bg-[#0e141f] border border-slate-700 rounded font-mono text-slate-100"
                  required
                />
              </div>
            </div>
            <div className="text-[10px] text-slate-500 font-mono">
              Accepted Range: [{targetLength - lenTolNeg} mm — {targetLength + lenTolPos} mm]
            </div>
          </div>

          {/* Width Limits */}
          <div className="space-y-2 pt-2 border-t border-slate-800">
            <span className="font-semibold text-slate-300 block">Width Tolerance Parameters (mm)</span>
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">Target Width</label>
                <input
                  type="number"
                  step="0.5"
                  value={targetWidth}
                  onChange={(e) => setTargetWidth(Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 bg-[#0e141f] border border-slate-700 rounded font-mono text-slate-100"
                  required
                />
              </div>
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">+ Upper Tolerance</label>
                <input
                  type="number"
                  step="0.1"
                  value={widTolPos}
                  onChange={(e) => setWidTolPos(Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 bg-[#0e141f] border border-slate-700 rounded font-mono text-slate-100"
                  required
                />
              </div>
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">- Lower Tolerance</label>
                <input
                  type="number"
                  step="0.1"
                  value={widTolNeg}
                  onChange={(e) => setWidTolNeg(Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 bg-[#0e141f] border border-slate-700 rounded font-mono text-slate-100"
                  required
                />
              </div>
            </div>
            <div className="text-[10px] text-slate-500 font-mono">
              Accepted Range: [{targetWidth - widTolNeg} mm — {targetWidth + widTolPos} mm]
            </div>
          </div>

          {/* OCR & Identification Thresholds */}
          <div className="space-y-2 pt-2 border-t border-slate-800">
            <span className="font-semibold text-slate-300 block">Optical Character Recognition & Triggers</span>
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">Min OCR Conf (0-1)</label>
                <input
                  type="number"
                  step="0.05"
                  min="0.1"
                  max="1.0"
                  value={minOcrConfidence}
                  onChange={(e) => setMinOcrConfidence(Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 bg-[#0e141f] border border-slate-700 rounded font-mono text-slate-100"
                  required
                />
              </div>
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">Trigger Line X (0-1)</label>
                <input
                  type="number"
                  step="0.05"
                  min="0.1"
                  max="0.9"
                  value={triggerX}
                  onChange={(e) => setTriggerX(Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 bg-[#0e141f] border border-slate-700 rounded font-mono text-slate-100"
                  required
                />
              </div>
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">Duplicate Window (s)</label>
                <input
                  type="number"
                  step="0.5"
                  min="0.5"
                  value={suppressionWindow}
                  onChange={(e) => setSuppressionWindow(Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 bg-[#0e141f] border border-slate-700 rounded font-mono text-slate-100"
                  required
                />
              </div>
            </div>
          </div>

          {/* Disallowed Defect Classes */}
          <div className="space-y-2 pt-2 border-t border-slate-800">
            <span className="font-semibold text-slate-300 block">Critical Disallowed Surface Defects</span>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {[
                { id: 'corner_crack', label: 'Corner Crack' },
                { id: 'surface_inclusion', label: 'Surface Inclusion' },
                { id: 'rhomboidity', label: 'Rhomboidity' },
                { id: 'longitudinal_crack', label: 'Longitudinal Crack' },
                { id: 'severe_scale', label: 'Severe Scale' },
                { id: 'bending_deformation', label: 'Bending Deformation' }
              ].map((def) => {
                const checked = disallowedDefects.includes(def.id);
                return (
                  <label
                    key={def.id}
                    className={`flex items-center gap-2 p-2 rounded border cursor-pointer select-none transition-colors ${
                      checked
                        ? 'border-rose-500/40 bg-rose-950/20 text-rose-300'
                        : 'border-slate-800 bg-[#0e141f] text-slate-400'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={checked}
                      onChange={() => handleToggleDefect(def.id)}
                      className="rounded bg-[#121722] border-slate-700 text-rose-500"
                    />
                    <span className="text-[11px] font-semibold">{def.label}</span>
                  </label>
                );
              })}
            </div>
          </div>

          {/* Operator Signature */}
          <div className="pt-2 border-t border-slate-800 space-y-2">
            <div>
              <label className="block text-slate-400 font-semibold mb-1">
                Authorized Engineering Signature / Stamp <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                value={operator}
                onChange={(e) => setOperator(e.target.value)}
                className="w-full px-3 py-2 bg-[#0e141f] border border-slate-700 rounded text-slate-100 focus:border-cyan-400 focus:outline-none"
                placeholder="Quality Engineer Name / Badge ID"
                required
              />
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-cyan-950 font-bold rounded uppercase tracking-wider text-xs transition-colors shadow-md"
            >
              {saving ? 'Validating Changes...' : 'Commit New Rule Version'}
            </button>
          </div>
        </div>

        {/* Right Audit Trail & Tools (5 Cols) */}
        <div className="lg:col-span-5 space-y-6">
          {/* Storage & Demo Tools */}
          <div className="bg-[#121722] border border-[#1e2638] rounded-md p-5 space-y-4 shadow-xl">
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider m-0 flex items-center gap-2">
              <Database size={16} className="text-cyan-400" /> Prototype Data Management
            </h3>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              BilletVision AI maintains all inspections, alerts, and tolerance revisions in SQLite local persistence.
            </p>
            <div className="p-3 bg-[#0e141f] border border-slate-800 rounded font-mono text-[11px] text-slate-400 space-y-1">
              <div>DB Engine: SQLite 3.x (WAL Enabled)</div>
              <div>Schema Migration: Automatic on Startup</div>
              <div>Repository Interface: PostgreSQL Compatible</div>
            </div>
            <button
              type="button"
              onClick={onSeedData}
              className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded border border-slate-700 flex items-center justify-center gap-2 transition-colors"
            >
              <RefreshCw size={13} className="text-cyan-400" />
              Re-seed Standard Demo Dataset
            </button>
          </div>

          {/* Audit Log Table */}
          <div className="bg-[#121722] border border-[#1e2638] rounded-md p-5 space-y-3 shadow-xl">
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider m-0 flex items-center gap-2">
              <History size={16} className="text-cyan-400" /> System Revisions Audit Log
            </h3>
            <div className="divide-y divide-slate-800/60 font-mono text-xs max-h-72 overflow-y-auto pr-1">
              {auditLogs.length === 0 ? (
                <div className="text-slate-500 py-6 text-center text-xs">No audit logs recorded yet.</div>
              ) : (
                auditLogs.map((log) => (
                  <div key={log.log_id} className="py-2 space-y-0.5">
                    <div className="flex items-center justify-between text-slate-300">
                      <span className="font-bold text-cyan-400 text-[11px]">{log.action}</span>
                      <span className="text-[10px] text-slate-500">
                        {log.timestamp.replace('T', ' ').substring(0, 19)}
                      </span>
                    </div>
                    <div className="text-slate-400 font-sans text-[11px]">{log.details}</div>
                    <div className="text-[10px] text-slate-500">Operator: {log.operator}</div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </form>
    </div>
  );
};
