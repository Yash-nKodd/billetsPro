import React from 'react';
import { CheckCircle2, XCircle, AlertTriangle, HelpCircle } from 'lucide-react';
import { QualityStatus } from '../../types';

interface StatusBadgeProps {
  status: QualityStatus | string;
  size?: 'sm' | 'md' | 'lg';
  showIcon?: boolean;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({
  status,
  size = 'md',
  showIcon = true
}) => {
  const normStatus = (status || '').toUpperCase();

  const sizeClasses = {
    sm: 'text-xs px-2 py-0.5 font-medium gap-1',
    md: 'text-xs px-2.5 py-1 font-semibold gap-1.5',
    lg: 'text-sm px-3.5 py-1.5 font-bold gap-2'
  }[size];

  const iconSizes = {
    sm: 12,
    md: 14,
    lg: 16
  }[size];

  switch (normStatus) {
    case 'PASS':
      return (
        <span
          className={`inline-flex items-center rounded-sm tracking-wider uppercase border border-emerald-500/40 bg-emerald-500/10 text-emerald-400 ${sizeClasses}`}
        >
          {showIcon && <CheckCircle2 size={iconSizes} className="text-emerald-400 shrink-0" />}
          PASS
        </span>
      );

    case 'FAIL':
      return (
        <span
          className={`inline-flex items-center rounded-sm tracking-wider uppercase border border-rose-500/40 bg-rose-500/10 text-rose-400 ${sizeClasses}`}
        >
          {showIcon && <XCircle size={iconSizes} className="text-rose-400 shrink-0" />}
          FAIL
        </span>
      );

    case 'REVIEW':
      return (
        <span
          className={`inline-flex items-center rounded-sm tracking-wider uppercase border border-amber-500/40 bg-amber-500/10 text-amber-400 ${sizeClasses}`}
        >
          {showIcon && <AlertTriangle size={iconSizes} className="text-amber-400 shrink-0" />}
          REVIEW
        </span>
      );

    default:
      return (
        <span
          className={`inline-flex items-center rounded-sm tracking-wider uppercase border border-slate-700 bg-slate-800 text-slate-300 ${sizeClasses}`}
        >
          {showIcon && <HelpCircle size={iconSizes} className="shrink-0" />}
          {status}
        </span>
      );
  }
};
