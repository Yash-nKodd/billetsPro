import React, { ReactNode } from 'react';

interface MetricCardProps {
  label: string;
  value: string | number;
  unit?: string;
  sublabel?: string;
  icon?: ReactNode;
  trend?: {
    value: string;
    isPositive?: boolean;
    isNeutral?: boolean;
  };
  highlightColor?: 'cyan' | 'emerald' | 'rose' | 'amber' | 'default';
}

export const MetricCard: React.FC<MetricCardProps> = ({
  label,
  value,
  unit,
  sublabel,
  icon,
  trend,
  highlightColor = 'default'
}) => {
  const borderHighlight = {
    cyan: 'border-cyan-500/30 hover:border-cyan-500/50',
    emerald: 'border-emerald-500/30 hover:border-emerald-500/50',
    rose: 'border-rose-500/30 hover:border-rose-500/50',
    amber: 'border-amber-500/30 hover:border-amber-500/50',
    default: 'border-slate-800 hover:border-slate-700'
  }[highlightColor];

  const valueColor = {
    cyan: 'text-cyan-400',
    emerald: 'text-emerald-400',
    rose: 'text-rose-400',
    amber: 'text-amber-400',
    default: 'text-slate-100'
  }[highlightColor];

  return (
    <div
      className={`bg-[#121722] border ${borderHighlight} rounded-md p-4 transition-all duration-150 flex flex-col justify-between`}
    >
      <div className="flex items-start justify-between mb-2">
        <span className="text-xs uppercase font-semibold tracking-wider text-slate-400">
          {label}
        </span>
        {icon && <div className="text-slate-500">{icon}</div>}
      </div>

      <div className="flex items-baseline gap-1.5 my-1">
        <span className={`text-2xl font-bold mono-nums ${valueColor}`}>
          {value}
        </span>
        {unit && <span className="text-xs font-medium text-slate-400">{unit}</span>}
      </div>

      <div className="flex items-center justify-between text-xs mt-2 pt-2 border-t border-slate-800/60">
        {sublabel && <span className="text-slate-500 truncate">{sublabel}</span>}
        {trend && (
          <span
            className={`font-medium mono-nums ml-auto ${
              trend.isNeutral
                ? 'text-slate-400'
                : trend.isPositive
                ? 'text-emerald-400'
                : 'text-rose-400'
            }`}
          >
            {trend.value}
          </span>
        )}
      </div>
    </div>
  );
};
