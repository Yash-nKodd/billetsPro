import React from 'react';
import {
  LayoutDashboard,
  Video,
  History,
  QrCode,
  BarChart3,
  Sliders,
  Settings,
  ChevronLeft,
  ChevronRight,
  Database,
  ShieldCheck
} from 'lucide-react';

export type NavItem =
  | 'overview'
  | 'live'
  | 'history'
  | 'passport'
  | 'analytics'
  | 'calibration'
  | 'settings';

interface SidebarProps {
  activeTab: NavItem;
  onSelectTab: (tab: NavItem) => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  pendingReviewsCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  isCollapsed,
  onToggleCollapse,
  pendingReviewsCount
}) => {
  const navItems: { id: NavItem; label: string; icon: React.ReactNode; badge?: number }[] = [
    {
      id: 'overview',
      label: 'Overview',
      icon: <LayoutDashboard size={18} />
    },
    {
      id: 'live',
      label: 'Live Inspection',
      icon: <Video size={18} />
    },
    {
      id: 'history',
      label: 'Inspection History',
      icon: <History size={18} />
    },
    {
      id: 'passport',
      label: 'Digital Billet Passport',
      icon: <QrCode size={18} />
    },
    {
      id: 'analytics',
      label: 'Quality Analytics',
      icon: <BarChart3 size={18} />
    },
    {
      id: 'calibration',
      label: 'Calibration',
      icon: <Sliders size={18} />
    },
    {
      id: 'settings',
      label: 'Settings',
      icon: <Settings size={18} />
    }
  ];

  return (
    <aside
      className={`bg-[#0d121c] border-r border-[#1e2638] flex flex-col justify-between transition-all duration-200 z-10 shrink-0 select-none ${
        isCollapsed ? 'w-16' : 'w-64'
      }`}
    >
      {/* Navigation Links */}
      <div className="py-4">
        <div className="px-3 mb-2 flex items-center justify-between">
          {!isCollapsed && (
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 px-2">
              Workstation Navigation
            </span>
          )}
          <button
            onClick={onToggleCollapse}
            className="p-1.5 text-slate-500 hover:text-slate-200 hover:bg-[#182030] rounded ml-auto transition-colors"
            title={isCollapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
          >
            {isCollapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
          </button>
        </div>

        <nav className="space-y-1 px-2">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectTab(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-xs font-semibold tracking-wide transition-all ${
                  isActive
                    ? 'bg-cyan-500/15 text-cyan-300 border-l-2 border-cyan-400 pl-[10px]'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-[#141b27]'
                }`}
                title={isCollapsed ? item.label : undefined}
              >
                <div className={`shrink-0 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`}>
                  {item.icon}
                </div>
                {!isCollapsed && (
                  <span className="truncate flex-1 text-left">{item.label}</span>
                )}
                {!isCollapsed && item.badge !== undefined && item.badge > 0 && (
                  <span className="px-1.5 py-0.5 text-[10px] font-mono rounded bg-amber-500/20 text-amber-400 border border-amber-500/30">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* System Persistence Status Footer */}
      <div className="p-3 border-t border-[#1e2638] bg-[#0a0e17]">
        {!isCollapsed ? (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <span className="flex items-center gap-1.5">
                <Database size={13} className="text-cyan-400" />
                SQLite Local DB
              </span>
              <span className="text-[10px] text-emerald-400 font-mono">CONNECTED</span>
            </div>
            <div className="flex items-center justify-between text-[10px] text-slate-500">
              <span>Safety Interlocks</span>
              <span className="text-amber-400 font-mono">STANDALONE</span>
            </div>
          </div>
        ) : (
          <div className="flex justify-center" title="SQLite Storage Connected">
            <Database size={16} className="text-cyan-400" />
          </div>
        )}
      </div>
    </aside>
  );
};
