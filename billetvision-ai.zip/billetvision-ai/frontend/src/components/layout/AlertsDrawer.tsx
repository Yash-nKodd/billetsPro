import React from 'react';
import { X, AlertTriangle, AlertCircle, Info, Check, ExternalLink } from 'lucide-react';
import { AlertItem } from '../../types';

interface AlertsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  alerts: AlertItem[];
  onAcknowledge: (alertId: string) => void;
  onSelectBillet?: (billetId: string) => void;
}

export const AlertsDrawer: React.FC<AlertsDrawerProps> = ({
  isOpen,
  onClose,
  alerts,
  onAcknowledge,
  onSelectBillet
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-xs flex justify-end animate-fade-in">
      <div className="w-full max-w-md bg-[#0e131d] border-l border-[#1e2638] h-full flex flex-col shadow-2xl">
        {/* Drawer Header */}
        <div className="px-5 py-4 border-b border-[#1e2638] flex items-center justify-between bg-[#121722]">
          <div className="flex items-center gap-2">
            <AlertTriangle size={18} className="text-amber-400" />
            <h2 className="text-sm font-bold text-slate-100 uppercase tracking-wider m-0">
              System Alerts & Review Queue
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-100 hover:bg-slate-800 rounded transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Safety Disclaimer Banner */}
        <div className="px-5 py-2.5 bg-amber-500/10 border-b border-amber-500/20 text-[11px] text-amber-300 flex items-start gap-2">
          <Info size={14} className="shrink-0 mt-0.5 text-amber-400" />
          <span>
            Physical safety interlock notice: BilletVision AI operates in advisory inspection mode. Rejection machinery must verify physical limit switches.
          </span>
        </div>

        {/* Alerts List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {alerts.length === 0 ? (
            <div className="p-8 text-center text-slate-500 text-xs">
              No active or unacknowledged alerts.
            </div>
          ) : (
            alerts.map((alert) => {
              const isCrit = alert.severity === 'CRITICAL';
              const isWarn = alert.severity === 'WARNING';

              const borderStyle = isCrit
                ? 'border-rose-500/40 bg-rose-950/20'
                : isWarn
                ? 'border-amber-500/40 bg-amber-950/20'
                : 'border-slate-700 bg-slate-900/40';

              const icon = isCrit ? (
                <AlertCircle size={16} className="text-rose-400 shrink-0 mt-0.5" />
              ) : isWarn ? (
                <AlertTriangle size={16} className="text-amber-400 shrink-0 mt-0.5" />
              ) : (
                <Info size={16} className="text-cyan-400 shrink-0 mt-0.5" />
              );

              return (
                <div
                  key={alert.alert_id}
                  className={`p-3.5 rounded border ${borderStyle} transition-all space-y-2`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-start gap-2">
                      {icon}
                      <div>
                        <h4 className="text-xs font-bold text-slate-200 leading-tight">
                          {alert.title}
                        </h4>
                        <span className="text-[10px] font-mono text-slate-400">
                          {alert.timestamp.substring(11, 19)} UTC • {alert.severity}
                        </span>
                      </div>
                    </div>
                    {alert.acknowledged ? (
                      <span className="text-[10px] text-emerald-400 font-mono flex items-center gap-1">
                        <Check size={12} /> ACK
                      </span>
                    ) : (
                      <button
                        onClick={() => onAcknowledge(alert.alert_id)}
                        className="px-2 py-1 text-[10px] font-semibold uppercase tracking-wider bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 rounded transition-colors"
                      >
                        Acknowledge
                      </button>
                    )}
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed pl-6">
                    {alert.message}
                  </p>

                  {alert.associated_billet_id && (
                    <div className="pl-6 pt-1 flex items-center justify-between text-[11px]">
                      <span className="text-slate-400">
                        Billet: <span className="font-mono text-cyan-400 font-semibold">{alert.associated_billet_id}</span>
                      </span>
                      {onSelectBillet && (
                        <button
                          onClick={() => {
                            onSelectBillet(alert.associated_billet_id!);
                            onClose();
                          }}
                          className="flex items-center gap-1 text-cyan-400 hover:text-cyan-300 font-medium"
                        >
                          Passport <ExternalLink size={11} />
                        </button>
                      )}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
