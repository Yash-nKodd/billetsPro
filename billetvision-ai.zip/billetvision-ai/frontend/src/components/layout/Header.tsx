import React, { useState, useEffect } from 'react';
import {
  Bell,
  Cpu,
  Video,
  VideoOff,
  Sparkles,
  RefreshCw,
  Sliders,
  CheckCircle,
  AlertCircle
} from 'lucide-react';
import { SystemStatus } from '../../types';

interface HeaderProps {
  systemStatus: SystemStatus | null;
  unreadAlertCount: number;
  onOpenAlerts: () => void;
  onToggleMode: (newMode: 'DEMO' | 'LIVE') => void;
  onRefresh: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  systemStatus,
  unreadAlertCount,
  onOpenAlerts,
  onToggleMode,
  onRefresh
}) => {
  const [currentTime, setCurrentTime] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toISOString().replace('T', ' ').substring(0, 19) + ' UTC'
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const isDemo = systemStatus?.active_mode === 'DEMO';

  return (
    <header className="h-16 bg-[#0e131d] border-b border-[#1e2638] px-5 flex items-center justify-between z-20 shrink-0 select-none">
      {/* Brand & Subtitle */}
      <div className="flex items-center gap-3">
        <div className="w-9 h-9 rounded bg-cyan-950/80 border border-cyan-500/40 flex items-center justify-center text-cyan-400 font-black text-lg tracking-wider shadow-[0_0_12px_rgba(6,182,212,0.2)]">
          BV
        </div>
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-base font-bold text-slate-100 tracking-wide m-0 leading-tight">
              BilletVision <span className="text-cyan-400 font-extrabold">AI</span>
            </h1>
            <span className="text-[10px] uppercase font-mono px-1.5 py-0.2 rounded bg-slate-800 text-slate-400 border border-slate-700">
              v1.2.0
            </span>
          </div>
          <p className="text-[11px] text-slate-400 tracking-tight leading-none mt-0.5">
            Automated Steel Billet Optical Inspection & Traceability
          </p>
        </div>
      </div>

      {/* Middle Status Hub: Mode Selector & Telemetry */}
      <div className="hidden lg:flex items-center gap-4">
        {/* Mode Pill Toggle */}
        <div className="flex items-center bg-[#141b27] border border-[#222c3f] rounded p-0.5">
          <button
            onClick={() => onToggleMode('DEMO')}
            className={`flex items-center gap-1.5 px-3 py-1 text-xs font-semibold rounded tracking-wider uppercase transition-colors ${
              isDemo
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sparkles size={12} className={isDemo ? 'text-cyan-400 animate-pulse' : ''} />
            DEMO MODE
          </button>
          <button
            onClick={() => onToggleMode('LIVE')}
            className={`flex items-center gap-1.5 px-3 py-1 text-xs font-semibold rounded tracking-wider uppercase transition-colors ${
              !isDemo
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <div className={`w-2 h-2 rounded-full ${!isDemo ? 'bg-emerald-400 animate-ping' : 'bg-slate-500'}`} />
            LIVE MODE
          </button>
        </div>

        {/* Device & Model Status indicators */}
        <div className="flex items-center gap-3 text-xs border-l border-r border-[#1e2638] px-4 py-1">
          {/* Camera Status */}
          <div className="flex items-center gap-1.5" title={systemStatus?.camera_available ? 'Camera DirectShow Connected' : 'Camera Disconnected'}>
            {systemStatus?.camera_available ? (
              <Video size={14} className="text-emerald-400" />
            ) : (
              <VideoOff size={14} className="text-rose-400" />
            )}
            <span className="text-[11px] font-mono text-slate-300">
              CAM: {systemStatus?.camera_available ? 'ONLINE' : 'DISCONNECTED'}
            </span>
          </div>

          {/* YOLO Model */}
          <div className="flex items-center gap-1.5" title={systemStatus?.model_yolo_status}>
            <Cpu size={14} className={systemStatus?.model_yolo_available ? 'text-cyan-400' : 'text-amber-400'} />
            <span className="text-[11px] font-mono text-slate-300">
              YOLO: {systemStatus?.model_yolo_available ? 'READY' : 'STANDBY (DEMO)'}
            </span>
          </div>

          {/* OCR Model */}
          <div className="flex items-center gap-1.5" title={systemStatus?.model_ocr_status}>
            <Sliders size={14} className="text-cyan-400" />
            <span className="text-[11px] font-mono text-slate-300">
              OCR: READY
            </span>
          </div>
        </div>

        {/* Live Mill Clock */}
        <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
          <span className="tracking-wide text-slate-300">{currentTime || 'SYNCING...'}</span>
        </div>
      </div>

      {/* Right User & Alert Actions */}
      <div className="flex items-center gap-3">
        {/* Refresh button */}
        <button
          onClick={onRefresh}
          className="p-2 text-slate-400 hover:text-cyan-400 hover:bg-slate-800 rounded transition-colors"
          title="Refresh All Telemetry"
        >
          <RefreshCw size={16} />
        </button>

        {/* Alerts Drawer Button */}
        <button
          onClick={onOpenAlerts}
          className="relative p-2 text-slate-400 hover:text-amber-400 hover:bg-slate-800 rounded transition-colors"
          title="Open Alerts & Review Queue"
        >
          <Bell size={18} />
          {unreadAlertCount > 0 && (
            <span className="absolute -top-1 -right-1 px-1.5 py-0.2 text-[10px] font-bold rounded-full bg-rose-500 text-white animate-pulse">
              {unreadAlertCount}
            </span>
          )}
        </button>

        {/* Operator Badge */}
        <div className="hidden sm:flex items-center gap-2.5 pl-3 border-l border-[#1e2638]">
          <div className="w-7 h-7 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-xs font-semibold text-cyan-400">
            LI
          </div>
          <div className="text-left leading-none">
            <div className="text-xs font-semibold text-slate-200">Shift A Inspector</div>
            <div className="text-[10px] text-slate-500 mt-0.5">Control Room #01</div>
          </div>
        </div>
      </div>
    </header>
  );
};
