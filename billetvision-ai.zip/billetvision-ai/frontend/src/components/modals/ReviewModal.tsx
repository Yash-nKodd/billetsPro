import React, { useState } from 'react';
import { X, CheckCircle, Edit3, ShieldAlert, RotateCcw } from 'lucide-react';
import { BilletInspection, ReviewAction } from '../../types';

interface ReviewModalProps {
  inspection: BilletInspection;
  isOpen: boolean;
  onClose: () => void;
  onSubmitReview: (
    inspectionId: string,
    action: ReviewAction,
    operator: string,
    notes: string,
    correctedBilletId?: string,
    correctedHeatNumber?: string,
    resolvedStatus?: 'PASS' | 'FAIL'
  ) => Promise<void>;
}

export const ReviewModal: React.FC<ReviewModalProps> = ({
  inspection,
  isOpen,
  onClose,
  onSubmitReview
}) => {
  const [action, setAction] = useState<ReviewAction>('CORRECT_ID');
  const [operator, setOperator] = useState<string>('Lead Inspector #01');
  const [notes, setNotes] = useState<string>('Verified physical tag on billet end face');
  const [correctedBilletId, setCorrectedBilletId] = useState<string>(inspection.billet_id);
  const [correctedHeatNumber, setCorrectedHeatNumber] = useState<string>(inspection.heat_number);
  const [resolvedStatus, setResolvedStatus] = useState<'PASS' | 'FAIL'>('PASS');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!operator.trim()) {
      setError('Operator identification name is required for auditable review.');
      return;
    }
    setError(null);
    setIsSubmitting(true);
    try {
      await onSubmitReview(
        inspection.inspection_id,
        action,
        operator,
        notes,
        action === 'CORRECT_ID' ? correctedBilletId : undefined,
        action === 'CORRECT_ID' ? correctedHeatNumber : undefined,
        action === 'RESOLVE' ? resolvedStatus : undefined
      );
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to submit review');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-[#121722] border border-[#222c3f] rounded-lg max-w-lg w-full p-6 shadow-2xl space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-sm font-bold text-slate-100 uppercase tracking-wider m-0">
              Operator Audit Review & ID Correction
            </h3>
            <span className="text-xs font-mono text-cyan-400">
              Inspection: {inspection.inspection_id}
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded"
          >
            <X size={18} />
          </button>
        </div>

        {/* Current Inspection Reference Info */}
        <div className="p-3 bg-[#0d121c] border border-slate-800 rounded text-xs space-y-1">
          <div className="flex justify-between">
            <span className="text-slate-500">Current Billet ID:</span>
            <span className="font-mono text-slate-200 font-semibold">{inspection.billet_id}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-500">Current Heat Number:</span>
            <span className="font-mono text-slate-200 font-semibold">{inspection.heat_number}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-500">Raw OCR Marking:</span>
            <span className="font-mono text-amber-300">
              "{inspection.ocr_raw_text || 'UNREADABLE'}" ({Math.round(inspection.ocr_confidence * 100)}% conf)
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-500">Flagged Reason:</span>
            <span className="text-slate-300 text-right max-w-[260px] truncate">{inspection.reason}</span>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {/* Action Selection */}
          <div>
            <label className="block text-slate-400 font-semibold uppercase tracking-wider mb-1.5">
              Review Action
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setAction('CORRECT_ID')}
                className={`p-2.5 rounded border text-left flex items-center gap-2 transition-all ${
                  action === 'CORRECT_ID'
                    ? 'border-cyan-500 bg-cyan-950/30 text-cyan-300'
                    : 'border-slate-800 bg-[#0e141f] text-slate-400 hover:border-slate-700'
                }`}
              >
                <Edit3 size={15} className="shrink-0" />
                <div>
                  <div className="font-bold">Correct Identifier</div>
                  <div className="text-[10px] text-slate-500">Manually fix heat/billet ID</div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => setAction('RESOLVE')}
                className={`p-2.5 rounded border text-left flex items-center gap-2 transition-all ${
                  action === 'RESOLVE'
                    ? 'border-emerald-500 bg-emerald-950/30 text-emerald-300'
                    : 'border-slate-800 bg-[#0e141f] text-slate-400 hover:border-slate-700'
                }`}
              >
                <CheckCircle size={15} className="shrink-0" />
                <div>
                  <div className="font-bold">Resolve Status</div>
                  <div className="text-[10px] text-slate-500">Change to PASS / FAIL</div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => setAction('CONFIRM')}
                className={`p-2.5 rounded border text-left flex items-center gap-2 transition-all ${
                  action === 'CONFIRM'
                    ? 'border-rose-500 bg-rose-950/30 text-rose-300'
                    : 'border-slate-800 bg-[#0e141f] text-slate-400 hover:border-slate-700'
                }`}
              >
                <ShieldAlert size={15} className="shrink-0" />
                <div>
                  <div className="font-bold">Confirm Rejection</div>
                  <div className="text-[10px] text-slate-500">Approve scrap/quarantine</div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => setAction('REINSPECT')}
                className={`p-2.5 rounded border text-left flex items-center gap-2 transition-all ${
                  action === 'REINSPECT'
                    ? 'border-amber-500 bg-amber-950/30 text-amber-300'
                    : 'border-slate-800 bg-[#0e141f] text-slate-400 hover:border-slate-700'
                }`}
              >
                <RotateCcw size={15} className="shrink-0" />
                <div>
                  <div className="font-bold">Request Reinspection</div>
                  <div className="text-[10px] text-slate-500">Trigger secondary pass</div>
                </div>
              </button>
            </div>
          </div>

          {/* Conditional inputs for CORRECT_ID */}
          {action === 'CORRECT_ID' && (
            <div className="grid grid-cols-2 gap-3 p-3 bg-[#0d121c] border border-slate-800 rounded">
              <div>
                <label className="block text-slate-400 mb-1">Corrected Billet ID</label>
                <input
                  type="text"
                  value={correctedBilletId}
                  onChange={(e) => setCorrectedBilletId(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-[#141a27] border border-slate-700 rounded text-slate-100 font-mono focus:border-cyan-400 focus:outline-none"
                  placeholder="BLT-2026-XXXX"
                  required
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Corrected Heat Number</label>
                <input
                  type="text"
                  value={correctedHeatNumber}
                  onChange={(e) => setCorrectedHeatNumber(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-[#141a27] border border-slate-700 rounded text-slate-100 font-mono focus:border-cyan-400 focus:outline-none"
                  placeholder="HEAT-XXXX-X"
                  required
                />
              </div>
            </div>
          )}

          {/* Conditional inputs for RESOLVE */}
          {action === 'RESOLVE' && (
            <div className="p-3 bg-[#0d121c] border border-slate-800 rounded flex items-center justify-between">
              <span className="text-slate-300 font-medium">Override Quality Decision:</span>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setResolvedStatus('PASS')}
                  className={`px-3 py-1 rounded text-xs font-bold uppercase transition-colors ${
                    resolvedStatus === 'PASS'
                      ? 'bg-emerald-500/30 text-emerald-400 border border-emerald-500'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  PASS
                </button>
                <button
                  type="button"
                  onClick={() => setResolvedStatus('FAIL')}
                  className={`px-3 py-1 rounded text-xs font-bold uppercase transition-colors ${
                    resolvedStatus === 'FAIL'
                      ? 'bg-rose-500/30 text-rose-400 border border-rose-500'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  FAIL
                </button>
              </div>
            </div>
          )}

          {/* Operator Signature & Reason */}
          <div className="space-y-3">
            <div>
              <label className="block text-slate-400 mb-1">
                Authorized Operator Signature / Badge ID <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                value={operator}
                onChange={(e) => setOperator(e.target.value)}
                className="w-full px-2.5 py-1.5 bg-[#141a27] border border-slate-700 rounded text-slate-100 focus:border-cyan-400 focus:outline-none"
                placeholder="e.g. Inspector J. Doe (Shift A)"
                required
              />
            </div>
            <div>
              <label className="block text-slate-400 mb-1">Audit Justification & Notes</label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={2}
                className="w-full px-2.5 py-1.5 bg-[#141a27] border border-slate-700 rounded text-slate-100 focus:border-cyan-400 focus:outline-none resize-none"
                placeholder="Details of visual verification or ultrasonic double-check..."
              />
            </div>
          </div>

          {error && <div className="text-xs text-rose-400 bg-rose-950/30 p-2 rounded border border-rose-500/30">{error}</div>}

          {/* Form Actions */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold rounded uppercase tracking-wider text-[11px]"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-4 py-2 bg-cyan-500 hover:bg-cyan-400 disabled:opacity-50 text-cyan-950 font-bold rounded uppercase tracking-wider text-[11px]"
            >
              {isSubmitting ? 'Recording Audit...' : 'Commit Audit Decision'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
