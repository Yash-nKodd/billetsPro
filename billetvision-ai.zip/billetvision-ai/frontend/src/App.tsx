import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/layout/Header';
import { Sidebar, NavItem } from './components/layout/Sidebar';
import { AlertsDrawer } from './components/layout/AlertsDrawer';
import { OverviewView } from './views/OverviewView';
import { LiveInspectionView } from './views/LiveInspectionView';
import { HistoryView } from './views/HistoryView';
import { PassportView } from './views/PassportView';
import { AnalyticsView } from './views/AnalyticsView';
import { CalibrationView } from './views/CalibrationView';
import { SettingsView } from './views/SettingsView';
import { api } from './services/api';
import {
  BilletInspection,
  SystemStatus,
  OverviewData,
  AlertItem,
  ReviewAction
} from './types';

export const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<NavItem>('overview');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(false);
  const [isAlertsOpen, setIsAlertsOpen] = useState<boolean>(false);

  const [systemStatus, setSystemStatus] = useState<SystemStatus | null>(null);
  const [overviewData, setOverviewData] = useState<OverviewData | null>(null);
  const [alerts, setAlerts] = useState<AlertItem[]>([]);
  const [selectedInspection, setSelectedInspection] = useState<BilletInspection | null>(null);
  const [latestInspection, setLatestInspection] = useState<BilletInspection | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  const loadTelemetry = useCallback(async () => {
    try {
      const [status, overview, alertList] = await Promise.all([
        api.getSystemStatus(),
        api.getOverview(),
        api.getAlerts(20, false)
      ]);
      setSystemStatus(status);
      setOverviewData(overview);
      setAlerts(alertList);

      if (overview.recent_inspections.length > 0 && !latestInspection) {
        setLatestInspection(overview.recent_inspections[0]);
        if (!selectedInspection) {
          setSelectedInspection(overview.recent_inspections[0]);
        }
      }
    } catch (err) {
      console.error('Failed to load telemetry:', err);
    } finally {
      setLoading(false);
    }
  }, [latestInspection, selectedInspection]);

  useEffect(() => {
    loadTelemetry();
    const interval = setInterval(loadTelemetry, 15000); // 15s refresh
    return () => clearInterval(interval);
  }, [loadTelemetry]);

  const handleToggleMode = async (newMode: 'DEMO' | 'LIVE') => {
    try {
      const res = await api.setOperatingMode(newMode);
      if (res.warning) {
        alert(res.warning);
      }
      loadTelemetry();
    } catch (err: any) {
      alert(`Mode switch failed: ${err.message}`);
    }
  };

  const handleRunDemoScenario = async (scenarioId: number): Promise<BilletInspection> => {
    const res = await api.runDemoScenario(scenarioId);
    setLatestInspection(res.inspection);
    setSelectedInspection(res.inspection);
    loadTelemetry();
    return res.inspection;
  };

  const handleUploadImage = async (file: File): Promise<BilletInspection> => {
    const formData = new FormData();
    formData.append('file', file);
    const result = await api.uploadImage(formData);
    setLatestInspection(result);
    setSelectedInspection(result);
    loadTelemetry();
    return result;
  };

  const handleSubmitReview = async (
    inspectionId: string,
    action: ReviewAction,
    operator: string,
    notes: string,
    correctedBilletId?: string,
    correctedHeatNumber?: string,
    resolvedStatus?: 'PASS' | 'FAIL'
  ) => {
    const updated = await api.submitReview(inspectionId, {
      action,
      operator,
      notes,
      corrected_billet_id: correctedBilletId,
      corrected_heat_number: correctedHeatNumber,
      resolved_status: resolvedStatus
    });
    setLatestInspection(updated);
    if (selectedInspection?.inspection_id === inspectionId) {
      setSelectedInspection(updated);
    }
    loadTelemetry();
  };

  const handleAcknowledgeAlert = async (alertId: string) => {
    await api.acknowledgeAlert(alertId, 'Lead Inspector #01');
    setAlerts((prev) =>
      prev.map((a) =>
        a.alert_id === alertId ? { ...a, acknowledged: true, acknowledged_by: 'Lead Inspector #01' } : a
      )
    );
  };

  const handleSeedData = async () => {
    await api.seedDemoData();
    loadTelemetry();
  };

  const handleSelectInspection = (inspection: BilletInspection) => {
    setSelectedInspection(inspection);
    setActiveTab('passport');
  };

  const unreadAlertsCount = alerts.filter((a) => !a.acknowledged).length;

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-[#0a0d14] text-slate-100 select-none">
      {/* Top Industrial Workstation Header */}
      <Header
        systemStatus={systemStatus}
        unreadAlertCount={unreadAlertsCount}
        onOpenAlerts={() => setIsAlertsOpen(true)}
        onToggleMode={handleToggleMode}
        onRefresh={loadTelemetry}
      />

      {/* Main Layout Area */}
      <div className="flex flex-1 overflow-hidden relative">
        {/* Collapsible Left Navigation Sidebar */}
        <Sidebar
          activeTab={activeTab}
          onSelectTab={setActiveTab}
          isCollapsed={isSidebarCollapsed}
          onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
          pendingReviewsCount={overviewData?.metrics.review_count || 0}
        />

        {/* Dynamic Main Workspace View */}
        <main className="flex-1 overflow-y-auto bg-[#0a0d14]">
          {activeTab === 'overview' && (
            <OverviewView
              data={overviewData}
              loading={loading}
              onSelectInspection={handleSelectInspection}
              onNavigateToTab={setActiveTab}
              onSeedData={handleSeedData}
            />
          )}

          {activeTab === 'live' && (
            <LiveInspectionView
              systemStatus={systemStatus}
              onRunDemoScenario={handleRunDemoScenario}
              onUploadImage={handleUploadImage}
              onSubmitReview={handleSubmitReview}
              latestInspection={latestInspection}
            />
          )}

          {activeTab === 'history' && (
            <HistoryView
              onSelectInspection={handleSelectInspection}
              onSubmitReview={handleSubmitReview}
            />
          )}

          {activeTab === 'passport' && (
            <PassportView
              selectedInspection={selectedInspection}
              onSubmitReview={handleSubmitReview}
              onSelectInspection={setSelectedInspection}
            />
          )}

          {activeTab === 'analytics' && <AnalyticsView />}

          {activeTab === 'calibration' && <CalibrationView />}

          {activeTab === 'settings' && <SettingsView onSeedData={handleSeedData} />}
        </main>
      </div>

      {/* Alerts & Review Queue Drawer */}
      <AlertsDrawer
        isOpen={isAlertsOpen}
        onClose={() => setIsAlertsOpen(false)}
        alerts={alerts}
        onAcknowledge={handleAcknowledgeAlert}
        onSelectBillet={(billetId) => {
          api.listInspections({ search: billetId, page_size: 1 }).then((res) => {
            if (res.items.length > 0) {
              handleSelectInspection(res.items[0]);
            }
          });
        }}
      />
    </div>
  );
};

export default App;
