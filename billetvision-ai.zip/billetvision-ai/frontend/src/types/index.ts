export type QualityStatus = 'PASS' | 'FAIL' | 'REVIEW';

export type DefectSeverity = 'CRITICAL' | 'MAJOR' | 'MINOR';

export interface DefectItem {
  defect_class: string;
  confidence: number;
  bbox: number[]; // [x, y, w, h]
  severity: DefectSeverity;
  description: string;
}

export type ReviewAction = 'CONFIRM' | 'CORRECT_ID' | 'REINSPECT' | 'RESOLVE';

export interface ReviewAuditEvent {
  event_id: string;
  timestamp: string;
  action: ReviewAction;
  operator: string;
  notes: string;
  original_val?: string;
  new_val?: string;
}

export interface BilletInspection {
  inspection_id: string;
  billet_id: string;
  heat_number: string;
  batch_id: string;
  timestamp: string;
  length_mm: number;
  width_mm: number;
  height_mm?: number | null;
  calibration_id: string;
  measurement_uncertainty?: number | null;
  ocr_raw_text: string;
  ocr_confidence: number;
  defect_results: DefectItem[];
  status: QualityStatus;
  reason: string;
  processing_latency_ms: number;
  frame_reference: string;
  source_mode: 'DEMO' | 'LIVE' | 'UPLOAD';
  configuration_version: string;
  review_audit_events: ReviewAuditEvent[];
  reviewed_by?: string | null;
  reviewed_at?: string | null;
}

export interface BilletInspectionCreate {
  billet_id?: string;
  heat_number?: string;
  batch_id?: string;
  length_mm: number;
  width_mm: number;
  height_mm?: number | null;
  calibration_id?: string;
  measurement_uncertainty?: number | null;
  ocr_raw_text?: string;
  ocr_confidence?: number;
  defect_results?: DefectItem[];
  processing_latency_ms?: number;
  frame_reference?: string;
  source_mode?: 'DEMO' | 'LIVE' | 'UPLOAD';
}

export interface CorrectionRequest {
  action: ReviewAction;
  operator: string;
  notes: string;
  corrected_billet_id?: string;
  corrected_heat_number?: string;
  resolved_status?: 'PASS' | 'FAIL';
}

export interface ToleranceConfig {
  version: string;
  target_length_mm: number;
  length_tolerance_pos_mm: number;
  length_tolerance_neg_mm: number;
  target_width_mm: number;
  width_tolerance_pos_mm: number;
  width_tolerance_neg_mm: number;
  target_height_mm?: number | null;
  height_tolerance_pos_mm?: number | null;
  height_tolerance_neg_mm?: number | null;
  min_ocr_confidence: number;
  disallowed_defects: string[];
  duplicate_suppression_window_s: number;
  inspection_zone_trigger_x: number;
}

export interface CalibrationConfig {
  calibration_id: string;
  known_reference_length_mm: number;
  pixel_distance_px: number;
  scale_mm_per_px: number;
  measurement_plane: 'TOP_SURFACE_CONVEYOR' | 'SIDE_PROFILE';
  is_calibrated: boolean;
  camera_distance_mm: number;
  calibration_timestamp: string;
  estimated_uncertainty_mm: number;
  notes: string;
}

export interface AlertItem {
  alert_id: string;
  timestamp: string;
  severity: 'CRITICAL' | 'WARNING' | 'INFO';
  title: string;
  message: string;
  associated_billet_id?: string | null;
  inspection_id?: string | null;
  acknowledged: boolean;
  acknowledged_by?: string | null;
  acknowledged_at?: string | null;
}

export interface SystemStatus {
  app_name: string;
  version: string;
  active_mode: 'DEMO' | 'LIVE';
  camera_available: boolean;
  camera_device_name?: string | null;
  fps: number;
  model_yolo_available: boolean;
  model_yolo_name: string;
  model_yolo_status: string;
  model_ocr_available: boolean;
  model_ocr_name: string;
  model_ocr_status: string;
  database_connected: boolean;
  database_type: string;
  calibrated: boolean;
  total_inspections_stored: number;
  pending_reviews_count: number;
}

export interface OverviewMetrics {
  inspected_count: number;
  pass_count: number;
  fail_count: number;
  review_count: number;
  pass_rate_pct: number;
  avg_latency_ms: number;
  fps: number;
  ocr_accuracy_pct: number;
}

export interface OverviewData {
  metrics: OverviewMetrics;
  latest_alerts: AlertItem[];
  recent_inspections: BilletInspection[];
  daily_trends: {
    date: string;
    inspected: number;
    passed: number;
    failed: number;
    reviewed: number;
    pass_rate: number;
  }[];
  defect_distribution: Record<string, number>;
  batch_comparison: {
    batch_id: string;
    count: number;
    pass_rate: number;
    fail_count: number;
    avg_length: number;
    avg_width: number;
  }[];
  active_mode: 'DEMO' | 'LIVE';
}

export interface QualityAnalytics {
  total_count: number;
  pass_rate_pct: number;
  defect_rate_pct: number;
  review_rate_pct: number;
  avg_length_mm: number;
  avg_width_mm: number;
  length_std_dev: number;
  width_std_dev: number;
  defect_distribution: Record<string, number>;
  daily_trends: {
    date: string;
    inspected: number;
    passed: number;
    failed: number;
    reviewed: number;
    pass_rate: number;
  }[];
  batch_comparison: {
    batch_id: string;
    count: number;
    pass_rate: number;
    fail_count: number;
    avg_length: number;
    avg_width: number;
  }[];
  drift_warning?: string | null;
  preliminary_notice?: string | null;
}

export interface AuditLogItem {
  log_id: number;
  timestamp: string;
  category: string;
  operator: string;
  action: string;
  details: string;
}
