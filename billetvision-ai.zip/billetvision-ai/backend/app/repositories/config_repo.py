import json
import sqlite3
from typing import Optional, List, Dict, Any
from datetime import datetime
from app.database import get_db
from app.models.schemas import ToleranceConfig, CalibrationConfig

class ConfigRepository:
    def __init__(self):
        pass

    def get_tolerances(self) -> ToleranceConfig:
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT config_value FROM configurations WHERE config_key = 'tolerances'")
            row = cursor.fetchone()
            if row:
                data = json.loads(row["config_value"])
                return ToleranceConfig(**data)
            # Default
            default_config = ToleranceConfig()
            self.save_tolerances(default_config, operator="SYSTEM_INIT")
            return default_config

    def save_tolerances(self, config: ToleranceConfig, operator: str = "OPERATOR") -> ToleranceConfig:
        with get_db() as conn:
            cursor = conn.cursor()
            now_iso = datetime.now().isoformat()
            cursor.execute("""
            INSERT OR REPLACE INTO configurations (config_key, config_value, updated_at)
            VALUES ('tolerances', ?, ?);
            """, (json.dumps(config.model_dump()), now_iso))

            cursor.execute("""
            INSERT INTO audit_logs (timestamp, category, operator, action, details)
            VALUES (?, 'CONFIG_CHANGE', ?, 'UPDATE_TOLERANCES', ?);
            """, (now_iso, operator, f"Updated tolerances to version {config.version}: target {config.target_length_mm}x{config.target_width_mm}mm"))

            return config

    def get_calibration(self) -> CalibrationConfig:
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT config_value FROM configurations WHERE config_key = 'calibration'")
            row = cursor.fetchone()
            if row:
                data = json.loads(row["config_value"])
                return CalibrationConfig(**data)
            # Default
            default_cal = CalibrationConfig(calibration_timestamp=datetime.now().isoformat())
            self.save_calibration(default_cal, operator="SYSTEM_INIT")
            return default_cal

    def save_calibration(self, cal: CalibrationConfig, operator: str = "OPERATOR") -> CalibrationConfig:
        with get_db() as conn:
            cursor = conn.cursor()
            now_iso = datetime.now().isoformat()
            cal.calibration_timestamp = now_iso
            # recalculate scale
            if cal.pixel_distance_px > 0:
                cal.scale_mm_per_px = round(cal.known_reference_length_mm / cal.pixel_distance_px, 4)
            
            cursor.execute("""
            INSERT OR REPLACE INTO configurations (config_key, config_value, updated_at)
            VALUES ('calibration', ?, ?);
            """, (json.dumps(cal.model_dump()), now_iso))

            cursor.execute("""
            INSERT INTO audit_logs (timestamp, category, operator, action, details)
            VALUES (?, 'CALIBRATION', ?, 'UPDATE_CALIBRATION', ?);
            """, (now_iso, operator, f"Calibrated {cal.calibration_id}: scale={cal.scale_mm_per_px} mm/px, plane={cal.measurement_plane}"))

            return cal

    def get_audit_logs(self, limit: int = 50) -> List[Dict[str, Any]]:
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT ?", (limit,))
            rows = cursor.fetchall()
            return [
                {
                    "log_id": r["log_id"],
                    "timestamp": r["timestamp"],
                    "category": r["category"],
                    "operator": r["operator"],
                    "action": r["action"],
                    "details": r["details"]
                }
                for r in rows
            ]
