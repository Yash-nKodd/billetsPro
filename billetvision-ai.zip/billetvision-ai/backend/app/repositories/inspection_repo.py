import json
import sqlite3
from typing import List, Optional, Tuple, Dict, Any
from datetime import datetime
from app.database import get_db
from app.models.schemas import (
    BilletInspection,
    DefectItem,
    ReviewAuditEvent,
    AlertItem,
)

class InspectionRepository:
    def __init__(self):
        pass

    def _row_to_inspection(self, row: sqlite3.Row) -> BilletInspection:
        defects_raw = json.loads(row["defect_results"]) if row["defect_results"] else []
        defects = [DefectItem(**d) for d in defects_raw]
        
        events_raw = json.loads(row["review_audit_events"]) if row["review_audit_events"] else []
        events = [ReviewAuditEvent(**e) for e in events_raw]

        return BilletInspection(
            inspection_id=row["inspection_id"],
            billet_id=row["billet_id"],
            heat_number=row["heat_number"],
            batch_id=row["batch_id"],
            timestamp=row["timestamp"],
            length_mm=row["length_mm"],
            width_mm=row["width_mm"],
            height_mm=row["height_mm"],
            calibration_id=row["calibration_id"],
            measurement_uncertainty=row["measurement_uncertainty"],
            ocr_raw_text=row["ocr_raw_text"] or "",
            ocr_confidence=row["ocr_confidence"],
            defect_results=defects,
            status=row["status"],
            reason=row["reason"],
            processing_latency_ms=row["processing_latency_ms"],
            frame_reference=row["frame_reference"] or "",
            source_mode=row["source_mode"],
            configuration_version=row["configuration_version"],
            review_audit_events=events,
            reviewed_by=row["reviewed_by"],
            reviewed_at=row["reviewed_at"]
        )

    def insert_inspection(self, item: BilletInspection) -> BilletInspection:
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            INSERT OR REPLACE INTO inspections (
                inspection_id, billet_id, heat_number, batch_id, timestamp,
                length_mm, width_mm, height_mm, calibration_id, measurement_uncertainty,
                ocr_raw_text, ocr_confidence, defect_results, status, reason,
                processing_latency_ms, frame_reference, source_mode,
                configuration_version, review_audit_events, reviewed_by, reviewed_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
            """, (
                item.inspection_id,
                item.billet_id,
                item.heat_number,
                item.batch_id,
                item.timestamp,
                item.length_mm,
                item.width_mm,
                item.height_mm,
                item.calibration_id,
                item.measurement_uncertainty,
                item.ocr_raw_text,
                item.ocr_confidence,
                json.dumps([d.model_dump() for d in item.defect_results]),
                item.status,
                item.reason,
                item.processing_latency_ms,
                item.frame_reference,
                item.source_mode,
                item.configuration_version,
                json.dumps([e.model_dump() for e in item.review_audit_events]),
                item.reviewed_by,
                item.reviewed_at
            ))
            return item

    def get_by_id(self, inspection_id: str) -> Optional[BilletInspection]:
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM inspections WHERE inspection_id = ?", (inspection_id,))
            row = cursor.fetchone()
            if not row:
                return None
            return self._row_to_inspection(row)

    def get_by_billet_id(self, billet_id: str) -> List[BilletInspection]:
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM inspections WHERE billet_id = ? ORDER BY timestamp DESC", (billet_id,))
            rows = cursor.fetchall()
            return [self._row_to_inspection(r) for r in rows]

    def list_inspections(
        self,
        search: Optional[str] = None,
        status: Optional[str] = None,
        defect_class: Optional[str] = None,
        date_from: Optional[str] = None,
        date_to: Optional[str] = None,
        source_mode: Optional[str] = None,
        limit: int = 50,
        offset: int = 0
    ) -> Tuple[List[BilletInspection], int]:
        conditions = []
        params: List[Any] = []

        if search:
            s = f"%{search.strip()}%"
            conditions.append("(billet_id LIKE ? OR heat_number LIKE ? OR batch_id LIKE ? OR inspection_id LIKE ?)")
            params.extend([s, s, s, s])

        if status and status.upper() != "ALL":
            conditions.append("status = ?")
            params.append(status.upper())

        if defect_class and defect_class.lower() != "all":
            conditions.append("defect_results LIKE ?")
            params.append(f"%{defect_class}%")

        if date_from:
            conditions.append("timestamp >= ?")
            params.append(date_from)

        if date_to:
            conditions.append("timestamp <= ?")
            params.append(date_to)

        if source_mode and source_mode.upper() != "ALL":
            conditions.append("source_mode = ?")
            params.append(source_mode.upper())

        where_clause = f"WHERE {' AND '.join(conditions)}" if conditions else ""

        with get_db() as conn:
            cursor = conn.cursor()
            # Count total matching
            cursor.execute(f"SELECT COUNT(*) FROM inspections {where_clause}", params)
            total = cursor.fetchone()[0]

            # Fetch paginated rows
            query = f"SELECT * FROM inspections {where_clause} ORDER BY timestamp DESC LIMIT ? OFFSET ?"
            cursor.execute(query, params + [limit, offset])
            rows = cursor.fetchall()
            items = [self._row_to_inspection(r) for r in rows]
            return items, total

    def update_audit(
        self,
        inspection_id: str,
        action: str,
        operator: str,
        notes: str = "",
        corrected_billet_id: Optional[str] = None,
        corrected_heat_number: Optional[str] = None,
        resolved_status: Optional[str] = None
    ) -> Optional[BilletInspection]:
        item = self.get_by_id(inspection_id)
        if not item:
            return None

        event_id = f"EVT-{datetime.now().strftime('%Y%m%d%H%M%S')}-{len(item.review_audit_events)+1}"
        now_iso = datetime.now().isoformat()

        original_val = f"BilletID:{item.billet_id}, Heat:{item.heat_number}, Status:{item.status}"
        
        # Apply changes
        if corrected_billet_id:
            item.billet_id = corrected_billet_id
        if corrected_heat_number:
            item.heat_number = corrected_heat_number
        if resolved_status:
            item.status = resolved_status
            item.reason = f"Manually resolved to {resolved_status} by operator {operator}: {notes}"
        
        item.reviewed_by = operator
        item.reviewed_at = now_iso

        new_val = f"BilletID:{item.billet_id}, Heat:{item.heat_number}, Status:{item.status}"

        audit_event = ReviewAuditEvent(
            event_id=event_id,
            timestamp=now_iso,
            action=action, # type: ignore
            operator=operator,
            notes=notes,
            original_val=original_val,
            new_val=new_val
        )
        item.review_audit_events.append(audit_event)

        return self.insert_inspection(item)

    def insert_alert(self, alert: AlertItem) -> AlertItem:
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            INSERT OR REPLACE INTO alerts (
                alert_id, timestamp, severity, title, message,
                associated_billet_id, inspection_id, acknowledged,
                acknowledged_by, acknowledged_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
            """, (
                alert.alert_id,
                alert.timestamp,
                alert.severity,
                alert.title,
                alert.message,
                alert.associated_billet_id,
                alert.inspection_id,
                1 if alert.acknowledged else 0,
                alert.acknowledged_by,
                alert.acknowledged_at
            ))
            return alert

    def get_alerts(self, limit: int = 50, unack_only: bool = False) -> List[AlertItem]:
        with get_db() as conn:
            cursor = conn.cursor()
            query = "SELECT * FROM alerts"
            params = []
            if unack_only:
                query += " WHERE acknowledged = 0"
            query += " ORDER BY timestamp DESC LIMIT ?"
            params.append(limit)

            cursor.execute(query, params)
            rows = cursor.fetchall()
            return [
                AlertItem(
                    alert_id=r["alert_id"],
                    timestamp=r["timestamp"],
                    severity=r["severity"],
                    title=r["title"],
                    message=r["message"],
                    associated_billet_id=r["associated_billet_id"],
                    inspection_id=r["inspection_id"],
                    acknowledged=bool(r["acknowledged"]),
                    acknowledged_by=r["acknowledged_by"],
                    acknowledged_at=r["acknowledged_at"]
                )
                for r in rows
            ]

    def acknowledge_alert(self, alert_id: str, operator: str) -> bool:
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            UPDATE alerts
            SET acknowledged = 1, acknowledged_by = ?, acknowledged_at = ?
            WHERE alert_id = ?;
            """, (operator, datetime.now().isoformat(), alert_id))
            return cursor.rowcount > 0

    def get_overview_metrics(self) -> Dict[str, Any]:
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM inspections")
            total = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM inspections WHERE status = 'PASS'")
            passes = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM inspections WHERE status = 'FAIL'")
            fails = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM inspections WHERE status = 'REVIEW'")
            reviews = cursor.fetchone()[0]

            cursor.execute("SELECT AVG(processing_latency_ms) FROM inspections")
            avg_latency_raw = cursor.fetchone()[0]
            avg_latency = round(float(avg_latency_raw), 1) if avg_latency_raw else 0.0

            cursor.execute("SELECT AVG(ocr_confidence) FROM inspections WHERE ocr_confidence > 0")
            avg_ocr_raw = cursor.fetchone()[0]
            avg_ocr = round(float(avg_ocr_raw) * 100, 1) if avg_ocr_raw else 0.0

            pass_rate = round((passes / total * 100), 1) if total > 0 else 0.0

            return {
                "inspected_count": total,
                "pass_count": passes,
                "fail_count": fails,
                "review_count": reviews,
                "pass_rate_pct": pass_rate,
                "avg_latency_ms": avg_latency,
                "fps": 28.5 if total > 0 else 0.0,
                "ocr_accuracy_pct": avg_ocr
            }

    def get_analytics_data(self) -> Dict[str, Any]:
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM inspections ORDER BY timestamp ASC")
            rows = cursor.fetchall()
            
            total = len(rows)
            if total == 0:
                return {
                    "total_count": 0,
                    "pass_rate_pct": 0.0,
                    "defect_rate_pct": 0.0,
                    "review_rate_pct": 0.0,
                    "avg_length_mm": 0.0,
                    "avg_width_mm": 0.0,
                    "length_std_dev": 0.0,
                    "width_std_dev": 0.0,
                    "defect_distribution": {},
                    "daily_trends": [],
                    "batch_comparison": [],
                    "drift_warning": None,
                    "preliminary_notice": "No inspection data yet recorded."
                }

            passes = sum(1 for r in rows if r["status"] == "PASS")
            fails = sum(1 for r in rows if r["status"] == "FAIL")
            reviews = sum(1 for r in rows if r["status"] == "REVIEW")

            lengths = [r["length_mm"] for r in rows]
            widths = [r["width_mm"] for r in rows]

            avg_len = sum(lengths) / total
            avg_wid = sum(widths) / total

            variance_len = sum((x - avg_len) ** 2 for x in lengths) / total
            std_len = variance_len ** 0.5

            variance_wid = sum((x - avg_wid) ** 2 for x in widths) / total
            std_wid = variance_wid ** 0.5

            # Defect distribution
            defect_dist: Dict[str, int] = {}
            for r in rows:
                if r["defect_results"]:
                    defs = json.loads(r["defect_results"])
                    for d in defs:
                        dclass = d.get("defect_class", "unknown")
                        defect_dist[dclass] = defect_dist.get(dclass, 0) + 1

            # Daily grouping
            day_map: Dict[str, Dict[str, int]] = {}
            for r in rows:
                day = r["timestamp"][:10]
                if day not in day_map:
                    day_map[day] = {"total": 0, "pass": 0, "fail": 0, "review": 0}
                day_map[day]["total"] += 1
                if r["status"] == "PASS":
                    day_map[day]["pass"] += 1
                elif r["status"] == "FAIL":
                    day_map[day]["fail"] += 1
                elif r["status"] == "REVIEW":
                    day_map[day]["review"] += 1

            daily_trends = [
                {
                    "date": d,
                    "inspected": vals["total"],
                    "passed": vals["pass"],
                    "failed": vals["fail"],
                    "reviewed": vals["review"],
                    "pass_rate": round(vals["pass"] / vals["total"] * 100, 1)
                }
                for d, vals in sorted(day_map.items())
            ]

            # Batch comparison
            batch_map: Dict[str, Dict[str, Any]] = {}
            for r in rows:
                b = r["batch_id"]
                if b not in batch_map:
                    batch_map[b] = {
                        "batch_id": b,
                        "count": 0,
                        "pass": 0,
                        "fail": 0,
                        "review": 0,
                        "avg_len": 0.0,
                        "avg_wid": 0.0,
                        "total_len": 0.0,
                        "total_wid": 0.0
                    }
                batch_map[b]["count"] += 1
                if r["status"] == "PASS":
                    batch_map[b]["pass"] += 1
                elif r["status"] == "FAIL":
                    batch_map[b]["fail"] += 1
                elif r["status"] == "REVIEW":
                    batch_map[b]["review"] += 1
                batch_map[b]["total_len"] += r["length_mm"]
                batch_map[b]["total_wid"] += r["width_mm"]

            batch_comp = []
            for b, item in batch_map.items():
                c = item["count"]
                batch_comp.append({
                    "batch_id": b,
                    "count": c,
                    "pass_rate": round(item["pass"] / c * 100, 1),
                    "fail_count": item["fail"],
                    "avg_length": round(item["total_len"] / c, 1),
                    "avg_width": round(item["total_wid"] / c, 1)
                })

            drift_warning = None
            if std_len > 25.0:
                drift_warning = f"High dimensional variance detected (σ={std_len:.1f} mm). Shear-cut mechanism or cooling bed thermal contraction may require recalibration."

            preliminary_notice = None
            if total < 10:
                preliminary_notice = f"Sample size ({total} billets) is preliminary. Statistical drift and OCR confidence confidence intervals will stabilize after 30+ inspections."

            return {
                "total_count": total,
                "pass_rate_pct": round(passes / total * 100, 1),
                "defect_rate_pct": round(fails / total * 100, 1),
                "review_rate_pct": round(reviews / total * 100, 1),
                "avg_length_mm": round(avg_len, 1),
                "avg_width_mm": round(avg_wid, 1),
                "length_std_dev": round(std_len, 2),
                "width_std_dev": round(std_wid, 2),
                "defect_distribution": defect_dist,
                "daily_trends": daily_trends,
                "batch_comparison": batch_comp,
                "drift_warning": drift_warning,
                "preliminary_notice": preliminary_notice
            }
