import cv2
import logging
from typing import Optional, Tuple, Dict, Any

logger = logging.getLogger("billetvision.camera")

class CameraAdapter:
    def __init__(self, device_index: int = 0):
        self.device_index = device_index
        self.cap: Optional[cv2.VideoCapture] = None
        self.is_connected: bool = False
        self.error_message: Optional[str] = None
        self.resolution: Tuple[int, int] = (0, 0)
        self.actual_fps: float = 0.0

    def check_and_connect(self) -> bool:
        """
        Attempts to open the OpenCV VideoCapture device.
        Honest check: returns False if no physical camera or permission denied.
        """
        try:
            self.release()
            # Try DirectShow or default backend on Windows
            self.cap = cv2.VideoCapture(self.device_index, cv2.CAP_DSHOW)
            if not self.cap.isOpened():
                # Try default backend
                self.cap = cv2.VideoCapture(self.device_index)

            if not self.cap or not self.cap.isOpened():
                self.is_connected = False
                self.error_message = f"Hardware camera device index {self.device_index} not accessible (permission denied or no device attached)."
                logger.warning(self.error_message)
                return False

            # Read a test frame to ensure it actually transmits
            ret, frame = self.cap.read()
            if not ret or frame is None:
                self.is_connected = False
                self.error_message = f"Camera device {self.device_index} opened but failed to capture frame."
                self.release()
                return False

            w = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            h = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            fps = float(self.cap.get(cv2.CAP_PROP_FPS)) or 30.0

            self.resolution = (w, h)
            self.actual_fps = fps
            self.is_connected = True
            self.error_message = None
            logger.info(f"Connected to camera {self.device_index} at {w}x{h} @ {fps} FPS")
            return True
        except Exception as e:
            self.is_connected = False
            self.error_message = f"Camera initialization exception: {str(e)}"
            self.release()
            return False

    def read_frame(self) -> Tuple[bool, Optional[Any]]:
        if not self.is_connected or not self.cap or not self.cap.isOpened():
            return False, None
        try:
            ret, frame = self.cap.read()
            return ret, frame
        except Exception as e:
            logger.error(f"Error reading frame: {e}")
            self.is_connected = False
            self.error_message = str(e)
            return False, None

    def release(self):
        if self.cap:
            try:
                self.cap.release()
            except Exception:
                pass
            self.cap = None
        self.is_connected = False

    def get_status(self) -> Dict[str, Any]:
        return {
            "is_connected": self.is_connected,
            "device_index": self.device_index,
            "resolution": f"{self.resolution[0]}x{self.resolution[1]}" if self.is_connected else "N/A",
            "fps": self.actual_fps if self.is_connected else 0.0,
            "error_message": self.error_message
        }
