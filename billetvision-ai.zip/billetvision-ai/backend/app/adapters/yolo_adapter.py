from pathlib import Path
from typing import List, Dict, Any, Optional
import logging
from app.models.schemas import DefectItem

logger = logging.getLogger("billetvision.yolo")

class YoloModelAdapter:
    """
    Model adapter for YOLO steel billet detection and visible surface defect classification.
    Honest reporting: If weights or library are not loaded, reports is_available=False.
    """
    def __init__(self, weights_path: Optional[str] = None):
        self.weights_path = Path(weights_path) if weights_path else Path(__file__).resolve().parent.parent.parent / "data" / "weights" / "yolov8_steel_billet.pt"
        self.is_available: bool = False
        self.status_message: str = "Checking model weights..."
        self.model = None
        self.supported_defect_classes = [
            "corner_crack",
            "surface_inclusion",
            "rhomboidity",
            "longitudinal_crack",
            "severe_scale",
            "bending_deformation"
        ]
        self._initialize_model()

    def _initialize_model(self):
        try:
            # Check if weights file exists
            if not self.weights_path.exists():
                self.is_available = False
                self.status_message = (
                    f"Model weights file not found at '{self.weights_path.name}'. "
                    "YOLO inference engine is inactive. Operating in Demo Mode or awaiting trained weights."
                )
                return

            # Check if ultralytics can be imported
            import ultralytics # type: ignore
            self.model = ultralytics.YOLO(str(self.weights_path))
            self.is_available = True
            self.status_message = f"YOLO model loaded from {self.weights_path.name} ({len(self.supported_defect_classes)} surface defect classes)."
            logger.info(self.status_message)
        except ImportError:
            self.is_available = False
            self.status_message = (
                "Ultralytics package not installed in environment. "
                "YOLO inference inactive. Provide weights and install ultralytics for live inference."
            )
            logger.warning(self.status_message)
        except Exception as e:
            self.is_available = False
            self.status_message = f"Failed to initialize YOLO model: {str(e)}"
            logger.error(self.status_message)

    def detect_defects(self, frame_bgr) -> List[DefectItem]:
        """
        Executes inference on the steel billet surface.
        Returns list of DefectItem. If model is unavailable, raises RuntimeError or returns empty,
        never fabricating synthetic detections in live inference mode.
        """
        if not self.is_available or self.model is None:
            raise RuntimeError(f"YOLO Defect Model is unavailable: {self.status_message}")

        results = self.model(frame_bgr)
        defects: List[DefectItem] = []
        for r in results:
            for box in r.boxes:
                cls_id = int(box.cls[0])
                cls_name = self.model.names.get(cls_id, f"defect_{cls_id}")
                conf = float(box.conf[0])
                xyxy = box.xyxy[0].tolist()
                defects.append(DefectItem(
                    defect_class=cls_name,
                    confidence=round(conf, 3),
                    bbox=xyxy,
                    severity="CRITICAL" if conf > 0.75 else "MAJOR",
                    description=f"Surface defect {cls_name} detected with {conf*100:.1f}% confidence"
                ))
        return defects

    def get_info(self) -> Dict[str, Any]:
        return {
            "name": "YOLOv8-SteelBillet-Detect",
            "is_available": self.is_available,
            "status_message": self.status_message,
            "supported_defect_classes": self.supported_defect_classes,
            "limitation_notice": "Surface visible defect detection only. Subsurface / internal voids or cracks cannot be confirmed by ordinary optical RGB cameras and require ultrasonic testing (UT)."
        }
