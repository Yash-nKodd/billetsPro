import re
import cv2
import numpy as np
import logging
from typing import Dict, Any, Tuple, Optional

logger = logging.getLogger("billetvision.ocr")

class OCRAdapter:
    """
    Modular OCR adapter for stamped steel billet identification (Heat number & Batch/Billet ID).
    Integrates PaddleOCR if available; provides industrial image preprocessing (CLAHE, thresholding)
    and format extraction.
    """
    def __init__(self):
        self.is_available: bool = False
        self.engine_name: str = "PaddleOCR (Steel Stencil Recognition)"
        self.status_message: str = "Initializing OCR adapter..."
        self.ocr_engine = None
        self._initialize_engine()

    def _initialize_engine(self):
        try:
            import paddleocr # type: ignore
            # Initialize paddleocr with english
            self.ocr_engine = paddleocr.PaddleOCR(use_angle_cls=True, lang='en', show_log=False)
            self.is_available = True
            self.status_message = "PaddleOCR ready and initialized."
            logger.info(self.status_message)
        except ImportError:
            # Check pytesseract fallback
            try:
                import pytesseract # type: ignore
                self.ocr_engine = pytesseract
                self.is_available = True
                self.engine_name = "Tesseract-OCR Fallback Engine"
                self.status_message = "Tesseract OCR engine ready."
            except ImportError:
                self.is_available = False
                self.status_message = (
                    "PaddleOCR/Tesseract not installed in this Python environment. "
                    "Live OCR recognition inactive. Demo mode provides calibrated OCR simulation with operator review."
                )
                logger.info(self.status_message)
        except Exception as e:
            self.is_available = False
            self.status_message = f"Failed to initialize OCR: {str(e)}"
            logger.warning(self.status_message)

    def preprocess_billet_marking(self, crop_bgr: np.ndarray) -> np.ndarray:
        """
        Enhances low-contrast dot-peen, stamped, or spray-painted characters on steel billets.
        Applies grayscale, CLAHE (Contrast Limited Adaptive Histogram Equalization),
        and bilateral noise reduction.
        """
        if crop_bgr is None or crop_bgr.size == 0:
            return crop_bgr

        # Convert to gray
        gray = cv2.cvtColor(crop_bgr, cv2.COLOR_BGR2GRAY) if len(crop_bgr.shape) == 3 else crop_bgr

        # CLAHE for handling uneven mill lighting and dark oxidized steel surface
        clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
        enhanced = clahe.apply(gray)

        # Bilateral filter to smooth scale noise while preserving character edges
        denoised = cv2.bilateralFilter(enhanced, 9, 75, 75)

        return denoised

    def read_text(self, crop_bgr: np.ndarray) -> Tuple[str, float]:
        """
        Runs OCR on cropped marking region.
        Returns: (recognized_raw_text, confidence_0_to_1)
        """
        if not self.is_available or self.ocr_engine is None:
            raise RuntimeError(f"OCR Engine is unavailable: {self.status_message}")

        preprocessed = self.preprocess_billet_marking(crop_bgr)

        # If PaddleOCR
        if hasattr(self.ocr_engine, "ocr"):
            result = self.ocr_engine.ocr(preprocessed, cls=True)
            if not result or not result[0]:
                return "", 0.0
            
            lines = []
            confs = []
            for item in result[0]:
                txt = item[1][0]
                conf = float(item[1][1])
                lines.append(txt)
                confs.append(conf)

            full_text = " ".join(lines)
            avg_conf = sum(confs) / len(confs) if confs else 0.0
            return full_text, round(avg_conf, 3)

        # If Tesseract fallback
        import pytesseract
        data = pytesseract.image_to_data(preprocessed, output_type=pytesseract.Output.DICT)
        confs = [int(c) for c in data['conf'] if int(c) > 0]
        words = [w for w in data['text'] if w.strip()]
        full_text = " ".join(words)
        avg_conf = (sum(confs) / len(confs) / 100.0) if confs else 0.0
        return full_text, round(avg_conf, 3)

    @staticmethod
    def parse_identifiers(raw_text: str) -> Dict[str, Optional[str]]:
        """
        Parses heat number, billet ID, and batch ID from stamped text using industrial regex patterns.
        """
        heat_match = re.search(r'(?:HEAT|HT)[-:\s]*([0-9]{4,6}-[A-Z0-9]+|[0-9]{5,7})', raw_text, re.IGNORECASE)
        billet_match = re.search(r'(?:BLT|BILLET)[-:\s]*([0-9]{4,6}-[0-9]{2,5}|[0-9]{5,8})', raw_text, re.IGNORECASE)
        batch_match = re.search(r'(?:BATCH|BT)[-:\s]*([A-Z0-9\-]{4,20})', raw_text, re.IGNORECASE)

        heat_number = f"HEAT-{heat_match.group(1)}" if heat_match else None
        billet_id = f"BLT-{billet_match.group(1)}" if billet_match else None
        # Clean trailing hyphen if any
        batch_val = batch_match.group(1).rstrip('-') if batch_match else None
        batch_id = f"BATCH-{batch_val}" if batch_val else None

        return {
            "heat_number": heat_number,
            "billet_id": billet_id,
            "batch_id": batch_id
        }

    def get_info(self) -> Dict[str, Any]:
        return {
            "engine_name": self.engine_name,
            "is_available": self.is_available,
            "status_message": self.status_message
        }
