from typing import List, Optional, Any, Dict, Literal
from pydantic import BaseModel, Field
from datetime import datetime

class DefectItem(BaseModel):
    defect_class: str
    confidence: float
    bbox: List[float] = Field(default_factory=list, description="[x, y, width, height] normalized or pixels")
    severity: Literal["CRITICAL", "MAJOR", "MINOR"] = "CRITICAL"
    description: str = ""

class ReviewAuditEvent(BaseModel):
    event_id: str
    timestamp: str
    action: Literal["CONFIRM", "CORRECT_ID", "REINSPECT", "RESOLVE"]
    operator: str
    notes: str = ""
    original_val: Optional[str] = None
    new_val: Optional[str] = None

class BilletInspection(BaseModel):
    inspection_id: str
    billet_id: str
    heat_number: str
    batch_id: str
    timestamp: str
    length_mm: float
    width_mm: float
    height_mm: Optional[float] = None
    calibration_id: str = "CAL-STD-01"
    measurement_uncertainty: Optional[float] = 2.5
    ocr_raw_text: str = ""
    ocr_confidence: float = 0.0
    defect_results: List[DefectItem] = Field(default_factory=list)
    status: Literal["PASS", "FAIL", "REVIEW"] = "PASS"
    reason: str = "Nominal inspection passed all manufacturing rules"
    processing_latency_ms: float = 0.0
    frame_reference: str = ""
    source_mode: Literal["DEMO", "LIVE", "UPLOAD"] = "DEMO"
    configuration_version: str = "v1.2.0"
    review_audit_events: List[ReviewAuditEvent] = Field(default_factory=list)
    reviewed_by: Optional[str] = None
    reviewed_at: Optional[str] = None

class BilletInspectionCreate(BaseModel):
    billet_id: Optional[str] = None
    heat_number: Optional[str] = None
    batch_id: Optional[str] = None
    length_mm: float
    width_mm: float
    height_mm: Optional[float] = None
    calibration_id: str = "CAL-STD-01"
    measurement_uncertainty: Optional[float] = 2.5
    ocr_raw_text: str = ""
    ocr_confidence: float = 0.0
    defect_results: List[DefectItem] = Field(default_factory=list)
    processing_latency_ms: float = 0.0
    frame_reference: Optional[str] = ""
    source_mode: Literal["DEMO", "LIVE", "UPLOAD"] = "DEMO"

class CorrectionRequest(BaseModel):
    action: Literal["CONFIRM", "CORRECT_ID", "REINSPECT", "RESOLVE"]
    operator: str
    notes: str = ""
    corrected_billet_id: Optional[str] = None
    corrected_heat_number: Optional[str] = None
    resolved_status: Optional[Literal["PASS", "FAIL"]] = None

class ToleranceConfig(BaseModel):
    version: str = "v1.2.0"
    target_length_mm: float = 12000.0
    length_tolerance_pos_mm: float = 50.0
    length_tolerance_neg_mm: float = 30.0
    target_width_mm: float = 150.0
    width_tolerance_pos_mm: float = 3.0
    width_tolerance_neg_mm: float = 3.0
    target_height_mm: Optional[float] = None
    height_tolerance_pos_mm: Optional[float] = None
    height_tolerance_neg_mm: Optional[float] = None
    min_ocr_confidence: float = 0.70
    disallowed_defects: List[str] = [
        "corner_crack",
        "surface_inclusion",
        "rhomboidity",
        "longitudinal_crack",
        "severe_scale"
    ]
    duplicate_suppression_window_s: float = 3.0
    inspection_zone_trigger_x: float = 0.50

class CalibrationConfig(BaseModel):
    calibration_id: str = "CAL-STD-01"
    known_reference_length_mm: float = 1000.0
    pixel_distance_px: float = 500.0
    scale_mm_per_px: float = 2.0
    measurement_plane: Literal["TOP_SURFACE_CONVEYOR", "SIDE_PROFILE"] = "TOP_SURFACE_CONVEYOR"
    is_calibrated: bool = True
    camera_distance_mm: float = 2400.0
    calibration_timestamp: str = ""
    estimated_uncertainty_mm: float = 2.5
    notes: str = "Factory standard steel billet conveyor overhead camera calibration"

class AlertItem(BaseModel):
    alert_id: str
    timestamp: str
    severity: Literal["CRITICAL", "WARNING", "INFO"]
    title: str
    message: str
    associated_billet_id: Optional[str] = None
    inspection_id: Optional[str] = None
    acknowledged: bool = False
    acknowledged_by: Optional[str] = None
    acknowledged_at: Optional[str] = None

class SystemStatus(BaseModel):
    app_name: str = "BilletVision AI"
    version: str = "v1.2.0"
    active_mode: Literal["DEMO", "LIVE"] = "DEMO"
    camera_available: bool = False
    camera_device_name: Optional[str] = None
    fps: float = 0.0
    model_yolo_available: bool = False
    model_yolo_name: str = "YOLOv8-SteelBillet-Detect (Adapter)"
    model_yolo_status: str = "Weights not loaded (Operating in demo / manual upload mode)"
    model_ocr_available: bool = False
    model_ocr_name: str = "PaddleOCR Steel Stencil Recognition"
    model_ocr_status: str = "OCR service active"
    database_connected: bool = True
    database_type: str = "SQLite (Local Storage Repository)"
    calibrated: bool = True
    total_inspections_stored: int = 0
    pending_reviews_count: int = 0

class OverviewMetrics(BaseModel):
    inspected_count: int
    pass_count: int
    fail_count: int
    review_count: int
    pass_rate_pct: float
    avg_latency_ms: float
    fps: float
    ocr_accuracy_pct: float
    latest_alerts: List[AlertItem]
    recent_inspections: List[BilletInspection]

class QualityTrendPoint(BaseModel):
    date: str
    inspected: int
    passed: int
    failed: int
    reviewed: int
    pass_rate: float

class QualityAnalytics(BaseModel):
    total_count: int
    pass_rate_pct: float
    defect_rate_pct: float
    review_rate_pct: float
    avg_length_mm: float
    avg_width_mm: float
    length_std_dev: float
    width_std_dev: float
    defect_distribution: Dict[str, int]
    daily_trends: List[QualityTrendPoint]
    batch_comparison: List[Dict[str, Any]]
    drift_warning: Optional[str] = None
    preliminary_notice: Optional[str] = None
