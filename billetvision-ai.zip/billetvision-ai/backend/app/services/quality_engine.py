from typing import Tuple, List, Optional
from app.models.schemas import ToleranceConfig, DefectItem

class QualityDecisionEngine:
    def __init__(self, config: ToleranceConfig):
        self.config = config

    def evaluate(
        self,
        length_mm: float,
        width_mm: float,
        height_mm: Optional[float],
        ocr_text: str,
        ocr_confidence: float,
        defects: List[DefectItem],
        is_calibrated: bool = True
    ) -> Tuple[str, str]:
        """
        Evaluates inspection data against tolerance rules.
        Returns:
            (status: "PASS" | "FAIL" | "REVIEW", reason: str)
        """
        reasons_fail: List[str] = []
        reasons_review: List[str] = []

        # 1. Calibration check
        if not is_calibrated:
            reasons_review.append("Dimensional calibration missing or unvalidated; physical dimensions cannot be certified")

        # 2. Length check
        min_len = self.config.target_length_mm - self.config.length_tolerance_neg_mm
        max_len = self.config.target_length_mm + self.config.length_tolerance_pos_mm
        if length_mm < min_len:
            reasons_fail.append(f"Length {length_mm:.1f} mm is below minimum tolerance ({min_len:.1f} mm, -{self.config.length_tolerance_neg_mm} mm)")
        elif length_mm > max_len:
            reasons_fail.append(f"Length {length_mm:.1f} mm exceeds maximum tolerance ({max_len:.1f} mm, +{self.config.length_tolerance_pos_mm} mm)")

        # 3. Width check
        min_wid = self.config.target_width_mm - self.config.width_tolerance_neg_mm
        max_wid = self.config.target_width_mm + self.config.width_tolerance_pos_mm
        if width_mm < min_wid:
            reasons_fail.append(f"Width {width_mm:.1f} mm is below minimum tolerance ({min_wid:.1f} mm, -{self.config.width_tolerance_neg_mm} mm)")
        elif width_mm > max_wid:
            reasons_fail.append(f"Width {width_mm:.1f} mm exceeds maximum tolerance ({max_wid:.1f} mm, +{self.config.width_tolerance_pos_mm} mm)")

        # 4. Optional Height check (only if target height configured and height is measured)
        if self.config.target_height_mm is not None and height_mm is not None:
            min_h = self.config.target_height_mm - (self.config.height_tolerance_neg_mm or 3.0)
            max_h = self.config.target_height_mm + (self.config.height_tolerance_pos_mm or 3.0)
            if height_mm < min_h:
                reasons_fail.append(f"Height {height_mm:.1f} mm is below minimum tolerance ({min_h:.1f} mm)")
            elif height_mm > max_h:
                reasons_fail.append(f"Height {height_mm:.1f} mm exceeds maximum tolerance ({max_h:.1f} mm)")

        # 5. Defect inspection check
        for d in defects:
            if d.defect_class.lower() in [x.lower() for x in self.config.disallowed_defects]:
                if d.confidence >= 0.60:
                    reasons_fail.append(f"Disallowed surface defect detected: '{d.defect_class}' ({d.confidence*100:.1f}% conf, severity: {d.severity})")
                else:
                    reasons_review.append(f"Borderline defect detection: '{d.defect_class}' ({d.confidence*100:.1f}% conf) requires visual verification")

        # 6. OCR and Identity verification check
        # We separate identity confidence: low OCR confidence triggers REVIEW, not immediate scrap FAIL
        clean_text = ocr_text.strip() if ocr_text else ""
        if not clean_text:
            reasons_review.append("OCR marking empty or undetectable on billet surface: operator ID verification required")
        elif ocr_confidence < self.config.min_ocr_confidence:
            reasons_review.append(f"Low OCR confidence ({ocr_confidence*100:.1f}% < {self.config.min_ocr_confidence*100:.1f}% target): heat/billet ID requires review")

        # Determine Final Decision: FAIL takes precedence over REVIEW
        if reasons_fail:
            return "FAIL", "; ".join(reasons_fail)
        if reasons_review:
            return "REVIEW", "; ".join(reasons_review)

        return "PASS", f"All manufacturing checks passed (Rule config {self.config.version})"
