import numpy as np
from typing import Dict, Any, Optional, Tuple
from app.models.schemas import CalibrationConfig

class DimensionalMeasurementEngine:
    def __init__(self, calibration: CalibrationConfig):
        self.calibration = calibration

    def compute_dimensions_from_pixels(
        self,
        pixel_length: float,
        pixel_width: float,
        pixel_height: Optional[float] = None
    ) -> Dict[str, Any]:
        """
        Converts pixel measurements to millimetres based on calibrated reference scale.
        """
        if not self.calibration.is_calibrated or self.calibration.scale_mm_per_px <= 0:
            return {
                "is_calibrated": False,
                "length_mm": round(pixel_length * 2.0, 1), # Fallback estimate
                "width_mm": round(pixel_width * 2.0, 1),
                "height_mm": None,
                "uncertainty_mm": None,
                "status": "UNCALIBRATED",
                "warning": "Measurement scale uncalibrated. Values are raw approximations."
            }

        scale = self.calibration.scale_mm_per_px
        length_mm = round(pixel_length * scale, 1)
        width_mm = round(pixel_width * scale, 1)

        # Height is strictly unavailable from top-down 2D camera geometry
        height_mm = None
        if self.calibration.measurement_plane == "SIDE_PROFILE" and pixel_height is not None:
            height_mm = round(pixel_height * scale, 1)

        # Estimated uncertainty: propagated based on pixel resolution and camera distance
        uncertainty = self.calibration.estimated_uncertainty_mm

        return {
            "is_calibrated": True,
            "length_mm": length_mm,
            "width_mm": width_mm,
            "height_mm": height_mm,
            "uncertainty_mm": uncertainty,
            "status": "VALID",
            "scale_mm_per_px": scale,
            "calibration_id": self.calibration.calibration_id
        }

    @staticmethod
    def calculate_scale(known_length_mm: float, pixel_distance_px: float) -> float:
        if pixel_distance_px <= 0:
            raise ValueError("Pixel distance must be greater than zero.")
        return round(known_length_mm / pixel_distance_px, 4)
