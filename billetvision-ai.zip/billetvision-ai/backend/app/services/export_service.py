import os
import json
import time
from pathlib import Path
from typing import List, Optional
from datetime import datetime
import pandas as pd
from app.config import EXPORTS_DIR
from app.models.schemas import BilletInspection

class ExportService:
    def __init__(self):
        EXPORTS_DIR.mkdir(parents=True, exist_ok=True)

    def _inspections_to_dataframe(self, inspections: List[BilletInspection]) -> pd.DataFrame:
        data = []
        for item in inspections:
            defect_summary = ", ".join([f"{d.defect_class}({int(d.confidence*100)}%)" for d in item.defect_results])
            data.append({
                "Inspection ID": item.inspection_id,
                "Billet ID": item.billet_id,
                "Heat Number": item.heat_number,
                "Batch ID": item.batch_id,
                "Timestamp (ISO)": item.timestamp,
                "Quality Status": item.status,
                "Reason / Decision": item.reason,
                "Length (mm)": item.length_mm,
                "Width (mm)": item.width_mm,
                "Height (mm)": item.height_mm if item.height_mm is not None else "N/A",
                "Uncertainty (mm)": f"±{item.measurement_uncertainty}" if item.measurement_uncertainty is not None else "N/A",
                "OCR Raw Text": item.ocr_raw_text,
                "OCR Confidence (%)": round(item.ocr_confidence * 100, 1),
                "Defects Detected": defect_summary if defect_summary else "None",
                "Processing Latency (ms)": item.processing_latency_ms,
                "Source Mode": item.source_mode,
                "Config Version": item.configuration_version,
                "Reviewed By": item.reviewed_by or "N/A",
                "Reviewed At": item.reviewed_at or "N/A"
            })
        return pd.DataFrame(data)

    def export_csv(self, inspections: List[BilletInspection], filename_prefix: str = "billet_inspections") -> str:
        """
        Exports inspections to CSV. Returns the generated file path.
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{filename_prefix}_{timestamp}.csv"
        file_path = EXPORTS_DIR / filename

        df = self._inspections_to_dataframe(inspections)
        # Write safely with atomic replacement or direct save
        temp_path = EXPORTS_DIR / f"temp_{filename}"
        df.to_csv(temp_path, index=False, encoding="utf-8-sig")
        
        # Rename to target file
        if file_path.exists():
            file_path.unlink()
        temp_path.rename(file_path)
        return str(file_path)

    def export_xlsx(self, inspections: List[BilletInspection], filename_prefix: str = "billet_inspections") -> str:
        """
        Exports inspections to XLSX with detailed records sheet and executive summary sheet.
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{filename_prefix}_{timestamp}.xlsx"
        file_path = EXPORTS_DIR / filename

        df_records = self._inspections_to_dataframe(inspections)

        # Summary statistics
        total = len(inspections)
        passes = sum(1 for i in inspections if i.status == "PASS")
        fails = sum(1 for i in inspections if i.status == "FAIL")
        reviews = sum(1 for i in inspections if i.status == "REVIEW")
        pass_rate = round(passes / total * 100, 1) if total > 0 else 0.0

        avg_len = round(sum(i.length_mm for i in inspections) / total, 1) if total > 0 else 0.0
        avg_wid = round(sum(i.width_mm for i in inspections) / total, 1) if total > 0 else 0.0

        summary_data = [
            {"Metric": "Report Title", "Value": "BilletVision AI Traceability Inspection Report"},
            {"Metric": "Generated Timestamp", "Value": datetime.now().isoformat()},
            {"Metric": "Total Inspected Billets", "Value": total},
            {"Metric": "Passed Billets (PASS)", "Value": passes},
            {"Metric": "Failed Billets (FAIL)", "Value": fails},
            {"Metric": "Under Review (REVIEW)", "Value": reviews},
            {"Metric": "Overall Pass Rate", "Value": f"{pass_rate}%"},
            {"Metric": "Average Length (mm)", "Value": avg_len},
            {"Metric": "Average Width (mm)", "Value": avg_wid},
        ]
        df_summary = pd.DataFrame(summary_data)

        temp_path = EXPORTS_DIR / f"temp_{filename}"
        with pd.ExcelWriter(temp_path, engine="openpyxl") as writer:
            df_records.to_excel(writer, sheet_name="Inspection Records", index=False)
            df_summary.to_excel(writer, sheet_name="Executive Summary", index=False)

        if file_path.exists():
            file_path.unlink()
        temp_path.rename(file_path)
        return str(file_path)
