import os
from pathlib import Path
from datetime import datetime, timedelta
from typing import List, Dict, Any
from PIL import Image, ImageDraw, ImageFont
from app.config import IMAGES_DIR
from app.models.schemas import BilletInspection, DefectItem, ReviewAuditEvent, AlertItem

class DemoGenerator:
    """
    Generates labelled sample data, realistic synthetic steel billet frames,
    and runs the 3 mandated test scenarios without requiring physical cameras or external weights.
    """
    def __init__(self):
        IMAGES_DIR.mkdir(parents=True, exist_ok=True)

    def _draw_synthetic_billet(
        self,
        billet_id: str,
        heat_number: str,
        status: str,
        dimensions: str,
        defects: List[DefectItem],
        blur_marking: bool = False
    ) -> str:
        """
        Draws a realistic steel billet on an industrial conveyor roller bed with camera overlay.
        Saves to IMAGES_DIR and returns the relative/absolute file path.
        """
        width, height = 960, 540
        img = Image.new("RGB", (width, height), color=(18, 24, 38))
        draw = ImageDraw.Draw(img)

        # Draw conveyor rollers (metallic cylinders)
        for rx in range(0, width, 80):
            draw.rectangle([rx, 0, rx + 65, height], fill=(28, 36, 52), outline=(38, 48, 70), width=1)
            # Roller highlight
            draw.line([rx + 10, 0, rx + 10, height], fill=(45, 58, 85), width=2)

        # Draw steel billet body (hot-rolled dark steel with slight metallic hue)
        # Steel billet centered horizontally
        by1, by2 = 140, 400
        bx1, bx2 = 60, 900
        draw.rectangle([bx1, by1, bx2, by2], fill=(62, 68, 78), outline=(90, 100, 118), width=3)

        # Steel surface texture / longitudinal grain lines
        for y_grain in range(by1 + 15, by2 - 15, 25):
            draw.line([bx1 + 10, y_grain, bx2 - 10, y_grain], fill=(52, 58, 68), width=2)

        # Billet Chamfered Edges (Steel profile 3D bevel)
        draw.line([bx1, by1, bx2, by1], fill=(120, 130, 148), width=2)
        draw.line([bx1, by2, bx2, by2], fill=(35, 40, 50), width=3)

        # Draw stamped stencil marking region
        mark_x1, mark_y1, mark_x2, mark_y2 = 120, 200, 480, 270
        draw.rectangle([mark_x1, mark_y1, mark_x2, mark_y2], fill=(45, 50, 60), outline=(75, 85, 100), width=1)
        
        # Stencil text on steel
        stencil_text = f"{heat_number}  |  {billet_id}"
        if blur_marking:
            stencil_text = "H..T-8?92-B  |  BLT-2026-????"

        text_color = (130, 140, 155) if blur_marking else (235, 240, 250)
        draw.text((mark_x1 + 15, mark_y1 + 18), stencil_text, fill=text_color)
        draw.text((mark_x1 + 15, mark_y1 + 42), "HOT-ROLLED STRUCTURAL GRADE S355JR", fill=(110, 120, 135))

        # Optical inspection bounding box & calibration overlay
        # Billet Bounding Box
        status_color = (16, 185, 129) if status == "PASS" else ((239, 68, 68) if status == "FAIL" else (245, 158, 11))
        draw.rectangle([bx1 - 4, by1 - 4, bx2 + 4, by2 + 4], outline=status_color, width=2)
        
        # Bounding box label
        draw.rectangle([bx1 - 4, by1 - 28, bx1 + 220, by1 - 4], fill=status_color)
        draw.text((bx1 + 4, by1 - 24), f"STEEL BILLET  [{status}]", fill=(0, 0, 0))

        # Measurement caliper lines
        draw.line([bx1, by2 + 25, bx2, by2 + 25], fill=(6, 182, 212), width=2)
        draw.line([bx1, by2 + 15, bx1, by2 + 35], fill=(6, 182, 212), width=2)
        draw.line([bx2, by2 + 15, bx2, by2 + 35], fill=(6, 182, 212), width=2)
        draw.text((bx1 + 320, by2 + 32), f"CALIBRATED LENGTH: {dimensions.split('x')[0].strip()}", fill=(6, 182, 212))

        # Draw defects if any
        for d in defects:
            if d.bbox and len(d.bbox) == 4:
                dx, dy, dw, dh = d.bbox
                draw.rectangle([dx, dy, dx + dw, dy + dh], outline=(239, 68, 68), width=3)
                # Defect indicator
                draw.rectangle([dx, dy - 22, dx + 180, dy], fill=(239, 68, 68))
                draw.text((dx + 4, dy - 18), f"{d.defect_class.upper()} {int(d.confidence*100)}%", fill=(255, 255, 255))

        # Industrial HUD overlay (Control Room Camera HUD)
        draw.rectangle([20, 20, 320, 75], fill=(10, 14, 22))
        draw.rectangle([20, 20, 320, 75], outline=(38, 48, 70), width=1)
        draw.text((30, 26), "BILLETVISION AI  •  ZONE-1 CAM-OVERHEAD", fill=(6, 182, 212))
        draw.text((30, 48), f"MODE: DEMO SCENARIO  |  STATUS: {status}", fill=status_color)

        # Reticle in center
        cx, cy = width // 2, height // 2
        draw.line([cx - 20, cy, cx + 20, cy], fill=(6, 182, 212), width=1)
        draw.line([cx, cy - 20, cx, cy + 20], fill=(6, 182, 212), width=1)

        filename = f"frame_{billet_id}_{status.lower()}.jpg"
        save_path = IMAGES_DIR / filename
        img.save(save_path, "JPEG", quality=90)
        return f"/data/images/{filename}"

    def get_scenario_1_pass(self) -> Dict[str, Any]:
        """
        Scenario 1: Billet within manufacturing tolerance.
        All checks PASS.
        """
        billet_id = "BLT-2026-1042"
        heat_number = "HEAT-8492-B"
        batch_id = "BATCH-2026-Q3-01"
        length_mm = 12005.0
        width_mm = 150.2
        frame_ref = self._draw_synthetic_billet(
            billet_id=billet_id,
            heat_number=heat_number,
            status="PASS",
            dimensions=f"{length_mm} mm x {width_mm} mm",
            defects=[]
        )

        inspection = BilletInspection(
            inspection_id="INSP-DEMO-001",
            billet_id=billet_id,
            heat_number=heat_number,
            batch_id=batch_id,
            timestamp=datetime.now().isoformat(),
            length_mm=length_mm,
            width_mm=width_mm,
            height_mm=None,
            calibration_id="CAL-STD-01",
            measurement_uncertainty=2.5,
            ocr_raw_text=f"{heat_number} {billet_id} GRADE-S355JR",
            ocr_confidence=0.96,
            defect_results=[],
            status="PASS",
            reason="All manufacturing checks passed: length 12005.0 mm within [-30.0, +50.0] mm, width 150.2 mm within [-3.0, +3.0] mm, no surface defects, OCR confidence 96.0%",
            processing_latency_ms=38.4,
            frame_reference=frame_ref,
            source_mode="DEMO",
            configuration_version="v1.2.0"
        )
        return {"scenario_name": "Scenario 1: Within Tolerance (PASS)", "inspection": inspection}

    def get_scenario_2_fail(self) -> Dict[str, Any]:
        """
        Scenario 2: Billet outside tolerance (Length out-of-spec + Corner Crack detected).
        Status FAIL.
        """
        billet_id = "BLT-2026-1043"
        heat_number = "HEAT-8492-B"
        batch_id = "BATCH-2026-Q3-01"
        length_mm = 12118.0 # +118 mm exceeds +50 mm
        width_mm = 154.2   # +4.2 mm exceeds +3 mm
        defects = [
            DefectItem(
                defect_class="corner_crack",
                confidence=0.88,
                bbox=[580, 160, 95, 55],
                severity="CRITICAL",
                description="Transverse corner crack exceeding 25mm length on cooling edge"
            )
        ]
        frame_ref = self._draw_synthetic_billet(
            billet_id=billet_id,
            heat_number=heat_number,
            status="FAIL",
            dimensions=f"{length_mm} mm x {width_mm} mm",
            defects=defects
        )

        inspection = BilletInspection(
            inspection_id="INSP-DEMO-002",
            billet_id=billet_id,
            heat_number=heat_number,
            batch_id=batch_id,
            timestamp=datetime.now().isoformat(),
            length_mm=length_mm,
            width_mm=width_mm,
            height_mm=None,
            calibration_id="CAL-STD-01",
            measurement_uncertainty=2.5,
            ocr_raw_text=f"{heat_number} {billet_id}",
            ocr_confidence=0.91,
            defect_results=defects,
            status="FAIL",
            reason="Length 12118.0 mm exceeds maximum tolerance (12050.0 mm, +50.0 mm); Width 154.2 mm exceeds maximum tolerance (153.0 mm, +3.0 mm); Disallowed surface defect detected: 'corner_crack' (88.0% conf, severity: CRITICAL)",
            processing_latency_ms=44.1,
            frame_reference=frame_ref,
            source_mode="DEMO",
            configuration_version="v1.2.0"
        )

        alert = AlertItem(
            alert_id="ALT-DEMO-002",
            timestamp=datetime.now().isoformat(),
            severity="CRITICAL",
            title="Tolerance & Defect Rejection (FAIL)",
            message=f"Billet {billet_id} rejected: Length +118mm out of spec; corner crack detected.",
            associated_billet_id=billet_id,
            inspection_id="INSP-DEMO-002"
        )

        return {"scenario_name": "Scenario 2: Out of Tolerance & Defect (FAIL)", "inspection": inspection, "alert": alert}

    def get_scenario_3_review(self) -> Dict[str, Any]:
        """
        Scenario 3: Unreadable / degraded stencil marking requiring operator verification.
        Status REVIEW.
        """
        billet_id = "BLT-2026-UNREADABLE"
        heat_number = "HEAT-8492-UNKNOWN"
        batch_id = "BATCH-2026-Q3-01"
        length_mm = 12012.0
        width_mm = 150.1
        frame_ref = self._draw_synthetic_billet(
            billet_id=billet_id,
            heat_number=heat_number,
            status="REVIEW",
            dimensions=f"{length_mm} mm x {width_mm} mm",
            defects=[],
            blur_marking=True
        )

        inspection = BilletInspection(
            inspection_id="INSP-DEMO-003",
            billet_id=billet_id,
            heat_number=heat_number,
            batch_id=batch_id,
            timestamp=datetime.now().isoformat(),
            length_mm=length_mm,
            width_mm=width_mm,
            height_mm=None,
            calibration_id="CAL-STD-01",
            measurement_uncertainty=2.5,
            ocr_raw_text="H..T-8?92-B | BLT-2026-????",
            ocr_confidence=0.48, # low confidence
            defect_results=[],
            status="REVIEW",
            reason="Low OCR confidence (48.0% < 70.0% target): heat/billet ID requires review; Ambiguous identifier stencil requires operator manual confirmation",
            processing_latency_ms=51.2,
            frame_reference=frame_ref,
            source_mode="DEMO",
            configuration_version="v1.2.0"
        )

        alert = AlertItem(
            alert_id="ALT-DEMO-003",
            timestamp=datetime.now().isoformat(),
            severity="WARNING",
            title="Identifier Ambiguity / OCR Degraded (REVIEW)",
            message=f"Billet marking degraded (48% conf). Operator manual identification required.",
            associated_billet_id=billet_id,
            inspection_id="INSP-DEMO-003"
        )

        return {"scenario_name": "Scenario 3: Unreadable Identifier (REVIEW)", "inspection": inspection, "alert": alert}

    def generate_seed_dataset(self) -> List[BilletInspection]:
        """
        Generates realistic initial batch of steel billets for initial inspection history and analytics.
        """
        items = []
        base_time = datetime.now() - timedelta(days=2)

        # Add the 3 standard demo scenarios
        s1 = self.get_scenario_1_pass()["inspection"]
        s2 = self.get_scenario_2_fail()["inspection"]
        s3 = self.get_scenario_3_review()["inspection"]
        items.extend([s1, s2, s3])

        # Add 7 more varied items across the last 48 hours for rich charts and analytics
        records_spec = [
            ("BLT-2026-1035", "HEAT-8490-A", "BATCH-2026-Q3-01", 12002.0, 150.1, "PASS", 0.95, [], 42.0),
            ("BLT-2026-1036", "HEAT-8490-A", "BATCH-2026-Q3-01", 11995.0, 149.8, "PASS", 0.94, [], 39.5),
            ("BLT-2026-1037", "HEAT-8490-A", "BATCH-2026-Q3-01", 12065.0, 150.3, "FAIL", 0.92, [], 41.2),
            ("BLT-2026-1038", "HEAT-8491-A", "BATCH-2026-Q3-02", 12008.0, 150.0, "PASS", 0.97, [], 40.0),
            ("BLT-2026-1039", "HEAT-8491-A", "BATCH-2026-Q3-02", 12004.0, 150.2, "PASS", 0.93, [], 37.8),
            ("BLT-2026-1040", "HEAT-8491-A", "BATCH-2026-Q3-02", 12010.0, 151.2, "PASS", 0.96, [], 38.6),
            ("BLT-2026-1041", "HEAT-8492-B", "BATCH-2026-Q3-01", 12015.0, 150.5, "PASS", 0.95, [], 39.1),
        ]

        for i, (bid, heat, batch, l, w, st, ocr_c, defs, lat) in enumerate(records_spec):
            t = (base_time + timedelta(hours=i*4)).isoformat()
            insp_id = f"INSP-HIST-10{35+i}"
            fref = self._draw_synthetic_billet(
                billet_id=bid,
                heat_number=heat,
                status=st,
                dimensions=f"{l} mm x {w} mm",
                defects=defs
            )
            items.append(BilletInspection(
                inspection_id=insp_id,
                billet_id=bid,
                heat_number=heat,
                batch_id=batch,
                timestamp=t,
                length_mm=l,
                width_mm=w,
                height_mm=None,
                calibration_id="CAL-STD-01",
                measurement_uncertainty=2.5,
                ocr_raw_text=f"{heat} {bid}",
                ocr_confidence=ocr_c,
                defect_results=defs,
                status=st,
                reason="All manufacturing checks passed" if st == "PASS" else "Length 12065.0 mm exceeds upper tolerance (+50.0 mm)",
                processing_latency_ms=lat,
                frame_reference=fref,
                source_mode="DEMO",
                configuration_version="v1.2.0"
            ))

        return items
