import time
from typing import Dict, Set

class DuplicateSuppressionManager:
    def __init__(self, suppression_window_s: float = 3.0, trigger_x: float = 0.5):
        self.suppression_window_s = suppression_window_s
        self.trigger_x = trigger_x
        # maps tracking_id or billet_id to timestamp of last completed inspection
        self.recent_inspections: Dict[str, float] = {}
        # tracks previous positions of tracked billets: id -> last_x
        self.tracked_positions: Dict[str, float] = {}

    def clean_old_records(self, now: float):
        cutoff = now - (self.suppression_window_s * 5)
        to_del = [k for k, t in self.recent_inspections.items() if t < cutoff]
        for k in to_del:
            del self.recent_inspections[k]

    def should_trigger_inspection(
        self,
        tracking_id: str,
        current_x: float,
        previous_x: float,
        now: float | None = None
    ) -> bool:
        """
        Evaluates whether a billet crossing the inspection line should trigger a new inspection.
        Returns True only once as the billet crosses trigger_x and if suppression window has elapsed.
        """
        if now is None:
            now = time.time()

        self.clean_old_records(now)

        # Check if already inspected recently
        last_time = self.recent_inspections.get(tracking_id)
        if last_time and (now - last_time) < self.suppression_window_s:
            return False

        # Line crossing check: previous_x <= trigger_x < current_x (left to right)
        # or previous_x >= trigger_x > current_x (right to left)
        crossed = (previous_x <= self.trigger_x <= current_x) or (previous_x >= self.trigger_x >= current_x)

        if crossed:
            self.recent_inspections[tracking_id] = now
            return True

        return False

    def mark_inspected(self, tracking_id: str, now: float | None = None):
        if now is None:
            now = time.time()
        self.recent_inspections[tracking_id] = now
