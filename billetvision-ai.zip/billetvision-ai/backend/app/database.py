import sqlite3
import json
import logging
from pathlib import Path
from contextlib import contextmanager
from app.config import DB_PATH

logger = logging.getLogger("billetvision.database")

def get_db_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

@contextmanager
def get_db():
    conn = get_db_connection()
    try:
        yield conn
        conn.commit()
    except Exception as e:
        conn.rollback()
        logger.error(f"Database error during transaction: {e}")
        raise
    finally:
        conn.close()

def init_db():
    """Initializes SQLite schema for BilletVision AI."""
    with get_db() as conn:
        cursor = conn.cursor()
        
        # Inspections table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS inspections (
            inspection_id TEXT PRIMARY KEY,
            billet_id TEXT NOT NULL,
            heat_number TEXT NOT NULL,
            batch_id TEXT NOT NULL,
            timestamp TEXT NOT NULL,
            length_mm REAL NOT NULL,
            width_mm REAL NOT NULL,
            height_mm REAL,
            calibration_id TEXT NOT NULL,
            measurement_uncertainty REAL,
            ocr_raw_text TEXT,
            ocr_confidence REAL NOT NULL,
            defect_results TEXT NOT NULL, -- JSON string
            status TEXT NOT NULL,         -- PASS, FAIL, REVIEW
            reason TEXT NOT NULL,
            processing_latency_ms REAL NOT NULL,
            frame_reference TEXT,
            source_mode TEXT NOT NULL,    -- DEMO, LIVE, UPLOAD
            configuration_version TEXT NOT NULL,
            review_audit_events TEXT NOT NULL, -- JSON string
            reviewed_by TEXT,
            reviewed_at TEXT
        );
        """)
        
        # Create helpful indices
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_inspections_timestamp ON inspections(timestamp DESC);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_inspections_billet_id ON inspections(billet_id);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_inspections_heat_number ON inspections(heat_number);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_inspections_batch_id ON inspections(batch_id);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_inspections_status ON inspections(status);")

        # Alerts table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS alerts (
            alert_id TEXT PRIMARY KEY,
            timestamp TEXT NOT NULL,
            severity TEXT NOT NULL,
            title TEXT NOT NULL,
            message TEXT NOT NULL,
            associated_billet_id TEXT,
            inspection_id TEXT,
            acknowledged INTEGER NOT NULL DEFAULT 0,
            acknowledged_by TEXT,
            acknowledged_at TEXT
        );
        """)
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_alerts_timestamp ON alerts(timestamp DESC);")

        # Tolerances & Configuration table (keyed by config_key)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS configurations (
            config_key TEXT PRIMARY KEY,
            config_value TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        """)

        # System Audit Log
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS audit_logs (
            log_id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            category TEXT NOT NULL,
            operator TEXT NOT NULL,
            action TEXT NOT NULL,
            details TEXT NOT NULL
        );
        """)

        conn.commit()
        logger.info("Database schema initialized successfully.")
