import os
from pathlib import Path
from pydantic import BaseModel

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
IMAGES_DIR = DATA_DIR / "images"
EXPORTS_DIR = DATA_DIR / "exports"
DB_PATH = DATA_DIR / "billetvision.db"

# Ensure data directories exist
DATA_DIR.mkdir(exist_ok=True, parents=True)
IMAGES_DIR.mkdir(exist_ok=True, parents=True)
EXPORTS_DIR.mkdir(exist_ok=True, parents=True)

class SystemSettings(BaseModel):
    version: str = "v1.2.0"
    app_name: str = "BilletVision AI"
    target_length_mm: float = 12000.0
    length_tolerance_pos_mm: float = 50.0
    length_tolerance_neg_mm: float = 30.0
    target_width_mm: float = 150.0
    width_tolerance_pos_mm: float = 3.0
    width_tolerance_neg_mm: float = 3.0
    target_height_mm: float | None = None
    height_tolerance_pos_mm: float | None = None
    height_tolerance_neg_mm: float | None = None
    min_ocr_confidence: float = 0.70
    disallowed_defects: list[str] = [
        "corner_crack",
        "surface_inclusion",
        "rhomboidity",
        "longitudinal_crack",
        "severe_scale"
    ]
    duplicate_suppression_window_s: float = 3.0
    inspection_zone_trigger_x: float = 0.50
    default_source_mode: str = "DEMO"
