import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pathlib import Path

from app.database import init_db
from app.routes.api import router as api_router
from app.config import DATA_DIR, IMAGES_DIR, EXPORTS_DIR
from app.services.demo_generator import DemoGenerator
from app.repositories.inspection_repo import InspectionRepository

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger("billetvision")

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Initializing BilletVision AI database...")
    init_db()
    
    # Auto-seed if database is empty to guarantee working demo immediately
    repo = InspectionRepository()
    _, total = repo.list_inspections(limit=1)
    if total == 0:
        logger.info("Initial empty database detected. Seeding demo steel billet records...")
        generator = DemoGenerator()
        seeds = generator.generate_seed_dataset()
        for item in seeds:
            repo.insert_inspection(item)
        logger.info(f"Seeded {len(seeds)} sample billet records.")

    yield
    logger.info("Shutting down BilletVision AI...")

app = FastAPI(
    title="BilletVision AI Backend API",
    description="Industrial Steel Billet Vision Inspection, Calibrated Dimensional Measurement & Traceability Engine",
    version="1.2.0",
    lifespan=lifespan
)

# CORS middleware for development and control room network
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount static file directory for inspection images and exports
app.mount("/data/images", StaticFiles(directory=str(IMAGES_DIR)), name="images")
app.mount("/data/exports", StaticFiles(directory=str(EXPORTS_DIR)), name="exports")

# Include API router
app.include_router(api_router)

@app.get("/")
def root():
    return {
        "app": "BilletVision AI",
        "description": "Industrial Steel Billet Optical Quality & Traceability Inspection System",
        "docs_url": "/docs",
        "health_url": "/api/health",
        "status_url": "/api/status"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="127.0.0.1", port=8000, reload=True)
