import pytest
import uuid
from datetime import datetime
from app.database import init_db
from app.models.schemas import BilletInspection, DefectItem
from app.repositories.inspection_repo import InspectionRepository

@pytest.fixture(autouse=True)
def setup_db():
    init_db()

def test_insert_and_retrieve_inspection():
    repo = InspectionRepository()
    uid = uuid.uuid4().hex[:6]
    test_id = f"INSP-TEST-{uid}"
    billet_id = f"BLT-TEST-{uid}"

    item = BilletInspection(
        inspection_id=test_id,
        billet_id=billet_id,
        heat_number="HEAT-9900-X",
        batch_id="BATCH-TEST",
        timestamp=datetime.now().isoformat(),
        length_mm=12001.0,
        width_mm=150.1,
        height_mm=None,
        calibration_id="CAL-STD-01",
        measurement_uncertainty=2.5,
        ocr_raw_text="HEAT-9900-X BLT-TEST",
        ocr_confidence=0.98,
        defect_results=[
            DefectItem(defect_class="surface_inclusion", confidence=0.72, bbox=[10, 20, 30, 40], severity="MAJOR")
        ],
        status="PASS",
        reason="Test insertion passed",
        processing_latency_ms=35.0,
        frame_reference="/data/images/test.jpg",
        source_mode="DEMO",
        configuration_version="v1.2.0"
    )

    repo.insert_inspection(item)

    retrieved = repo.get_by_id(test_id)
    assert retrieved is not None
    assert retrieved.inspection_id == test_id
    assert retrieved.billet_id == billet_id
    assert retrieved.length_mm == 12001.0
    assert len(retrieved.defect_results) == 1
    assert retrieved.defect_results[0].defect_class == "surface_inclusion"

def test_auditable_correction_history():
    repo = InspectionRepository()
    uid = uuid.uuid4().hex[:6]
    test_id = f"INSP-AUDIT-{uid}"
    billet_id = f"BLT-UNVERIFIED-{uid}"

    item = BilletInspection(
        inspection_id=test_id,
        billet_id=billet_id,
        heat_number="HEAT-UNKNOWN",
        batch_id="BATCH-TEST",
        timestamp=datetime.now().isoformat(),
        length_mm=12000.0,
        width_mm=150.0,
        ocr_raw_text="???",
        ocr_confidence=0.30,
        status="REVIEW",
        reason="Unreadable ID"
    )
    repo.insert_inspection(item)

    # Operator corrects heat number and resolves status
    updated = repo.update_audit(
        inspection_id=test_id,
        action="CORRECT_ID",
        operator="CHIEF_INSPECTOR_01",
        notes="Verified stamped tag physically on billet end",
        corrected_billet_id=f"BLT-VERIFIED-{uid}",
        corrected_heat_number="HEAT-8842-A",
        resolved_status="PASS"
    )

    assert updated is not None
    assert updated.billet_id == f"BLT-VERIFIED-{uid}"
    assert updated.heat_number == "HEAT-8842-A"
    assert updated.status == "PASS"
    assert updated.reviewed_by == "CHIEF_INSPECTOR_01"
    assert len(updated.review_audit_events) == 1
    assert updated.review_audit_events[0].action == "CORRECT_ID"
    assert "Original" not in updated.review_audit_events[0].original_val or len(updated.review_audit_events[0].original_val) > 0
