import pytest
from app.adapters.ocr_adapter import OCRAdapter
from app.models.schemas import ToleranceConfig
from app.services.quality_engine import QualityDecisionEngine

def test_ocr_identifier_parsing():
    adapter = OCRAdapter()

    sample_1 = "HEAT-8492-B BATCH-2026-Q3-01 BLT-2026-1042"
    parsed_1 = adapter.parse_identifiers(sample_1)
    assert parsed_1["heat_number"] == "HEAT-8492-B"
    assert parsed_1["batch_id"] == "BATCH-2026-Q3-01"
    assert parsed_1["billet_id"] == "BLT-2026-1042"

    sample_2 = "HT:948123-A BLT-1042-881"
    parsed_2 = adapter.parse_identifiers(sample_2)
    assert "948123-A" in parsed_2["heat_number"]

def test_ocr_low_confidence_triggers_review():
    config = ToleranceConfig(min_ocr_confidence=0.70)
    engine = QualityDecisionEngine(config)

    # 55% confidence (< 70%)
    status, reason = engine.evaluate(
        length_mm=12000.0,
        width_mm=150.0,
        height_mm=None,
        ocr_text="HEAT-8492-?",
        ocr_confidence=0.55,
        defects=[]
    )
    assert status == "REVIEW"
    assert "Low OCR confidence" in reason

def test_ocr_empty_text_triggers_review():
    config = ToleranceConfig(min_ocr_confidence=0.70)
    engine = QualityDecisionEngine(config)

    status, reason = engine.evaluate(
        length_mm=12000.0,
        width_mm=150.0,
        height_mm=None,
        ocr_text="",
        ocr_confidence=0.0,
        defects=[]
    )
    assert status == "REVIEW"
    assert "OCR marking empty or undetectable" in reason
