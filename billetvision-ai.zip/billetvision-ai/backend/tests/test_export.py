import os
import pandas as pd
from app.services.export_service import ExportService
from app.models.schemas import BilletInspection

def test_csv_export():
    service = ExportService()
    items = [
        BilletInspection(
            inspection_id="INSP-EXP-01",
            billet_id="BLT-01",
            heat_number="HEAT-1",
            batch_id="BATCH-1",
            timestamp="2026-10-03T10:00:00",
            length_mm=12000.0,
            width_mm=150.0,
            status="PASS",
            reason="Nominal pass",
            ocr_confidence=0.95
        ),
        BilletInspection(
            inspection_id="INSP-EXP-02",
            billet_id="BLT-02",
            heat_number="HEAT-2",
            batch_id="BATCH-1",
            timestamp="2026-10-03T10:05:00",
            length_mm=12150.0,
            width_mm=154.0,
            status="FAIL",
            reason="Length out of tolerance",
            ocr_confidence=0.88
        )
    ]

    csv_path = service.export_csv(items, filename_prefix="test_billet_exp")
    assert os.path.exists(csv_path)

    # Read back and verify columns
    df = pd.read_csv(csv_path)
    assert len(df) == 2
    assert "Inspection ID" in df.columns
    assert "Quality Status" in df.columns
    assert df.iloc[0]["Quality Status"] == "PASS"
    assert df.iloc[1]["Quality Status"] == "FAIL"

    # Clean up test file
    try:
        os.unlink(csv_path)
    except Exception:
        pass

def test_xlsx_export():
    service = ExportService()
    items = [
        BilletInspection(
            inspection_id="INSP-EXP-01",
            billet_id="BLT-01",
            heat_number="HEAT-1",
            batch_id="BATCH-1",
            timestamp="2026-10-03T10:00:00",
            length_mm=12000.0,
            width_mm=150.0,
            status="PASS",
            reason="Nominal pass",
            ocr_confidence=0.95
        )
    ]

    xlsx_path = service.export_xlsx(items, filename_prefix="test_billet_exp")
    assert os.path.exists(xlsx_path)

    # Verify both sheets using pandas ExcelFile
    excel_file = pd.ExcelFile(xlsx_path)
    assert "Inspection Records" in excel_file.sheet_names
    assert "Executive Summary" in excel_file.sheet_names

    df_records = pd.read_excel(xlsx_path, sheet_name="Inspection Records")
    assert len(df_records) == 1
    assert df_records.iloc[0]["Billet ID"] == "BLT-01"

    df_summary = pd.read_excel(xlsx_path, sheet_name="Executive Summary")
    assert len(df_summary) >= 5

    # Clean up test file
    try:
        os.unlink(xlsx_path)
    except Exception:
        pass
