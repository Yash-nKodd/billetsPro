import pytest
from app.models.schemas import ToleranceConfig, DefectItem
from app.services.quality_engine import QualityDecisionEngine

def test_nominal_pass():
    config = ToleranceConfig(
        target_length_mm=12000.0,
        length_tolerance_pos_mm=50.0,
        length_tolerance_neg_mm=30.0,
        target_width_mm=150.0,
        width_tolerance_pos_mm=3.0,
        width_tolerance_neg_mm=3.0,
        min_ocr_confidence=0.70
    )
    engine = QualityDecisionEngine(config)

    status, reason = engine.evaluate(
        length_mm=12010.0,
        width_mm=150.5,
        height_mm=None,
        ocr_text="HEAT-8492-B BLT-2026-1042",
        ocr_confidence=0.95,
        defects=[]
    )
    assert status == "PASS"
    assert "passed" in reason.lower()

def test_length_exceeded_fail():
    config = ToleranceConfig(
        target_length_mm=12000.0,
        length_tolerance_pos_mm=50.0,
        length_tolerance_neg_mm=30.0
    )
    engine = QualityDecisionEngine(config)

    status, reason = engine.evaluate(
        length_mm=12065.0,  # +65 mm > +50 mm max
        width_mm=150.0,
        height_mm=None,
        ocr_text="HEAT-8492-B",
        ocr_confidence=0.90,
        defects=[]
    )
    assert status == "FAIL"
    assert "exceeds maximum tolerance" in reason

def test_length_under_fail():
    config = ToleranceConfig(
        target_length_mm=12000.0,
        length_tolerance_neg_mm=30.0
    )
    engine = QualityDecisionEngine(config)

    status, reason = engine.evaluate(
        length_mm=11960.0,  # -40 mm < -30 mm
        width_mm=150.0,
        height_mm=None,
        ocr_text="HEAT-8492-B",
        ocr_confidence=0.90,
        defects=[]
    )
    assert status == "FAIL"
    assert "below minimum tolerance" in reason

def test_disallowed_defect_fail():
    config = ToleranceConfig(
        disallowed_defects=["corner_crack", "surface_inclusion"]
    )
    engine = QualityDecisionEngine(config)

    defect = DefectItem(
        defect_class="corner_crack",
        confidence=0.85,
        bbox=[100, 100, 50, 50],
        severity="CRITICAL"
    )
    status, reason = engine.evaluate(
        length_mm=12000.0,
        width_mm=150.0,
        height_mm=None,
        ocr_text="HEAT-8492-B",
        ocr_confidence=0.90,
        defects=[defect]
    )
    assert status == "FAIL"
    assert "corner_crack" in reason

def test_low_ocr_confidence_review():
    config = ToleranceConfig(min_ocr_confidence=0.75)
    engine = QualityDecisionEngine(config)

    status, reason = engine.evaluate(
        length_mm=12000.0,
        width_mm=150.0,
        height_mm=None,
        ocr_text="HEAT-???",
        ocr_confidence=0.55,  # < 0.75
        defects=[]
    )
    assert status == "REVIEW"
    assert "Low OCR confidence" in reason

def test_fail_takes_precedence_over_review():
    config = ToleranceConfig(
        target_length_mm=12000.0,
        length_tolerance_pos_mm=50.0,
        min_ocr_confidence=0.75
    )
    engine = QualityDecisionEngine(config)

    status, reason = engine.evaluate(
        length_mm=12200.0,  # FAIL
        width_mm=150.0,
        height_mm=None,
        ocr_text="HEAT-???",
        ocr_confidence=0.40,  # REVIEW
        defects=[]
    )
    assert status == "FAIL"
    assert "exceeds maximum tolerance" in reason
