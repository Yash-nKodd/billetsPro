import pytest
from app.services.duplicate_suppression import DuplicateSuppressionManager

def test_line_crossing_triggers_once():
    mgr = DuplicateSuppressionManager(suppression_window_s=3.0, trigger_x=0.5)

    # Approaching line (x=0.3 to 0.45)
    t0 = 100.0
    assert not mgr.should_trigger_inspection("BLT-1", current_x=0.45, previous_x=0.3, now=t0)

    # Crossing line (previous 0.45 <= 0.5 <= current 0.55)
    t1 = 100.5
    assert mgr.should_trigger_inspection("BLT-1", current_x=0.55, previous_x=0.45, now=t1)

    # Moving past line within suppression window
    t2 = 101.5
    assert not mgr.should_trigger_inspection("BLT-1", current_x=0.65, previous_x=0.55, now=t2)

def test_duplicate_suppression_window_expiry():
    mgr = DuplicateSuppressionManager(suppression_window_s=3.0, trigger_x=0.5)

    # First trigger at t=100
    assert mgr.should_trigger_inspection("BLT-2", current_x=0.55, previous_x=0.45, now=100.0)

    # Same billet tries to trigger at t=102 (< 3.0s window)
    assert not mgr.should_trigger_inspection("BLT-2", current_x=0.52, previous_x=0.48, now=102.0)

    # After 3.5s (window expired), line crossing triggers again (e.g. conveyor reverse or second pass)
    assert mgr.should_trigger_inspection("BLT-2", current_x=0.52, previous_x=0.48, now=103.5)
